var require, define; !
function(r) {
    function e(r, e) {
        var u = n[r] || {},
        o = u.pkg ? i[u.pkg].url: u.url || r,
        p = a[r] || (a[r] = []);
        if (p.push(e), !(o in f)) {
            f[o] = !0;
            var s = document.createElement("script");
            s.type = "text/javascript",
            s.src = o,
            t.appendChild(s)
        }
    }
    var n, i, t = document.getElementsByTagName("head")[0],
    a = {},
    u = {},
    o = {},
    f = {};
    define = function(r, e) {
        u[r] = e;
        var n = a[r];
        if (n) {
            for (var i = n.length - 1; i >= 0; --i) n[i]();
            delete a[r]
        }
    },
    require = function(r) {
        r = require.alias(r);
        var e = o[r];
        if (e) return e.exports;
        var n = u[r];
        if (!n) throw Error("Cannot find module `" + r + "`");
        e = o[r] = {
            exports: {}
        };
        var i = "function" == typeof n ? n.apply(e, [require, e.exports, e]) : n;
        return i && (e.exports = i),
        e.exports
    },
    require.async = function(i, t) {
        function a(r) {
            for (var i = r.length - 1; i >= 0; --i) {
                var t = r[i];
                if (! (t in u || t in p)) {
                    p[t] = !0,
                    s++,
                    e(t, o);
                    var f = n[t];
                    f && "deps" in f && a(f.deps)
                }
            }
        }
        function o() {
            if (0 == s--) {
                var e, n = [];
                for (e = i.length - 1; e >= 0; --e) n[e] = require(i[e]);
                t && t.apply(r, n)
            }
        }
        "string" == typeof i && (i = [i]);
        for (var f = i.length - 1; f >= 0; --f) i[f] = require.alias(i[f]);
        var p = {},
        s = 0;
        a(i),
        o()
    },
    require.resourceMap = function(r) {
        n = r.res || {},
        i = r.pkg || {}
    },
    require.alias = function(r) {
        return r
    },
    define.amd = {
        jQuery: !0,
        version: "1.0.0"
    }
} (this);;
window.listener = window.listener ||
function() {
    var n = 50,
    t = 25,
    e = {},
    r = [].slice,
    a = {},
    c = function(n, t, r, c) {
        var o = a[n];
        o || (o = a[n] = {}),
        o[t] = o[t] || [],
        o[t].push({
            func: r,
            context: c || e
        })
    },
    o = function(n, t, r, a) {
        var o = function() {
            return e.off(n, t, o),
            r.apply(a || e, arguments)
        };
        c(n, t, o, a)
    },
    f = function(e, c) {
        if (a[e] && a[e][c] && a[e][c].length) {
            for (var o = a[e][c], f = [], i = o.length; i--;) f.push({
                handler: o[i],
                args: r.call(arguments, 1)
            }); !
            function() {
                var e = +new Date;
                do {
                    var r = f.shift(), a = r.handler;
                    try {
                        a.func.apply(a.context, r.args)
                    } catch(c) {}
                } while ( f . length && + new Date - e < n );
                f.length > 0 && setTimeout(arguments.callee, t)
            } ()
        }
    },
    i = function(n, t, r, c) {
        if (c = c || e, a[n] && a[n][t] && a[n][t].length) for (var o, f = a[n][t], i = f.length; i--;) o = f[i],
        o.func === r && o.context === c && f.splice(i, 1)
    };
    return e.on = c,
    e.once = o,
    e.trigger = f,
    e.off = i,
    e
} ();;
window.baidu = window.baidu || {},
baidu.template = baidu.template || {},
baidu.template._encodeHTML = function(e) {
    return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\\/g, "&#92;").replace(/"/g, "&quot;").replace(/'/g, "&#39;")
},
baidu.template._encodeEventHTML = function(e) {
    return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/\\\\/g, "\\").replace(/\\\//g, "/").replace(/\\n/g, "\n").replace(/\\r/g, "\r")
};;
window.Widget = function() {
    function n(n) {
        i(n)
    }
    var t, o = [],
    e = [],
    i = function(n) {
        t.$el = $(t.el),
        c(),
        t.init && $.isFunction(t.init) && t.init(n),
        r()
    },
    c = function() {
        t.$dom = {};
        for (var n, o, e = t.$el.html() || "", i = e.match(/data-node="([^"]*)"/gim) || [], c = i.length - 1; c >= 0; c--) n = i[c],
        o = n.split("=")[1].replace(/"/g, ""),
        t.$dom[o] = t.$el.find("[" + n + "]")
    },
    r = function() {
        var n, o, e, i, c = t.events,
        r = t.channels,
        a = /^(\S+)\s*(.*)$/;
        c && c instanceof Object && $.each(c,
        function(e, c) {
            return $.isFunction(c) || (c = t[c]),
            c ? (i = e.match(a), n = i[1], o = i[2], void u(n, o, c)) : !0
        }),
        r && r instanceof Object && $.each(r,
        function(o, c) {
            return $.isFunction(c) || (c = t[c]),
            c ? (i = o.match(a), e = i[1], n = i[2], void f(e, n, c)) : !0
        }),
        listener.once("common.page", "pagearrived", $.proxy(d, t))
    },
    u = function(n, e, i) {
        var c = t.el || "body";
        e ? $(c).on(n, e, $.proxy(i, t)) : $(c).on(n, $.proxy(i, t)),
        o.push([n, e, i])
    },
    f = function(n, o, i) {
        listener.on(n, o, $.proxy(i, t)),
        e.push([n, o, i])
    },
    a = function(n, o, e) {
        var i = t.el || "body";
        o ? $(i).off(n, o, e) : $(i).off(n, e)
    },
    s = function(n, t, o) {
        listener.off(n, t, o)
    },
    d = function() {
        t.destroy && $.isFunction(t.destroy) && (t.destroy(), t.destroy = null),
        $.each(o,
        function(n, t) {
            a(t[0], t[1], t[2])
        }),
        $.each(e,
        function(n, t) {
            s(t[0], t[1], t[2])
        }),
        o = [],
        e = [],
        t.el = void 0
    };
    return n.extend = function(n) {
        var o = this,
        e = function() {
            return t = this,
            o.apply(this, arguments)
        },
        i = function() {
            this.constructor = e
        };
        return i.prototype = o.prototype,
        e.prototype = new i,
        i = null,
        $.extend(e.prototype, n),
        e.createWidget = function(n) {
            new e(n)
        },
        e
    },
    n
} ();; !
function(e, t) {
    "object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, !0) : function(e) {
        if (!e.document) throw new Error("jQuery requires a window with a document");
        return t(e)
    }: t(e)
} ("undefined" != typeof window ? window: this,
function(e, t) {
    function n(e) {
        var t = e.length,
        n = ot.type(e);
        return "function" === n || ot.isWindow(e) ? !1 : 1 === e.nodeType && t ? !0 : "array" === n || 0 === t || "number" == typeof t && t > 0 && t - 1 in e
    }
    function r(e, t, n) {
        if (ot.isFunction(t)) return ot.grep(e,
        function(e, r) {
            return !! t.call(e, r, e) !== n
        });
        if (t.nodeType) return ot.grep(e,
        function(e) {
            return e === t !== n
        });
        if ("string" == typeof t) {
            if (pt.test(t)) return ot.filter(t, e, n);
            t = ot.filter(t, e)
        }
        return ot.grep(e,
        function(e) {
            return ot.inArray(e, t) >= 0 !== n
        })
    }
    function i(e, t) {
        do e = e[t];
        while (e && 1 !== e.nodeType);
        return e
    }
    function o(e) {
        var t = wt[e] = {};
        return ot.each(e.match(xt) || [],
        function(e, n) {
            t[n] = !0
        }),
        t
    }
    function a() {
        mt.addEventListener ? (mt.removeEventListener("DOMContentLoaded", s, !1), e.removeEventListener("load", s, !1)) : (mt.detachEvent("onreadystatechange", s), e.detachEvent("onload", s))
    }
    function s() { (mt.addEventListener || "load" === event.type || "complete" === mt.readyState) && (a(), ot.ready())
    }
    function l(e, t, n) {
        if (void 0 === n && 1 === e.nodeType) {
            var r = "data-" + t.replace(kt, "-$1").toLowerCase();
            if (n = e.getAttribute(r), "string" == typeof n) {
                try {
                    n = "true" === n ? !0 : "false" === n ? !1 : "null" === n ? null: +n + "" === n ? +n: Et.test(n) ? ot.parseJSON(n) : n
                } catch(i) {}
                ot.data(e, t, n)
            } else n = void 0
        }
        return n
    }
    function u(e) {
        var t;
        for (t in e) if (("data" !== t || !ot.isEmptyObject(e[t])) && "toJSON" !== t) return ! 1;
        return ! 0
    }
    function c(e, t, n, r) {
        if (ot.acceptData(e)) {
            var i, o, a = ot.expando,
            s = e.nodeType,
            l = s ? ot.cache: e,
            u = s ? e[a] : e[a] && a;
            if (u && l[u] && (r || l[u].data) || void 0 !== n || "string" != typeof t) return u || (u = s ? e[a] = Y.pop() || ot.guid++:a),
            l[u] || (l[u] = s ? {}: {
                toJSON: ot.noop
            }),
            ("object" == typeof t || "function" == typeof t) && (r ? l[u] = ot.extend(l[u], t) : l[u].data = ot.extend(l[u].data, t)),
            o = l[u],
            r || (o.data || (o.data = {}), o = o.data),
            void 0 !== n && (o[ot.camelCase(t)] = n),
            "string" == typeof t ? (i = o[t], null == i && (i = o[ot.camelCase(t)])) : i = o,
            i
        }
    }
    function d(e, t, n) {
        if (ot.acceptData(e)) {
            var r, i, o = e.nodeType,
            a = o ? ot.cache: e,
            s = o ? e[ot.expando] : ot.expando;
            if (a[s]) {
                if (t && (r = n ? a[s] : a[s].data)) {
                    ot.isArray(t) ? t = t.concat(ot.map(t, ot.camelCase)) : t in r ? t = [t] : (t = ot.camelCase(t), t = t in r ? [t] : t.split(" ")),
                    i = t.length;
                    for (; i--;) delete r[t[i]];
                    if (n ? !u(r) : !ot.isEmptyObject(r)) return
                } (n || (delete a[s].data, u(a[s]))) && (o ? ot.cleanData([e], !0) : rt.deleteExpando || a != a.window ? delete a[s] : a[s] = null)
            }
        }
    }
    function f() {
        return ! 0
    }
    function p() {
        return ! 1
    }
    function h() {
        try {
            return mt.activeElement
        } catch(e) {}
    }
    function m(e) {
        var t = Ft.split("|"),
        n = e.createDocumentFragment();
        if (n.createElement) for (; t.length;) n.createElement(t.pop());
        return n
    }
    function g(e, t) {
        var n, r, i = 0,
        o = typeof e.getElementsByTagName !== Nt ? e.getElementsByTagName(t || "*") : typeof e.querySelectorAll !== Nt ? e.querySelectorAll(t || "*") : void 0;
        if (!o) for (o = [], n = e.childNodes || e; null != (r = n[i]); i++) ! t || ot.nodeName(r, t) ? o.push(r) : ot.merge(o, g(r, t));
        return void 0 === t || t && ot.nodeName(e, t) ? ot.merge([e], o) : o
    }
    function v(e) {
        Lt.test(e.type) && (e.defaultChecked = e.checked)
    }
    function y(e, t) {
        return ot.nodeName(e, "table") && ot.nodeName(11 !== t.nodeType ? t: t.firstChild, "tr") ? e.getElementsByTagName("tbody")[0] || e.appendChild(e.ownerDocument.createElement("tbody")) : e
    }
    function b(e) {
        return e.type = (null !== ot.find.attr(e, "type")) + "/" + e.type,
        e
    }
    function x(e) {
        var t = Yt.exec(e.type);
        return t ? e.type = t[1] : e.removeAttribute("type"),
        e
    }
    function w(e, t) {
        for (var n, r = 0; null != (n = e[r]); r++) ot._data(n, "globalEval", !t || ot._data(t[r], "globalEval"))
    }
    function T(e, t) {
        if (1 === t.nodeType && ot.hasData(e)) {
            var n, r, i, o = ot._data(e),
            a = ot._data(t, o),
            s = o.events;
            if (s) {
                delete a.handle,
                a.events = {};
                for (n in s) for (r = 0, i = s[n].length; i > r; r++) ot.event.add(t, n, s[n][r])
            }
            a.data && (a.data = ot.extend({},
            a.data))
        }
    }
    function C(e, t) {
        var n, r, i;
        if (1 === t.nodeType) {
            if (n = t.nodeName.toLowerCase(), !rt.noCloneEvent && t[ot.expando]) {
                i = ot._data(t);
                for (r in i.events) ot.removeEvent(t, r, i.handle);
                t.removeAttribute(ot.expando)
            }
            "script" === n && t.text !== e.text ? (b(t).text = e.text, x(t)) : "object" === n ? (t.parentNode && (t.outerHTML = e.outerHTML), rt.html5Clone && e.innerHTML && !ot.trim(t.innerHTML) && (t.innerHTML = e.innerHTML)) : "input" === n && Lt.test(e.type) ? (t.defaultChecked = t.checked = e.checked, t.value !== e.value && (t.value = e.value)) : "option" === n ? t.defaultSelected = t.selected = e.defaultSelected: ("input" === n || "textarea" === n) && (t.defaultValue = e.defaultValue)
        }
    }
    function N(t, n) {
        var r = ot(n.createElement(t)).appendTo(n.body),
        i = e.getDefaultComputedStyle ? e.getDefaultComputedStyle(r[0]).display: ot.css(r[0], "display");
        return r.detach(),
        i
    }
    function E(e) {
        var t = mt,
        n = en[e];
        return n || (n = N(e, t), "none" !== n && n || (Zt = (Zt || ot("<iframe frameborder='0' width='0' height='0'/>")).appendTo(t.documentElement), t = (Zt[0].contentWindow || Zt[0].contentDocument).document, t.write(), t.close(), n = N(e, t), Zt.detach()), en[e] = n),
        n
    }
    function k(e, t) {
        return {
            get: function() {
                var n = e();
                if (null != n) return n ? void delete this.get: (this.get = t).apply(this, arguments)
            }
        }
    }
    function S(e, t) {
        if (t in e) return t;
        for (var n = t.charAt(0).toUpperCase() + t.slice(1), r = t, i = hn.length; i--;) if (t = hn[i] + n, t in e) return t;
        return r
    }
    function D(e, t) {
        for (var n, r, i, o = [], a = 0, s = e.length; s > a; a++) r = e[a],
        r.style && (o[a] = ot._data(r, "olddisplay"), n = r.style.display, t ? (o[a] || "none" !== n || (r.style.display = ""), "" === r.style.display && At(r) && (o[a] = ot._data(r, "olddisplay", E(r.nodeName)))) : o[a] || (i = At(r), (n && "none" !== n || !i) && ot._data(r, "olddisplay", i ? n: ot.css(r, "display"))));
        for (a = 0; s > a; a++) r = e[a],
        r.style && (t && "none" !== r.style.display && "" !== r.style.display || (r.style.display = t ? o[a] || "": "none"));
        return e
    }
    function A(e, t, n) {
        var r = cn.exec(t);
        return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : t
    }
    function j(e, t, n, r, i) {
        for (var o = n === (r ? "border": "content") ? 4 : "width" === t ? 1 : 0, a = 0; 4 > o; o += 2)"margin" === n && (a += ot.css(e, n + Dt[o], !0, i)),
        r ? ("content" === n && (a -= ot.css(e, "padding" + Dt[o], !0, i)), "margin" !== n && (a -= ot.css(e, "border" + Dt[o] + "Width", !0, i))) : (a += ot.css(e, "padding" + Dt[o], !0, i), "padding" !== n && (a += ot.css(e, "border" + Dt[o] + "Width", !0, i)));
        return a
    }
    function L(e, t, n) {
        var r = !0,
        i = "width" === t ? e.offsetWidth: e.offsetHeight,
        o = tn(e),
        a = rt.boxSizing() && "border-box" === ot.css(e, "boxSizing", !1, o);
        if (0 >= i || null == i) {
            if (i = nn(e, t, o), (0 > i || null == i) && (i = e.style[t]), on.test(i)) return i;
            r = a && (rt.boxSizingReliable() || i === e.style[t]),
            i = parseFloat(i) || 0
        }
        return i + j(e, t, n || (a ? "border": "content"), r, o) + "px"
    }
    function _(e, t, n, r, i) {
        return new _.prototype.init(e, t, n, r, i)
    }
    function H() {
        return setTimeout(function() {
            mn = void 0
        }),
        mn = ot.now()
    }
    function M(e, t) {
        var n, r = {
            height: e
        },
        i = 0;
        for (t = t ? 1 : 0; 4 > i; i += 2 - t) n = Dt[i],
        r["margin" + n] = r["padding" + n] = e;
        return t && (r.opacity = r.width = e),
        r
    }
    function q(e, t, n) {
        for (var r, i = (wn[t] || []).concat(wn["*"]), o = 0, a = i.length; a > o; o++) if (r = i[o].call(n, t, e)) return r
    }
    function O(e, t, n) {
        var r, i, o, a, s, l, u, c, d = this,
        f = {},
        p = e.style,
        h = e.nodeType && At(e),
        m = ot._data(e, "fxshow");
        n.queue || (s = ot._queueHooks(e, "fx"), null == s.unqueued && (s.unqueued = 0, l = s.empty.fire, s.empty.fire = function() {
            s.unqueued || l()
        }), s.unqueued++, d.always(function() {
            d.always(function() {
                s.unqueued--,
                ot.queue(e, "fx").length || s.empty.fire()
            })
        })),
        1 === e.nodeType && ("height" in t || "width" in t) && (n.overflow = [p.overflow, p.overflowX, p.overflowY], u = ot.css(e, "display"), c = E(e.nodeName), "none" === u && (u = c), "inline" === u && "none" === ot.css(e, "float") && (rt.inlineBlockNeedsLayout && "inline" !== c ? p.zoom = 1 : p.display = "inline-block")),
        n.overflow && (p.overflow = "hidden", rt.shrinkWrapBlocks() || d.always(function() {
            p.overflow = n.overflow[0],
            p.overflowX = n.overflow[1],
            p.overflowY = n.overflow[2]
        }));
        for (r in t) if (i = t[r], vn.exec(i)) {
            if (delete t[r], o = o || "toggle" === i, i === (h ? "hide": "show")) {
                if ("show" !== i || !m || void 0 === m[r]) continue;
                h = !0
            }
            f[r] = m && m[r] || ot.style(e, r)
        }
        if (!ot.isEmptyObject(f)) {
            m ? "hidden" in m && (h = m.hidden) : m = ot._data(e, "fxshow", {}),
            o && (m.hidden = !h),
            h ? ot(e).show() : d.done(function() {
                ot(e).hide()
            }),
            d.done(function() {
                var t;
                ot._removeData(e, "fxshow");
                for (t in f) ot.style(e, t, f[t])
            });
            for (r in f) a = q(h ? m[r] : 0, r, d),
            r in m || (m[r] = a.start, h && (a.end = a.start, a.start = "width" === r || "height" === r ? 1 : 0))
        }
    }
    function F(e, t) {
        var n, r, i, o, a;
        for (n in e) if (r = ot.camelCase(n), i = t[r], o = e[n], ot.isArray(o) && (i = o[1], o = e[n] = o[0]), n !== r && (e[r] = o, delete e[n]), a = ot.cssHooks[r], a && "expand" in a) {
            o = a.expand(o),
            delete e[r];
            for (n in o) n in e || (e[n] = o[n], t[n] = i)
        } else t[r] = i
    }
    function P(e, t, n) {
        var r, i, o = 0,
        a = xn.length,
        s = ot.Deferred().always(function() {
            delete l.elem
        }),
        l = function() {
            if (i) return ! 1;
            for (var t = mn || H(), n = Math.max(0, u.startTime + u.duration - t), r = n / u.duration || 0, o = 1 - r, a = 0, l = u.tweens.length; l > a; a++) u.tweens[a].run(o);
            return s.notifyWith(e, [u, o, n]),
            1 > o && l ? n: (s.resolveWith(e, [u]), !1)
        },
        u = s.promise({
            elem: e,
            props: ot.extend({},
            t),
            opts: ot.extend(!0, {
                specialEasing: {}
            },
            n),
            originalProperties: t,
            originalOptions: n,
            startTime: mn || H(),
            duration: n.duration,
            tweens: [],
            createTween: function(t, n) {
                var r = ot.Tween(e, u.opts, t, n, u.opts.specialEasing[t] || u.opts.easing);
                return u.tweens.push(r),
                r
            },
            stop: function(t) {
                var n = 0,
                r = t ? u.tweens.length: 0;
                if (i) return this;
                for (i = !0; r > n; n++) u.tweens[n].run(1);
                return t ? s.resolveWith(e, [u, t]) : s.rejectWith(e, [u, t]),
                this
            }
        }),
        c = u.props;
        for (F(c, u.opts.specialEasing); a > o; o++) if (r = xn[o].call(u, e, c, u.opts)) return r;
        return ot.map(c, q, u),
        ot.isFunction(u.opts.start) && u.opts.start.call(e, u),
        ot.fx.timer(ot.extend(l, {
            elem: e,
            anim: u,
            queue: u.opts.queue
        })),
        u.progress(u.opts.progress).done(u.opts.done, u.opts.complete).fail(u.opts.fail).always(u.opts.always)
    }
    function B(e) {
        return function(t, n) {
            "string" != typeof t && (n = t, t = "*");
            var r, i = 0,
            o = t.toLowerCase().match(xt) || [];
            if (ot.isFunction(n)) for (; r = o[i++];)"+" === r.charAt(0) ? (r = r.slice(1) || "*", (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n)
        }
    }
    function W(e, t, n, r) {
        function i(s) {
            var l;
            return o[s] = !0,
            ot.each(e[s] || [],
            function(e, s) {
                var u = s(t, n, r);
                return "string" != typeof u || a || o[u] ? a ? !(l = u) : void 0 : (t.dataTypes.unshift(u), i(u), !1)
            }),
            l
        }
        var o = {},
        a = e === Xn;
        return i(t.dataTypes[0]) || !o["*"] && i("*")
    }
    function R(e, t) {
        var n, r, i = ot.ajaxSettings.flatOptions || {};
        for (r in t) void 0 !== t[r] && ((i[r] ? e: n || (n = {}))[r] = t[r]);
        return n && ot.extend(!0, e, n),
        e
    }
    function $(e, t, n) {
        for (var r, i, o, a, s = e.contents,
        l = e.dataTypes;
        "*" === l[0];) l.shift(),
        void 0 === i && (i = e.mimeType || t.getResponseHeader("Content-Type"));
        if (i) for (a in s) if (s[a] && s[a].test(i)) {
            l.unshift(a);
            break
        }
        if (l[0] in n) o = l[0];
        else {
            for (a in n) {
                if (!l[0] || e.converters[a + " " + l[0]]) {
                    o = a;
                    break
                }
                r || (r = a)
            }
            o = o || r
        }
        return o ? (o !== l[0] && l.unshift(o), n[o]) : void 0
    }
    function z(e, t, n, r) {
        var i, o, a, s, l, u = {},
        c = e.dataTypes.slice();
        if (c[1]) for (a in e.converters) u[a.toLowerCase()] = e.converters[a];
        for (o = c.shift(); o;) if (e.responseFields[o] && (n[e.responseFields[o]] = t), !l && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), l = o, o = c.shift()) if ("*" === o) o = l;
        else if ("*" !== l && l !== o) {
            if (a = u[l + " " + o] || u["* " + o], !a) for (i in u) if (s = i.split(" "), s[1] === o && (a = u[l + " " + s[0]] || u["* " + s[0]])) {
                a === !0 ? a = u[i] : u[i] !== !0 && (o = s[0], c.unshift(s[1]));
                break
            }
            if (a !== !0) if (a && e["throws"]) t = a(t);
            else try {
                t = a(t)
            } catch(d) {
                return {
                    state: "parsererror",
                    error: a ? d: "No conversion from " + l + " to " + o
                }
            }
        }
        return {
            state: "success",
            data: t
        }
    }
    function I(e, t, n, r) {
        var i;
        if (ot.isArray(t)) ot.each(t,
        function(t, i) {
            n || Jn.test(e) ? r(e, i) : I(e + "[" + ("object" == typeof i ? t: "") + "]", i, n, r)
        });
        else if (n || "object" !== ot.type(t)) r(e, t);
        else for (i in t) I(e + "[" + i + "]", t[i], n, r)
    }
    function X() {
        try {
            return new e.XMLHttpRequest
        } catch(t) {}
    }
    function U() {
        try {
            return new e.ActiveXObject("Microsoft.XMLHTTP")
        } catch(t) {}
    }
    function V(e) {
        return ot.isWindow(e) ? e: 9 === e.nodeType ? e.defaultView || e.parentWindow: !1
    }
    var Y = [],
    J = Y.slice,
    Q = Y.concat,
    G = Y.push,
    K = Y.indexOf,
    Z = {},
    et = Z.toString,
    tt = Z.hasOwnProperty,
    nt = "".trim,
    rt = {},
    it = "1.11.0",
    ot = function(e, t) {
        return new ot.fn.init(e, t)
    },
    at = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
    st = /^-ms-/,
    lt = /-([\da-z])/gi,
    ut = function(e, t) {
        return t.toUpperCase()
    };
    ot.fn = ot.prototype = {
        jquery: it,
        constructor: ot,
        selector: "",
        length: 0,
        toArray: function() {
            return J.call(this)
        },
        get: function(e) {
            return null != e ? 0 > e ? this[e + this.length] : this[e] : J.call(this)
        },
        pushStack: function(e) {
            var t = ot.merge(this.constructor(), e);
            return t.prevObject = this,
            t.context = this.context,
            t
        },
        each: function(e, t) {
            return ot.each(this, e, t)
        },
        map: function(e) {
            return this.pushStack(ot.map(this,
            function(t, n) {
                return e.call(t, n, t)
            }))
        },
        slice: function() {
            return this.pushStack(J.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq( - 1)
        },
        eq: function(e) {
            var t = this.length,
            n = +e + (0 > e ? t: 0);
            return this.pushStack(n >= 0 && t > n ? [this[n]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor(null)
        },
        push: G,
        sort: Y.sort,
        splice: Y.splice
    },
    ot.extend = ot.fn.extend = function() {
        var e, t, n, r, i, o, a = arguments[0] || {},
        s = 1,
        l = arguments.length,
        u = !1;
        for ("boolean" == typeof a && (u = a, a = arguments[s] || {},
        s++), "object" == typeof a || ot.isFunction(a) || (a = {}), s === l && (a = this, s--); l > s; s++) if (null != (i = arguments[s])) for (r in i) e = a[r],
        n = i[r],
        a !== n && (u && n && (ot.isPlainObject(n) || (t = ot.isArray(n))) ? (t ? (t = !1, o = e && ot.isArray(e) ? e: []) : o = e && ot.isPlainObject(e) ? e: {},
        a[r] = ot.extend(u, o, n)) : void 0 !== n && (a[r] = n));
        return a
    },
    ot.extend({
        expando: "jQuery" + (it + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(e) {
            throw new Error(e)
        },
        noop: function() {},
        isFunction: function(e) {
            return "function" === ot.type(e)
        },
        isArray: Array.isArray ||
        function(e) {
            return "array" === ot.type(e)
        },
        isWindow: function(e) {
            return null != e && e == e.window
        },
        isNumeric: function(e) {
            return e - parseFloat(e) >= 0
        },
        isEmptyObject: function(e) {
            var t;
            for (t in e) return ! 1;
            return ! 0
        },
        isPlainObject: function(e) {
            var t;
            if (!e || "object" !== ot.type(e) || e.nodeType || ot.isWindow(e)) return ! 1;
            try {
                if (e.constructor && !tt.call(e, "constructor") && !tt.call(e.constructor.prototype, "isPrototypeOf")) return ! 1
            } catch(n) {
                return ! 1
            }
            if (rt.ownLast) for (t in e) return tt.call(e, t);
            for (t in e);
            return void 0 === t || tt.call(e, t)
        },
        type: function(e) {
            return null == e ? e + "": "object" == typeof e || "function" == typeof e ? Z[et.call(e)] || "object": typeof e
        },
        globalEval: function(t) {
            t && ot.trim(t) && (e.execScript ||
            function(t) {
                e.eval.call(e, t)
            })(t)
        },
        camelCase: function(e) {
            return e.replace(st, "ms-").replace(lt, ut)
        },
        nodeName: function(e, t) {
            return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
        },
        each: function(e, t, r) {
            var i, o = 0,
            a = e.length,
            s = n(e);
            if (r) {
                if (s) for (; a > o && (i = t.apply(e[o], r), i !== !1); o++);
                else for (o in e) if (i = t.apply(e[o], r), i === !1) break
            } else if (s) for (; a > o && (i = t.call(e[o], o, e[o]), i !== !1); o++);
            else for (o in e) if (i = t.call(e[o], o, e[o]), i === !1) break;
            return e
        },
        trim: nt && !nt.call("﻿ ") ?
        function(e) {
            return null == e ? "": nt.call(e)
        }: function(e) {
            return null == e ? "": (e + "").replace(at, "")
        },
        makeArray: function(e, t) {
            var r = t || [];
            return null != e && (n(Object(e)) ? ot.merge(r, "string" == typeof e ? [e] : e) : G.call(r, e)),
            r
        },
        inArray: function(e, t, n) {
            var r;
            if (t) {
                if (K) return K.call(t, e, n);
                for (r = t.length, n = n ? 0 > n ? Math.max(0, r + n) : n: 0; r > n; n++) if (n in t && t[n] === e) return n
            }
            return - 1
        },
        merge: function(e, t) {
            for (var n = +t.length,
            r = 0,
            i = e.length; n > r;) e[i++] = t[r++];
            if (n !== n) for (; void 0 !== t[r];) e[i++] = t[r++];
            return e.length = i,
            e
        },
        grep: function(e, t, n) {
            for (var r, i = [], o = 0, a = e.length, s = !n; a > o; o++) r = !t(e[o], o),
            r !== s && i.push(e[o]);
            return i
        },
        map: function(e, t, r) {
            var i, o = 0,
            a = e.length,
            s = n(e),
            l = [];
            if (s) for (; a > o; o++) i = t(e[o], o, r),
            null != i && l.push(i);
            else for (o in e) i = t(e[o], o, r),
            null != i && l.push(i);
            return Q.apply([], l)
        },
        guid: 1,
        proxy: function(e, t) {
            var n, r, i;
            return "string" == typeof t && (i = e[t], t = e, e = i),
            ot.isFunction(e) ? (n = J.call(arguments, 2), r = function() {
                return e.apply(t || this, n.concat(J.call(arguments)))
            },
            r.guid = e.guid = e.guid || ot.guid++, r) : void 0
        },
        now: function() {
            return + new Date
        },
        support: rt
    }),
    ot.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),
    function(e, t) {
        Z["[object " + t + "]"] = t.toLowerCase()
    });
    var ct = function(e) {
        function t(e, t, n, r) {
            var i, o, a, s, l, u, d, h, m, g;
            if ((t ? t.ownerDocument || t: W) !== _ && L(t), t = t || _, n = n || [], !e || "string" != typeof e) return n;
            if (1 !== (s = t.nodeType) && 9 !== s) return [];
            if (M && !r) {
                if (i = yt.exec(e)) if (a = i[1]) {
                    if (9 === s) {
                        if (o = t.getElementById(a), !o || !o.parentNode) return n;
                        if (o.id === a) return n.push(o),
                        n
                    } else if (t.ownerDocument && (o = t.ownerDocument.getElementById(a)) && P(t, o) && o.id === a) return n.push(o),
                    n
                } else {
                    if (i[2]) return Z.apply(n, t.getElementsByTagName(e)),
                    n;
                    if ((a = i[3]) && C.getElementsByClassName && t.getElementsByClassName) return Z.apply(n, t.getElementsByClassName(a)),
                    n
                }
                if (C.qsa && (!q || !q.test(e))) {
                    if (h = d = B, m = t, g = 9 === s && e, 1 === s && "object" !== t.nodeName.toLowerCase()) {
                        for (u = f(e), (d = t.getAttribute("id")) ? h = d.replace(xt, "\\$&") : t.setAttribute("id", h), h = "[id='" + h + "'] ", l = u.length; l--;) u[l] = h + p(u[l]);
                        m = bt.test(e) && c(t.parentNode) || t,
                        g = u.join(",")
                    }
                    if (g) try {
                        return Z.apply(n, m.querySelectorAll(g)),
                        n
                    } catch(v) {} finally {
                        d || t.removeAttribute("id")
                    }
                }
            }
            return w(e.replace(lt, "$1"), t, n, r)
        }
        function n() {
            function e(n, r) {
                return t.push(n + " ") > N.cacheLength && delete e[t.shift()],
                e[n + " "] = r
            }
            var t = [];
            return e
        }
        function r(e) {
            return e[B] = !0,
            e
        }
        function i(e) {
            var t = _.createElement("div");
            try {
                return !! e(t)
            } catch(n) {
                return ! 1
            } finally {
                t.parentNode && t.parentNode.removeChild(t),
                t = null
            }
        }
        function o(e, t) {
            for (var n = e.split("|"), r = e.length; r--;) N.attrHandle[n[r]] = t
        }
        function a(e, t) {
            var n = t && e,
            r = n && 1 === e.nodeType && 1 === t.nodeType && (~t.sourceIndex || Y) - (~e.sourceIndex || Y);
            if (r) return r;
            if (n) for (; n = n.nextSibling;) if (n === t) return - 1;
            return e ? 1 : -1
        }
        function s(e) {
            return function(t) {
                var n = t.nodeName.toLowerCase();
                return "input" === n && t.type === e
            }
        }
        function l(e) {
            return function(t) {
                var n = t.nodeName.toLowerCase();
                return ("input" === n || "button" === n) && t.type === e
            }
        }
        function u(e) {
            return r(function(t) {
                return t = +t,
                r(function(n, r) {
                    for (var i, o = e([], n.length, t), a = o.length; a--;) n[i = o[a]] && (n[i] = !(r[i] = n[i]))
                })
            })
        }
        function c(e) {
            return e && typeof e.getElementsByTagName !== V && e
        }
        function d() {}
        function f(e, n) {
            var r, i, o, a, s, l, u, c = I[e + " "];
            if (c) return n ? 0 : c.slice(0);
            for (s = e, l = [], u = N.preFilter; s;) { (!r || (i = ut.exec(s))) && (i && (s = s.slice(i[0].length) || s), l.push(o = [])),
                r = !1,
                (i = ct.exec(s)) && (r = i.shift(), o.push({
                    value: r,
                    type: i[0].replace(lt, " ")
                }), s = s.slice(r.length));
                for (a in N.filter) ! (i = ht[a].exec(s)) || u[a] && !(i = u[a](i)) || (r = i.shift(), o.push({
                    value: r,
                    type: a,
                    matches: i
                }), s = s.slice(r.length));
                if (!r) break
            }
            return n ? s.length: s ? t.error(e) : I(e, l).slice(0)
        }
        function p(e) {
            for (var t = 0,
            n = e.length,
            r = ""; n > t; t++) r += e[t].value;
            return r
        }
        function h(e, t, n) {
            var r = t.dir,
            i = n && "parentNode" === r,
            o = $++;
            return t.first ?
            function(t, n, o) {
                for (; t = t[r];) if (1 === t.nodeType || i) return e(t, n, o)
            }: function(t, n, a) {
                var s, l, u = [R, o];
                if (a) {
                    for (; t = t[r];) if ((1 === t.nodeType || i) && e(t, n, a)) return ! 0
                } else for (; t = t[r];) if (1 === t.nodeType || i) {
                    if (l = t[B] || (t[B] = {}), (s = l[r]) && s[0] === R && s[1] === o) return u[2] = s[2];
                    if (l[r] = u, u[2] = e(t, n, a)) return ! 0
                }
            }
        }
        function m(e) {
            return e.length > 1 ?
            function(t, n, r) {
                for (var i = e.length; i--;) if (!e[i](t, n, r)) return ! 1;
                return ! 0
            }: e[0]
        }
        function g(e, t, n, r, i) {
            for (var o, a = [], s = 0, l = e.length, u = null != t; l > s; s++)(o = e[s]) && (!n || n(o, r, i)) && (a.push(o), u && t.push(s));
            return a
        }
        function v(e, t, n, i, o, a) {
            return i && !i[B] && (i = v(i)),
            o && !o[B] && (o = v(o, a)),
            r(function(r, a, s, l) {
                var u, c, d, f = [],
                p = [],
                h = a.length,
                m = r || x(t || "*", s.nodeType ? [s] : s, []),
                v = !e || !r && t ? m: g(m, f, e, s, l),
                y = n ? o || (r ? e: h || i) ? [] : a: v;
                if (n && n(v, y, s, l), i) for (u = g(y, p), i(u, [], s, l), c = u.length; c--;)(d = u[c]) && (y[p[c]] = !(v[p[c]] = d));
                if (r) {
                    if (o || e) {
                        if (o) {
                            for (u = [], c = y.length; c--;)(d = y[c]) && u.push(v[c] = d);
                            o(null, y = [], u, l)
                        }
                        for (c = y.length; c--;)(d = y[c]) && (u = o ? tt.call(r, d) : f[c]) > -1 && (r[u] = !(a[u] = d))
                    }
                } else y = g(y === a ? y.splice(h, y.length) : y),
                o ? o(null, a, y, l) : Z.apply(a, y)
            })
        }
        function y(e) {
            for (var t, n, r, i = e.length,
            o = N.relative[e[0].type], a = o || N.relative[" "], s = o ? 1 : 0, l = h(function(e) {
                return e === t
            },
            a, !0), u = h(function(e) {
                return tt.call(t, e) > -1
            },
            a, !0), c = [function(e, n, r) {
                return ! o && (r || n !== D) || ((t = n).nodeType ? l(e, n, r) : u(e, n, r))
            }]; i > s; s++) if (n = N.relative[e[s].type]) c = [h(m(c), n)];
            else {
                if (n = N.filter[e[s].type].apply(null, e[s].matches), n[B]) {
                    for (r = ++s; i > r && !N.relative[e[r].type]; r++);
                    return v(s > 1 && m(c), s > 1 && p(e.slice(0, s - 1).concat({
                        value: " " === e[s - 2].type ? "*": ""
                    })).replace(lt, "$1"), n, r > s && y(e.slice(s, r)), i > r && y(e = e.slice(r)), i > r && p(e))
                }
                c.push(n)
            }
            return m(c)
        }
        function b(e, n) {
            var i = n.length > 0,
            o = e.length > 0,
            a = function(r, a, s, l, u) {
                var c, d, f, p = 0,
                h = "0",
                m = r && [],
                v = [],
                y = D,
                b = r || o && N.find.TAG("*", u),
                x = R += null == y ? 1 : Math.random() || .1,
                w = b.length;
                for (u && (D = a !== _ && a); h !== w && null != (c = b[h]); h++) {
                    if (o && c) {
                        for (d = 0; f = e[d++];) if (f(c, a, s)) {
                            l.push(c);
                            break
                        }
                        u && (R = x)
                    }
                    i && ((c = !f && c) && p--, r && m.push(c))
                }
                if (p += h, i && h !== p) {
                    for (d = 0; f = n[d++];) f(m, v, a, s);
                    if (r) {
                        if (p > 0) for (; h--;) m[h] || v[h] || (v[h] = G.call(l));
                        v = g(v)
                    }
                    Z.apply(l, v),
                    u && !r && v.length > 0 && p + n.length > 1 && t.uniqueSort(l)
                }
                return u && (R = x, D = y),
                m
            };
            return i ? r(a) : a
        }
        function x(e, n, r) {
            for (var i = 0,
            o = n.length; o > i; i++) t(e, n[i], r);
            return r
        }
        function w(e, t, n, r) {
            var i, o, a, s, l, u = f(e);
            if (!r && 1 === u.length) {
                if (o = u[0] = u[0].slice(0), o.length > 2 && "ID" === (a = o[0]).type && C.getById && 9 === t.nodeType && M && N.relative[o[1].type]) {
                    if (t = (N.find.ID(a.matches[0].replace(wt, Tt), t) || [])[0], !t) return n;
                    e = e.slice(o.shift().value.length)
                }
                for (i = ht.needsContext.test(e) ? 0 : o.length; i--&&(a = o[i], !N.relative[s = a.type]);) if ((l = N.find[s]) && (r = l(a.matches[0].replace(wt, Tt), bt.test(o[0].type) && c(t.parentNode) || t))) {
                    if (o.splice(i, 1), e = r.length && p(o), !e) return Z.apply(n, r),
                    n;
                    break
                }
            }
            return S(e, u)(r, t, !M, n, bt.test(e) && c(t.parentNode) || t),
            n
        }
        var T, C, N, E, k, S, D, A, j, L, _, H, M, q, O, F, P, B = "sizzle" + -new Date,
        W = e.document,
        R = 0,
        $ = 0,
        z = n(),
        I = n(),
        X = n(),
        U = function(e, t) {
            return e === t && (j = !0),
            0
        },
        V = "undefined",
        Y = 1 << 31,
        J = {}.hasOwnProperty,
        Q = [],
        G = Q.pop,
        K = Q.push,
        Z = Q.push,
        et = Q.slice,
        tt = Q.indexOf ||
        function(e) {
            for (var t = 0,
            n = this.length; n > t; t++) if (this[t] === e) return t;
            return - 1
        },
        nt = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
        rt = "[\\x20\\t\\r\\n\\f]",
        it = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
        ot = it.replace("w", "w#"),
        at = "\\[" + rt + "*(" + it + ")" + rt + "*(?:([*^$|!~]?=)" + rt + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + ot + ")|)|)" + rt + "*\\]",
        st = ":(" + it + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + at.replace(3, 8) + ")*)|.*)\\)|)",
        lt = new RegExp("^" + rt + "+|((?:^|[^\\\\])(?:\\\\.)*)" + rt + "+$", "g"),
        ut = new RegExp("^" + rt + "*," + rt + "*"),
        ct = new RegExp("^" + rt + "*([>+~]|" + rt + ")" + rt + "*"),
        dt = new RegExp("=" + rt + "*([^\\]'\"]*?)" + rt + "*\\]", "g"),
        ft = new RegExp(st),
        pt = new RegExp("^" + ot + "$"),
        ht = {
            ID: new RegExp("^#(" + it + ")"),
            CLASS: new RegExp("^\\.(" + it + ")"),
            TAG: new RegExp("^(" + it.replace("w", "w*") + ")"),
            ATTR: new RegExp("^" + at),
            PSEUDO: new RegExp("^" + st),
            CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + rt + "*(even|odd|(([+-]|)(\\d*)n|)" + rt + "*(?:([+-]|)" + rt + "*(\\d+)|))" + rt + "*\\)|)", "i"),
            bool: new RegExp("^(?:" + nt + ")$", "i"),
            needsContext: new RegExp("^" + rt + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + rt + "*((?:-\\d)?\\d*)" + rt + "*\\)|)(?=[^-]|$)", "i")
        },
        mt = /^(?:input|select|textarea|button)$/i,
        gt = /^h\d$/i,
        vt = /^[^{]+\{\s*\[native \w/,
        yt = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
        bt = /[+~]/,
        xt = /'|\\/g,
        wt = new RegExp("\\\\([\\da-f]{1,6}" + rt + "?|(" + rt + ")|.)", "ig"),
        Tt = function(e, t, n) {
            var r = "0x" + t - 65536;
            return r !== r || n ? t: 0 > r ? String.fromCharCode(r + 65536) : String.fromCharCode(r >> 10 | 55296, 1023 & r | 56320)
        };
        try {
            Z.apply(Q = et.call(W.childNodes), W.childNodes),
            Q[W.childNodes.length].nodeType
        } catch(Ct) {
            Z = {
                apply: Q.length ?
                function(e, t) {
                    K.apply(e, et.call(t))
                }: function(e, t) {
                    for (var n = e.length,
                    r = 0; e[n++] = t[r++];);
                    e.length = n - 1
                }
            }
        }
        C = t.support = {},
        k = t.isXML = function(e) {
            var t = e && (e.ownerDocument || e).documentElement;
            return t ? "HTML" !== t.nodeName: !1
        },
        L = t.setDocument = function(e) {
            var t, n = e ? e.ownerDocument || e: W,
            r = n.defaultView;
            return n !== _ && 9 === n.nodeType && n.documentElement ? (_ = n, H = n.documentElement, M = !k(n), r && r !== r.top && (r.addEventListener ? r.addEventListener("unload",
            function() {
                L()
            },
            !1) : r.attachEvent && r.attachEvent("onunload",
            function() {
                L()
            })), C.attributes = i(function(e) {
                return e.className = "i",
                !e.getAttribute("className")
            }), C.getElementsByTagName = i(function(e) {
                return e.appendChild(n.createComment("")),
                !e.getElementsByTagName("*").length
            }), C.getElementsByClassName = vt.test(n.getElementsByClassName) && i(function(e) {
                return e.innerHTML = "<div class='a'></div><div class='a i'></div>",
                e.firstChild.className = "i",
                2 === e.getElementsByClassName("i").length
            }), C.getById = i(function(e) {
                return H.appendChild(e).id = B,
                !n.getElementsByName || !n.getElementsByName(B).length
            }), C.getById ? (N.find.ID = function(e, t) {
                if (typeof t.getElementById !== V && M) {
                    var n = t.getElementById(e);
                    return n && n.parentNode ? [n] : []
                }
            },
            N.filter.ID = function(e) {
                var t = e.replace(wt, Tt);
                return function(e) {
                    return e.getAttribute("id") === t
                }
            }) : (delete N.find.ID, N.filter.ID = function(e) {
                var t = e.replace(wt, Tt);
                return function(e) {
                    var n = typeof e.getAttributeNode !== V && e.getAttributeNode("id");
                    return n && n.value === t
                }
            }), N.find.TAG = C.getElementsByTagName ?
            function(e, t) {
                return typeof t.getElementsByTagName !== V ? t.getElementsByTagName(e) : void 0
            }: function(e, t) {
                var n, r = [],
                i = 0,
                o = t.getElementsByTagName(e);
                if ("*" === e) {
                    for (; n = o[i++];) 1 === n.nodeType && r.push(n);
                    return r
                }
                return o
            },
            N.find.CLASS = C.getElementsByClassName &&
            function(e, t) {
                return typeof t.getElementsByClassName !== V && M ? t.getElementsByClassName(e) : void 0
            },
            O = [], q = [], (C.qsa = vt.test(n.querySelectorAll)) && (i(function(e) {
                e.innerHTML = "<select t=''><option selected=''></option></select>",
                e.querySelectorAll("[t^='']").length && q.push("[*^$]=" + rt + "*(?:''|\"\")"),
                e.querySelectorAll("[selected]").length || q.push("\\[" + rt + "*(?:value|" + nt + ")"),
                e.querySelectorAll(":checked").length || q.push(":checked")
            }), i(function(e) {
                var t = n.createElement("input");
                t.setAttribute("type", "hidden"),
                e.appendChild(t).setAttribute("name", "D"),
                e.querySelectorAll("[name=d]").length && q.push("name" + rt + "*[*^$|!~]?="),
                e.querySelectorAll(":enabled").length || q.push(":enabled", ":disabled"),
                e.querySelectorAll("*,:x"),
                q.push(",.*:")
            })), (C.matchesSelector = vt.test(F = H.webkitMatchesSelector || H.mozMatchesSelector || H.oMatchesSelector || H.msMatchesSelector)) && i(function(e) {
                C.disconnectedMatch = F.call(e, "div"),
                F.call(e, "[s!='']:x"),
                O.push("!=", st)
            }), q = q.length && new RegExp(q.join("|")), O = O.length && new RegExp(O.join("|")), t = vt.test(H.compareDocumentPosition), P = t || vt.test(H.contains) ?
            function(e, t) {
                var n = 9 === e.nodeType ? e.documentElement: e,
                r = t && t.parentNode;
                return e === r || !(!r || 1 !== r.nodeType || !(n.contains ? n.contains(r) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(r)))
            }: function(e, t) {
                if (t) for (; t = t.parentNode;) if (t === e) return ! 0;
                return ! 1
            },
            U = t ?
            function(e, t) {
                if (e === t) return j = !0,
                0;
                var r = !e.compareDocumentPosition - !t.compareDocumentPosition;
                return r ? r: (r = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1, 1 & r || !C.sortDetached && t.compareDocumentPosition(e) === r ? e === n || e.ownerDocument === W && P(W, e) ? -1 : t === n || t.ownerDocument === W && P(W, t) ? 1 : A ? tt.call(A, e) - tt.call(A, t) : 0 : 4 & r ? -1 : 1)
            }: function(e, t) {
                if (e === t) return j = !0,
                0;
                var r, i = 0,
                o = e.parentNode,
                s = t.parentNode,
                l = [e],
                u = [t];
                if (!o || !s) return e === n ? -1 : t === n ? 1 : o ? -1 : s ? 1 : A ? tt.call(A, e) - tt.call(A, t) : 0;
                if (o === s) return a(e, t);
                for (r = e; r = r.parentNode;) l.unshift(r);
                for (r = t; r = r.parentNode;) u.unshift(r);
                for (; l[i] === u[i];) i++;
                return i ? a(l[i], u[i]) : l[i] === W ? -1 : u[i] === W ? 1 : 0
            },
            n) : _
        },
        t.matches = function(e, n) {
            return t(e, null, null, n)
        },
        t.matchesSelector = function(e, n) {
            if ((e.ownerDocument || e) !== _ && L(e), n = n.replace(dt, "='$1']"), !(!C.matchesSelector || !M || O && O.test(n) || q && q.test(n))) try {
                var r = F.call(e, n);
                if (r || C.disconnectedMatch || e.document && 11 !== e.document.nodeType) return r
            } catch(i) {}
            return t(n, _, null, [e]).length > 0
        },
        t.contains = function(e, t) {
            return (e.ownerDocument || e) !== _ && L(e),
            P(e, t)
        },
        t.attr = function(e, t) { (e.ownerDocument || e) !== _ && L(e);
            var n = N.attrHandle[t.toLowerCase()],
            r = n && J.call(N.attrHandle, t.toLowerCase()) ? n(e, t, !M) : void 0;
            return void 0 !== r ? r: C.attributes || !M ? e.getAttribute(t) : (r = e.getAttributeNode(t)) && r.specified ? r.value: null
        },
        t.error = function(e) {
            throw new Error("Syntax error, unrecognized expression: " + e)
        },
        t.uniqueSort = function(e) {
            var t, n = [],
            r = 0,
            i = 0;
            if (j = !C.detectDuplicates, A = !C.sortStable && e.slice(0), e.sort(U), j) {
                for (; t = e[i++];) t === e[i] && (r = n.push(i));
                for (; r--;) e.splice(n[r], 1)
            }
            return A = null,
            e
        },
        E = t.getText = function(e) {
            var t, n = "",
            r = 0,
            i = e.nodeType;
            if (i) {
                if (1 === i || 9 === i || 11 === i) {
                    if ("string" == typeof e.textContent) return e.textContent;
                    for (e = e.firstChild; e; e = e.nextSibling) n += E(e)
                } else if (3 === i || 4 === i) return e.nodeValue
            } else for (; t = e[r++];) n += E(t);
            return n
        },
        N = t.selectors = {
            cacheLength: 50,
            createPseudo: r,
            match: ht,
            attrHandle: {},
            find: {},
            relative: {
                ">": {
                    dir: "parentNode",
                    first: !0
                },
                " ": {
                    dir: "parentNode"
                },
                "+": {
                    dir: "previousSibling",
                    first: !0
                },
                "~": {
                    dir: "previousSibling"
                }
            },
            preFilter: {
                ATTR: function(e) {
                    return e[1] = e[1].replace(wt, Tt),
                    e[3] = (e[4] || e[5] || "").replace(wt, Tt),
                    "~=" === e[2] && (e[3] = " " + e[3] + " "),
                    e.slice(0, 4)
                },
                CHILD: function(e) {
                    return e[1] = e[1].toLowerCase(),
                    "nth" === e[1].slice(0, 3) ? (e[3] || t.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && t.error(e[0]),
                    e
                },
                PSEUDO: function(e) {
                    var t, n = !e[5] && e[2];
                    return ht.CHILD.test(e[0]) ? null: (e[3] && void 0 !== e[4] ? e[2] = e[4] : n && ft.test(n) && (t = f(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                }
            },
            filter: {
                TAG: function(e) {
                    var t = e.replace(wt, Tt).toLowerCase();
                    return "*" === e ?
                    function() {
                        return ! 0
                    }: function(e) {
                        return e.nodeName && e.nodeName.toLowerCase() === t
                    }
                },
                CLASS: function(e) {
                    var t = z[e + " "];
                    return t || (t = new RegExp("(^|" + rt + ")" + e + "(" + rt + "|$)")) && z(e,
                    function(e) {
                        return t.test("string" == typeof e.className && e.className || typeof e.getAttribute !== V && e.getAttribute("class") || "")
                    })
                },
                ATTR: function(e, n, r) {
                    return function(i) {
                        var o = t.attr(i, e);
                        return null == o ? "!=" === n: n ? (o += "", "=" === n ? o === r: "!=" === n ? o !== r: "^=" === n ? r && 0 === o.indexOf(r) : "*=" === n ? r && o.indexOf(r) > -1 : "$=" === n ? r && o.slice( - r.length) === r: "~=" === n ? (" " + o + " ").indexOf(r) > -1 : "|=" === n ? o === r || o.slice(0, r.length + 1) === r + "-": !1) : !0
                    }
                },
                CHILD: function(e, t, n, r, i) {
                    var o = "nth" !== e.slice(0, 3),
                    a = "last" !== e.slice( - 4),
                    s = "of-type" === t;
                    return 1 === r && 0 === i ?
                    function(e) {
                        return !! e.parentNode
                    }: function(t, n, l) {
                        var u, c, d, f, p, h, m = o !== a ? "nextSibling": "previousSibling",
                        g = t.parentNode,
                        v = s && t.nodeName.toLowerCase(),
                        y = !l && !s;
                        if (g) {
                            if (o) {
                                for (; m;) {
                                    for (d = t; d = d[m];) if (s ? d.nodeName.toLowerCase() === v: 1 === d.nodeType) return ! 1;
                                    h = m = "only" === e && !h && "nextSibling"
                                }
                                return ! 0
                            }
                            if (h = [a ? g.firstChild: g.lastChild], a && y) {
                                for (c = g[B] || (g[B] = {}), u = c[e] || [], p = u[0] === R && u[1], f = u[0] === R && u[2], d = p && g.childNodes[p]; d = ++p && d && d[m] || (f = p = 0) || h.pop();) if (1 === d.nodeType && ++f && d === t) {
                                    c[e] = [R, p, f];
                                    break
                                }
                            } else if (y && (u = (t[B] || (t[B] = {}))[e]) && u[0] === R) f = u[1];
                            else for (; (d = ++p && d && d[m] || (f = p = 0) || h.pop()) && ((s ? d.nodeName.toLowerCase() !== v: 1 !== d.nodeType) || !++f || (y && ((d[B] || (d[B] = {}))[e] = [R, f]), d !== t)););
                            return f -= i,
                            f === r || f % r === 0 && f / r >= 0
                        }
                    }
                },
                PSEUDO: function(e, n) {
                    var i, o = N.pseudos[e] || N.setFilters[e.toLowerCase()] || t.error("unsupported pseudo: " + e);
                    return o[B] ? o(n) : o.length > 1 ? (i = [e, e, "", n], N.setFilters.hasOwnProperty(e.toLowerCase()) ? r(function(e, t) {
                        for (var r, i = o(e, n), a = i.length; a--;) r = tt.call(e, i[a]),
                        e[r] = !(t[r] = i[a])
                    }) : function(e) {
                        return o(e, 0, i)
                    }) : o
                }
            },
            pseudos: {
                not: r(function(e) {
                    var t = [],
                    n = [],
                    i = S(e.replace(lt, "$1"));
                    return i[B] ? r(function(e, t, n, r) {
                        for (var o, a = i(e, null, r, []), s = e.length; s--;)(o = a[s]) && (e[s] = !(t[s] = o))
                    }) : function(e, r, o) {
                        return t[0] = e,
                        i(t, null, o, n),
                        !n.pop()
                    }
                }),
                has: r(function(e) {
                    return function(n) {
                        return t(e, n).length > 0
                    }
                }),
                contains: r(function(e) {
                    return function(t) {
                        return (t.textContent || t.innerText || E(t)).indexOf(e) > -1
                    }
                }),
                lang: r(function(e) {
                    return pt.test(e || "") || t.error("unsupported lang: " + e),
                    e = e.replace(wt, Tt).toLowerCase(),
                    function(t) {
                        var n;
                        do
                        if (n = M ? t.lang: t.getAttribute("xml:lang") || t.getAttribute("lang")) return n = n.toLowerCase(),
                        n === e || 0 === n.indexOf(e + "-");
                        while ((t = t.parentNode) && 1 === t.nodeType);
                        return ! 1
                    }
                }),
                target: function(t) {
                    var n = e.location && e.location.hash;
                    return n && n.slice(1) === t.id
                },
                root: function(e) {
                    return e === H
                },
                focus: function(e) {
                    return e === _.activeElement && (!_.hasFocus || _.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                },
                enabled: function(e) {
                    return e.disabled === !1
                },
                disabled: function(e) {
                    return e.disabled === !0
                },
                checked: function(e) {
                    var t = e.nodeName.toLowerCase();
                    return "input" === t && !!e.checked || "option" === t && !!e.selected
                },
                selected: function(e) {
                    return e.parentNode && e.parentNode.selectedIndex,
                    e.selected === !0
                },
                empty: function(e) {
                    for (e = e.firstChild; e; e = e.nextSibling) if (e.nodeType < 6) return ! 1;
                    return ! 0
                },
                parent: function(e) {
                    return ! N.pseudos.empty(e)
                },
                header: function(e) {
                    return gt.test(e.nodeName)
                },
                input: function(e) {
                    return mt.test(e.nodeName)
                },
                button: function(e) {
                    var t = e.nodeName.toLowerCase();
                    return "input" === t && "button" === e.type || "button" === t
                },
                text: function(e) {
                    var t;
                    return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                },
                first: u(function() {
                    return [0]
                }),
                last: u(function(e, t) {
                    return [t - 1]
                }),
                eq: u(function(e, t, n) {
                    return [0 > n ? n + t: n]
                }),
                even: u(function(e, t) {
                    for (var n = 0; t > n; n += 2) e.push(n);
                    return e
                }),
                odd: u(function(e, t) {
                    for (var n = 1; t > n; n += 2) e.push(n);
                    return e
                }),
                lt: u(function(e, t, n) {
                    for (var r = 0 > n ? n + t: n; --r >= 0;) e.push(r);
                    return e
                }),
                gt: u(function(e, t, n) {
                    for (var r = 0 > n ? n + t: n; ++r < t;) e.push(r);
                    return e
                })
            }
        },
        N.pseudos.nth = N.pseudos.eq;
        for (T in {
            radio: !0,
            checkbox: !0,
            file: !0,
            password: !0,
            image: !0
        }) N.pseudos[T] = s(T);
        for (T in {
            submit: !0,
            reset: !0
        }) N.pseudos[T] = l(T);
        return d.prototype = N.filters = N.pseudos,
        N.setFilters = new d,
        S = t.compile = function(e, t) {
            var n, r = [],
            i = [],
            o = X[e + " "];
            if (!o) {
                for (t || (t = f(e)), n = t.length; n--;) o = y(t[n]),
                o[B] ? r.push(o) : i.push(o);
                o = X(e, b(i, r))
            }
            return o
        },
        C.sortStable = B.split("").sort(U).join("") === B,
        C.detectDuplicates = !!j,
        L(),
        C.sortDetached = i(function(e) {
            return 1 & e.compareDocumentPosition(_.createElement("div"))
        }),
        i(function(e) {
            return e.innerHTML = "<a href='#'></a>",
            "#" === e.firstChild.getAttribute("href")
        }) || o("type|href|height|width",
        function(e, t, n) {
            return n ? void 0 : e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
        }),
        C.attributes && i(function(e) {
            return e.innerHTML = "<input/>",
            e.firstChild.setAttribute("value", ""),
            "" === e.firstChild.getAttribute("value")
        }) || o("value",
        function(e, t, n) {
            return n || "input" !== e.nodeName.toLowerCase() ? void 0 : e.defaultValue
        }),
        i(function(e) {
            return null == e.getAttribute("disabled")
        }) || o(nt,
        function(e, t, n) {
            var r;
            return n ? void 0 : e[t] === !0 ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value: null
        }),
        t
    } (e);
    ot.find = ct,
    ot.expr = ct.selectors,
    ot.expr[":"] = ot.expr.pseudos,
    ot.unique = ct.uniqueSort,
    ot.text = ct.getText,
    ot.isXMLDoc = ct.isXML,
    ot.contains = ct.contains;
    var dt = ot.expr.match.needsContext,
    ft = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
    pt = /^.[^:#\[\.,]*$/;
    ot.filter = function(e, t, n) {
        var r = t[0];
        return n && (e = ":not(" + e + ")"),
        1 === t.length && 1 === r.nodeType ? ot.find.matchesSelector(r, e) ? [r] : [] : ot.find.matches(e, ot.grep(t,
        function(e) {
            return 1 === e.nodeType
        }))
    },
    ot.fn.extend({
        find: function(e) {
            var t, n = [],
            r = this,
            i = r.length;
            if ("string" != typeof e) return this.pushStack(ot(e).filter(function() {
                for (t = 0; i > t; t++) if (ot.contains(r[t], this)) return ! 0
            }));
            for (t = 0; i > t; t++) ot.find(e, r[t], n);
            return n = this.pushStack(i > 1 ? ot.unique(n) : n),
            n.selector = this.selector ? this.selector + " " + e: e,
            n
        },
        filter: function(e) {
            return this.pushStack(r(this, e || [], !1))
        },
        not: function(e) {
            return this.pushStack(r(this, e || [], !0))
        },
        is: function(e) {
            return !! r(this, "string" == typeof e && dt.test(e) ? ot(e) : e || [], !1).length
        }
    });
    var ht, mt = e.document,
    gt = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
    vt = ot.fn.init = function(e, t) {
        var n, r;
        if (!e) return this;
        if ("string" == typeof e) {
            if (n = "<" === e.charAt(0) && ">" === e.charAt(e.length - 1) && e.length >= 3 ? [null, e, null] : gt.exec(e), !n || !n[1] && t) return ! t || t.jquery ? (t || ht).find(e) : this.constructor(t).find(e);
            if (n[1]) {
                if (t = t instanceof ot ? t[0] : t, ot.merge(this, ot.parseHTML(n[1], t && t.nodeType ? t.ownerDocument || t: mt, !0)), ft.test(n[1]) && ot.isPlainObject(t)) for (n in t) ot.isFunction(this[n]) ? this[n](t[n]) : this.attr(n, t[n]);
                return this
            }
            if (r = mt.getElementById(n[2]), r && r.parentNode) {
                if (r.id !== n[2]) return ht.find(e);
                this.length = 1,
                this[0] = r
            }
            return this.context = mt,
            this.selector = e,
            this
        }
        return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : ot.isFunction(e) ? "undefined" != typeof ht.ready ? ht.ready(e) : e(ot) : (void 0 !== e.selector && (this.selector = e.selector, this.context = e.context), ot.makeArray(e, this))
    };
    vt.prototype = ot.fn,
    ht = ot(mt);
    var yt = /^(?:parents|prev(?:Until|All))/,
    bt = {
        children: !0,
        contents: !0,
        next: !0,
        prev: !0
    };
    ot.extend({
        dir: function(e, t, n) {
            for (var r = [], i = e[t]; i && 9 !== i.nodeType && (void 0 === n || 1 !== i.nodeType || !ot(i).is(n));) 1 === i.nodeType && r.push(i),
            i = i[t];
            return r
        },
        sibling: function(e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        }
    }),
    ot.fn.extend({
        has: function(e) {
            var t, n = ot(e, this),
            r = n.length;
            return this.filter(function() {
                for (t = 0; r > t; t++) if (ot.contains(this, n[t])) return ! 0
            })
        },
        closest: function(e, t) {
            for (var n, r = 0,
            i = this.length,
            o = [], a = dt.test(e) || "string" != typeof e ? ot(e, t || this.context) : 0; i > r; r++) for (n = this[r]; n && n !== t; n = n.parentNode) if (n.nodeType < 11 && (a ? a.index(n) > -1 : 1 === n.nodeType && ot.find.matchesSelector(n, e))) {
                o.push(n);
                break
            }
            return this.pushStack(o.length > 1 ? ot.unique(o) : o)
        },
        index: function(e) {
            return e ? "string" == typeof e ? ot.inArray(this[0], ot(e)) : ot.inArray(e.jquery ? e[0] : e, this) : this[0] && this[0].parentNode ? this.first().prevAll().length: -1
        },
        add: function(e, t) {
            return this.pushStack(ot.unique(ot.merge(this.get(), ot(e, t))))
        },
        addBack: function(e) {
            return this.add(null == e ? this.prevObject: this.prevObject.filter(e))
        }
    }),
    ot.each({
        parent: function(e) {
            var t = e.parentNode;
            return t && 11 !== t.nodeType ? t: null
        },
        parents: function(e) {
            return ot.dir(e, "parentNode")
        },
        parentsUntil: function(e, t, n) {
            return ot.dir(e, "parentNode", n)
        },
        next: function(e) {
            return i(e, "nextSibling")
        },
        prev: function(e) {
            return i(e, "previousSibling")
        },
        nextAll: function(e) {
            return ot.dir(e, "nextSibling")
        },
        prevAll: function(e) {
            return ot.dir(e, "previousSibling")
        },
        nextUntil: function(e, t, n) {
            return ot.dir(e, "nextSibling", n)
        },
        prevUntil: function(e, t, n) {
            return ot.dir(e, "previousSibling", n)
        },
        siblings: function(e) {
            return ot.sibling((e.parentNode || {}).firstChild, e)
        },
        children: function(e) {
            return ot.sibling(e.firstChild)
        },
        contents: function(e) {
            return ot.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document: ot.merge([], e.childNodes)
        }
    },
    function(e, t) {
        ot.fn[e] = function(n, r) {
            var i = ot.map(this, t, n);
            return "Until" !== e.slice( - 5) && (r = n),
            r && "string" == typeof r && (i = ot.filter(r, i)),
            this.length > 1 && (bt[e] || (i = ot.unique(i)), yt.test(e) && (i = i.reverse())),
            this.pushStack(i)
        }
    });
    var xt = /\S+/g,
    wt = {};
    ot.Callbacks = function(e) {
        e = "string" == typeof e ? wt[e] || o(e) : ot.extend({},
        e);
        var t, n, r, i, a, s, l = [],
        u = !e.once && [],
        c = function(o) {
            for (n = e.memory && o, r = !0, a = s || 0, s = 0, i = l.length, t = !0; l && i > a; a++) if (l[a].apply(o[0], o[1]) === !1 && e.stopOnFalse) {
                n = !1;
                break
            }
            t = !1,
            l && (u ? u.length && c(u.shift()) : n ? l = [] : d.disable())
        },
        d = {
            add: function() {
                if (l) {
                    var r = l.length; !
                    function o(t) {
                        ot.each(t,
                        function(t, n) {
                            var r = ot.type(n);
                            "function" === r ? e.unique && d.has(n) || l.push(n) : n && n.length && "string" !== r && o(n)
                        })
                    } (arguments),
                    t ? i = l.length: n && (s = r, c(n))
                }
                return this
            },
            remove: function() {
                return l && ot.each(arguments,
                function(e, n) {
                    for (var r; (r = ot.inArray(n, l, r)) > -1;) l.splice(r, 1),
                    t && (i >= r && i--, a >= r && a--)
                }),
                this
            },
            has: function(e) {
                return e ? ot.inArray(e, l) > -1 : !(!l || !l.length)
            },
            empty: function() {
                return l = [],
                i = 0,
                this
            },
            disable: function() {
                return l = u = n = void 0,
                this
            },
            disabled: function() {
                return ! l
            },
            lock: function() {
                return u = void 0,
                n || d.disable(),
                this
            },
            locked: function() {
                return ! u
            },
            fireWith: function(e, n) {
                return ! l || r && !u || (n = n || [], n = [e, n.slice ? n.slice() : n], t ? u.push(n) : c(n)),
                this
            },
            fire: function() {
                return d.fireWith(this, arguments),
                this
            },
            fired: function() {
                return !! r
            }
        };
        return d
    },
    ot.extend({
        Deferred: function(e) {
            var t = [["resolve", "done", ot.Callbacks("once memory"), "resolved"], ["reject", "fail", ot.Callbacks("once memory"), "rejected"], ["notify", "progress", ot.Callbacks("memory")]],
            n = "pending",
            r = {
                state: function() {
                    return n
                },
                always: function() {
                    return i.done(arguments).fail(arguments),
                    this
                },
                then: function() {
                    var e = arguments;
                    return ot.Deferred(function(n) {
                        ot.each(t,
                        function(t, o) {
                            var a = ot.isFunction(e[t]) && e[t];
                            i[o[1]](function() {
                                var e = a && a.apply(this, arguments);
                                e && ot.isFunction(e.promise) ? e.promise().done(n.resolve).fail(n.reject).progress(n.notify) : n[o[0] + "With"](this === r ? n.promise() : this, a ? [e] : arguments)
                            })
                        }),
                        e = null
                    }).promise()
                },
                promise: function(e) {
                    return null != e ? ot.extend(e, r) : r
                }
            },
            i = {};
            return r.pipe = r.then,
            ot.each(t,
            function(e, o) {
                var a = o[2],
                s = o[3];
                r[o[1]] = a.add,
                s && a.add(function() {
                    n = s
                },
                t[1 ^ e][2].disable, t[2][2].lock),
                i[o[0]] = function() {
                    return i[o[0] + "With"](this === i ? r: this, arguments),
                    this
                },
                i[o[0] + "With"] = a.fireWith
            }),
            r.promise(i),
            e && e.call(i, i),
            i
        },
        when: function(e) {
            var t, n, r, i = 0,
            o = J.call(arguments),
            a = o.length,
            s = 1 !== a || e && ot.isFunction(e.promise) ? a: 0,
            l = 1 === s ? e: ot.Deferred(),
            u = function(e, n, r) {
                return function(i) {
                    n[e] = this,
                    r[e] = arguments.length > 1 ? J.call(arguments) : i,
                    r === t ? l.notifyWith(n, r) : --s || l.resolveWith(n, r)
                }
            };
            if (a > 1) for (t = new Array(a), n = new Array(a), r = new Array(a); a > i; i++) o[i] && ot.isFunction(o[i].promise) ? o[i].promise().done(u(i, r, o)).fail(l.reject).progress(u(i, n, t)) : --s;
            return s || l.resolveWith(r, o),
            l.promise()
        }
    });
    var Tt;
    ot.fn.ready = function(e) {
        return ot.ready.promise().done(e),
        this
    },
    ot.extend({
        isReady: !1,
        readyWait: 1,
        holdReady: function(e) {
            e ? ot.readyWait++:ot.ready(!0)
        },
        ready: function(e) {
            if (e === !0 ? !--ot.readyWait: !ot.isReady) {
                if (!mt.body) return setTimeout(ot.ready);
                ot.isReady = !0,
                e !== !0 && --ot.readyWait > 0 || (Tt.resolveWith(mt, [ot]), ot.fn.trigger && ot(mt).trigger("ready").off("ready"))
            }
        }
    }),
    ot.ready.promise = function(t) {
        if (!Tt) if (Tt = ot.Deferred(), "complete" === mt.readyState) setTimeout(ot.ready);
        else if (mt.addEventListener) mt.addEventListener("DOMContentLoaded", s, !1),
        e.addEventListener("load", s, !1);
        else {
            mt.attachEvent("onreadystatechange", s),
            e.attachEvent("onload", s);
            var n = !1;
            try {
                n = null == e.frameElement && mt.documentElement
            } catch(r) {}
            n && n.doScroll && !
            function i() {
                if (!ot.isReady) {
                    try {
                        n.doScroll("left")
                    } catch(e) {
                        return setTimeout(i, 50)
                    }
                    a(),
                    ot.ready()
                }
            } ()
        }
        return Tt.promise(t)
    };
    var Ct, Nt = "undefined";
    for (Ct in ot(rt)) break;
    rt.ownLast = "0" !== Ct,
    rt.inlineBlockNeedsLayout = !1,
    ot(function() {
        var e, t, n = mt.getElementsByTagName("body")[0];
        n && (e = mt.createElement("div"), e.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px", t = mt.createElement("div"), n.appendChild(e).appendChild(t), typeof t.style.zoom !== Nt && (t.style.cssText = "border:0;margin:0;width:1px;padding:1px;display:inline;zoom:1", (rt.inlineBlockNeedsLayout = 3 === t.offsetWidth) && (n.style.zoom = 1)), n.removeChild(e), e = t = null)
    }),
    function() {
        var e = mt.createElement("div");
        if (null == rt.deleteExpando) {
            rt.deleteExpando = !0;
            try {
                delete e.test
            } catch(t) {
                rt.deleteExpando = !1
            }
        }
        e = null
    } (),
    ot.acceptData = function(e) {
        var t = ot.noData[(e.nodeName + " ").toLowerCase()],
        n = +e.nodeType || 1;
        return 1 !== n && 9 !== n ? !1 : !t || t !== !0 && e.getAttribute("classid") === t
    };
    var Et = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
    kt = /([A-Z])/g;
    ot.extend({
        cache: {},
        noData: {
            "applet ": !0,
            "embed ": !0,
            "object ": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
        },
        hasData: function(e) {
            return e = e.nodeType ? ot.cache[e[ot.expando]] : e[ot.expando],
            !!e && !u(e)
        },
        data: function(e, t, n) {
            return c(e, t, n)
        },
        removeData: function(e, t) {
            return d(e, t)
        },
        _data: function(e, t, n) {
            return c(e, t, n, !0)
        },
        _removeData: function(e, t) {
            return d(e, t, !0)
        }
    }),
    ot.fn.extend({
        data: function(e, t) {
            var n, r, i, o = this[0],
            a = o && o.attributes;
            if (void 0 === e) {
                if (this.length && (i = ot.data(o), 1 === o.nodeType && !ot._data(o, "parsedAttrs"))) {
                    for (n = a.length; n--;) r = a[n].name,
                    0 === r.indexOf("data-") && (r = ot.camelCase(r.slice(5)), l(o, r, i[r]));
                    ot._data(o, "parsedAttrs", !0)
                }
                return i
            }
            return "object" == typeof e ? this.each(function() {
                ot.data(this, e)
            }) : arguments.length > 1 ? this.each(function() {
                ot.data(this, e, t)
            }) : o ? l(o, e, ot.data(o, e)) : void 0
        },
        removeData: function(e) {
            return this.each(function() {
                ot.removeData(this, e)
            })
        }
    }),
    ot.extend({
        queue: function(e, t, n) {
            var r;
            return e ? (t = (t || "fx") + "queue", r = ot._data(e, t), n && (!r || ot.isArray(n) ? r = ot._data(e, t, ot.makeArray(n)) : r.push(n)), r || []) : void 0
        },
        dequeue: function(e, t) {
            t = t || "fx";
            var n = ot.queue(e, t),
            r = n.length,
            i = n.shift(),
            o = ot._queueHooks(e, t),
            a = function() {
                ot.dequeue(e, t)
            };
            "inprogress" === i && (i = n.shift(), r--),
            i && ("fx" === t && n.unshift("inprogress"), delete o.stop, i.call(e, a, o)),
            !r && o && o.empty.fire()
        },
        _queueHooks: function(e, t) {
            var n = t + "queueHooks";
            return ot._data(e, n) || ot._data(e, n, {
                empty: ot.Callbacks("once memory").add(function() {
                    ot._removeData(e, t + "queue"),
                    ot._removeData(e, n)
                })
            })
        }
    }),
    ot.fn.extend({
        queue: function(e, t) {
            var n = 2;
            return "string" != typeof e && (t = e, e = "fx", n--),
            arguments.length < n ? ot.queue(this[0], e) : void 0 === t ? this: this.each(function() {
                var n = ot.queue(this, e, t);
                ot._queueHooks(this, e),
                "fx" === e && "inprogress" !== n[0] && ot.dequeue(this, e)
            })
        },
        dequeue: function(e) {
            return this.each(function() {
                ot.dequeue(this, e)
            })
        },
        clearQueue: function(e) {
            return this.queue(e || "fx", [])
        },
        promise: function(e, t) {
            var n, r = 1,
            i = ot.Deferred(),
            o = this,
            a = this.length,
            s = function() {--r || i.resolveWith(o, [o])
            };
            for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; a--;) n = ot._data(o[a], e + "queueHooks"),
            n && n.empty && (r++, n.empty.add(s));
            return s(),
            i.promise(t)
        }
    });
    var St = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
    Dt = ["Top", "Right", "Bottom", "Left"],
    At = function(e, t) {
        return e = t || e,
        "none" === ot.css(e, "display") || !ot.contains(e.ownerDocument, e)
    },
    jt = ot.access = function(e, t, n, r, i, o, a) {
        var s = 0,
        l = e.length,
        u = null == n;
        if ("object" === ot.type(n)) {
            i = !0;
            for (s in n) ot.access(e, t, s, n[s], !0, o, a)
        } else if (void 0 !== r && (i = !0, ot.isFunction(r) || (a = !0), u && (a ? (t.call(e, r), t = null) : (u = t, t = function(e, t, n) {
            return u.call(ot(e), n)
        })), t)) for (; l > s; s++) t(e[s], n, a ? r: r.call(e[s], s, t(e[s], n)));
        return i ? e: u ? t.call(e) : l ? t(e[0], n) : o
    },
    Lt = /^(?:checkbox|radio)$/i; !
    function() {
        var e = mt.createDocumentFragment(),
        t = mt.createElement("div"),
        n = mt.createElement("input");
        if (t.setAttribute("className", "t"), t.innerHTML = "  <link/><table></table><a href='/a'>a</a>", rt.leadingWhitespace = 3 === t.firstChild.nodeType, rt.tbody = !t.getElementsByTagName("tbody").length, rt.htmlSerialize = !!t.getElementsByTagName("link").length, rt.html5Clone = "<:nav></:nav>" !== mt.createElement("nav").cloneNode(!0).outerHTML, n.type = "checkbox", n.checked = !0, e.appendChild(n), rt.appendChecked = n.checked, t.innerHTML = "<textarea>x</textarea>", rt.noCloneChecked = !!t.cloneNode(!0).lastChild.defaultValue, e.appendChild(t), t.innerHTML = "<input type='radio' checked='checked' name='t'/>", rt.checkClone = t.cloneNode(!0).cloneNode(!0).lastChild.checked, rt.noCloneEvent = !0, t.attachEvent && (t.attachEvent("onclick",
        function() {
            rt.noCloneEvent = !1
        }), t.cloneNode(!0).click()), null == rt.deleteExpando) {
            rt.deleteExpando = !0;
            try {
                delete t.test
            } catch(r) {
                rt.deleteExpando = !1
            }
        }
        e = t = n = null
    } (),
    function() {
        var t, n, r = mt.createElement("div");
        for (t in {
            submit: !0,
            change: !0,
            focusin: !0
        }) n = "on" + t,
        (rt[t + "Bubbles"] = n in e) || (r.setAttribute(n, "t"), rt[t + "Bubbles"] = r.attributes[n].expando === !1);
        r = null
    } ();
    var _t = /^(?:input|select|textarea)$/i,
    Ht = /^key/,
    Mt = /^(?:mouse|contextmenu)|click/,
    qt = /^(?:focusinfocus|focusoutblur)$/,
    Ot = /^([^.]*)(?:\.(.+)|)$/;
    ot.event = {
        global: {},
        add: function(e, t, n, r, i) {
            var o, a, s, l, u, c, d, f, p, h, m, g = ot._data(e);
            if (g) {
                for (n.handler && (l = n, n = l.handler, i = l.selector), n.guid || (n.guid = ot.guid++), (a = g.events) || (a = g.events = {}), (c = g.handle) || (c = g.handle = function(e) {
                    return typeof ot === Nt || e && ot.event.triggered === e.type ? void 0 : ot.event.dispatch.apply(c.elem, arguments)
                },
                c.elem = e), t = (t || "").match(xt) || [""], s = t.length; s--;) o = Ot.exec(t[s]) || [],
                p = m = o[1],
                h = (o[2] || "").split(".").sort(),
                p && (u = ot.event.special[p] || {},
                p = (i ? u.delegateType: u.bindType) || p, u = ot.event.special[p] || {},
                d = ot.extend({
                    type: p,
                    origType: m,
                    data: r,
                    handler: n,
                    guid: n.guid,
                    selector: i,
                    needsContext: i && ot.expr.match.needsContext.test(i),
                    namespace: h.join(".")
                },
                l), (f = a[p]) || (f = a[p] = [], f.delegateCount = 0, u.setup && u.setup.call(e, r, h, c) !== !1 || (e.addEventListener ? e.addEventListener(p, c, !1) : e.attachEvent && e.attachEvent("on" + p, c))), u.add && (u.add.call(e, d), d.handler.guid || (d.handler.guid = n.guid)), i ? f.splice(f.delegateCount++, 0, d) : f.push(d), ot.event.global[p] = !0);
                e = null
            }
        },
        remove: function(e, t, n, r, i) {
            var o, a, s, l, u, c, d, f, p, h, m, g = ot.hasData(e) && ot._data(e);
            if (g && (c = g.events)) {
                for (t = (t || "").match(xt) || [""], u = t.length; u--;) if (s = Ot.exec(t[u]) || [], p = m = s[1], h = (s[2] || "").split(".").sort(), p) {
                    for (d = ot.event.special[p] || {},
                    p = (r ? d.delegateType: d.bindType) || p, f = c[p] || [], s = s[2] && new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)"), l = o = f.length; o--;) a = f[o],
                    !i && m !== a.origType || n && n.guid !== a.guid || s && !s.test(a.namespace) || r && r !== a.selector && ("**" !== r || !a.selector) || (f.splice(o, 1), a.selector && f.delegateCount--, d.remove && d.remove.call(e, a));
                    l && !f.length && (d.teardown && d.teardown.call(e, h, g.handle) !== !1 || ot.removeEvent(e, p, g.handle), delete c[p])
                } else for (p in c) ot.event.remove(e, p + t[u], n, r, !0);
                ot.isEmptyObject(c) && (delete g.handle, ot._removeData(e, "events"))
            }
        },
        trigger: function(t, n, r, i) {
            var o, a, s, l, u, c, d, f = [r || mt],
            p = tt.call(t, "type") ? t.type: t,
            h = tt.call(t, "namespace") ? t.namespace.split(".") : [];
            if (s = c = r = r || mt, 3 !== r.nodeType && 8 !== r.nodeType && !qt.test(p + ot.event.triggered) && (p.indexOf(".") >= 0 && (h = p.split("."), p = h.shift(), h.sort()), a = p.indexOf(":") < 0 && "on" + p, t = t[ot.expando] ? t: new ot.Event(p, "object" == typeof t && t), t.isTrigger = i ? 2 : 3, t.namespace = h.join("."), t.namespace_re = t.namespace ? new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t.result = void 0, t.target || (t.target = r), n = null == n ? [t] : ot.makeArray(n, [t]), u = ot.event.special[p] || {},
            i || !u.trigger || u.trigger.apply(r, n) !== !1)) {
                if (!i && !u.noBubble && !ot.isWindow(r)) {
                    for (l = u.delegateType || p, qt.test(l + p) || (s = s.parentNode); s; s = s.parentNode) f.push(s),
                    c = s;
                    c === (r.ownerDocument || mt) && f.push(c.defaultView || c.parentWindow || e)
                }
                for (d = 0; (s = f[d++]) && !t.isPropagationStopped();) t.type = d > 1 ? l: u.bindType || p,
                o = (ot._data(s, "events") || {})[t.type] && ot._data(s, "handle"),
                o && o.apply(s, n),
                o = a && s[a],
                o && o.apply && ot.acceptData(s) && (t.result = o.apply(s, n), t.result === !1 && t.preventDefault());
                if (t.type = p, !i && !t.isDefaultPrevented() && (!u._default || u._default.apply(f.pop(), n) === !1) && ot.acceptData(r) && a && r[p] && !ot.isWindow(r)) {
                    c = r[a],
                    c && (r[a] = null),
                    ot.event.triggered = p;
                    try {
                        r[p]()
                    } catch(m) {}
                    ot.event.triggered = void 0,
                    c && (r[a] = c)
                }
                return t.result
            }
        },
        dispatch: function(e) {
            e = ot.event.fix(e);
            var t, n, r, i, o, a = [],
            s = J.call(arguments),
            l = (ot._data(this, "events") || {})[e.type] || [],
            u = ot.event.special[e.type] || {};
            if (s[0] = e, e.delegateTarget = this, !u.preDispatch || u.preDispatch.call(this, e) !== !1) {
                for (a = ot.event.handlers.call(this, e, l), t = 0; (i = a[t++]) && !e.isPropagationStopped();) for (e.currentTarget = i.elem, o = 0; (r = i.handlers[o++]) && !e.isImmediatePropagationStopped();)(!e.namespace_re || e.namespace_re.test(r.namespace)) && (e.handleObj = r, e.data = r.data, n = ((ot.event.special[r.origType] || {}).handle || r.handler).apply(i.elem, s), void 0 !== n && (e.result = n) === !1 && (e.preventDefault(), e.stopPropagation()));
                return u.postDispatch && u.postDispatch.call(this, e),
                e.result
            }
        },
        handlers: function(e, t) {
            var n, r, i, o, a = [],
            s = t.delegateCount,
            l = e.target;
            if (s && l.nodeType && (!e.button || "click" !== e.type)) for (; l != this; l = l.parentNode || this) if (1 === l.nodeType && (l.disabled !== !0 || "click" !== e.type)) {
                for (i = [], o = 0; s > o; o++) r = t[o],
                n = r.selector + " ",
                void 0 === i[n] && (i[n] = r.needsContext ? ot(n, this).index(l) >= 0 : ot.find(n, this, null, [l]).length),
                i[n] && i.push(r);
                i.length && a.push({
                    elem: l,
                    handlers: i
                })
            }
            return s < t.length && a.push({
                elem: this,
                handlers: t.slice(s)
            }),
            a
        },
        fix: function(e) {
            if (e[ot.expando]) return e;
            var t, n, r, i = e.type,
            o = e,
            a = this.fixHooks[i];
            for (a || (this.fixHooks[i] = a = Mt.test(i) ? this.mouseHooks: Ht.test(i) ? this.keyHooks: {}), r = a.props ? this.props.concat(a.props) : this.props, e = new ot.Event(o), t = r.length; t--;) n = r[t],
            e[n] = o[n];
            return e.target || (e.target = o.srcElement || mt),
            3 === e.target.nodeType && (e.target = e.target.parentNode),
            e.metaKey = !!e.metaKey,
            a.filter ? a.filter(e, o) : e
        },
        props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function(e, t) {
                return null == e.which && (e.which = null != t.charCode ? t.charCode: t.keyCode),
                e
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function(e, t) {
                var n, r, i, o = t.button,
                a = t.fromElement;
                return null == e.pageX && null != t.clientX && (r = e.target.ownerDocument || mt, i = r.documentElement, n = r.body, e.pageX = t.clientX + (i && i.scrollLeft || n && n.scrollLeft || 0) - (i && i.clientLeft || n && n.clientLeft || 0), e.pageY = t.clientY + (i && i.scrollTop || n && n.scrollTop || 0) - (i && i.clientTop || n && n.clientTop || 0)),
                !e.relatedTarget && a && (e.relatedTarget = a === e.target ? t.toElement: a),
                e.which || void 0 === o || (e.which = 1 & o ? 1 : 2 & o ? 3 : 4 & o ? 2 : 0),
                e
            }
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                trigger: function() {
                    if (this !== h() && this.focus) try {
                        return this.focus(),
                        !1
                    } catch(e) {}
                },
                delegateType: "focusin"
            },
            blur: {
                trigger: function() {
                    return this === h() && this.blur ? (this.blur(), !1) : void 0
                },
                delegateType: "focusout"
            },
            click: {
                trigger: function() {
                    return ot.nodeName(this, "input") && "checkbox" === this.type && this.click ? (this.click(), !1) : void 0
                },
                _default: function(e) {
                    return ot.nodeName(e.target, "a")
                }
            },
            beforeunload: {
                postDispatch: function(e) {
                    void 0 !== e.result && (e.originalEvent.returnValue = e.result)
                }
            }
        },
        simulate: function(e, t, n, r) {
            var i = ot.extend(new ot.Event, n, {
                type: e,
                isSimulated: !0,
                originalEvent: {}
            });
            r ? ot.event.trigger(i, null, t) : ot.event.dispatch.call(t, i),
            i.isDefaultPrevented() && n.preventDefault()
        }
    },
    ot.removeEvent = mt.removeEventListener ?
    function(e, t, n) {
        e.removeEventListener && e.removeEventListener(t, n, !1)
    }: function(e, t, n) {
        var r = "on" + t;
        e.detachEvent && (typeof e[r] === Nt && (e[r] = null), e.detachEvent(r, n))
    },
    ot.Event = function(e, t) {
        return this instanceof ot.Event ? (e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && (e.returnValue === !1 || e.getPreventDefault && e.getPreventDefault()) ? f: p) : this.type = e, t && ot.extend(this, t), this.timeStamp = e && e.timeStamp || ot.now(), void(this[ot.expando] = !0)) : new ot.Event(e, t)
    },
    ot.Event.prototype = {
        isDefaultPrevented: p,
        isPropagationStopped: p,
        isImmediatePropagationStopped: p,
        preventDefault: function() {
            var e = this.originalEvent;
            this.isDefaultPrevented = f,
            e && (e.preventDefault ? e.preventDefault() : e.returnValue = !1)
        },
        stopPropagation: function() {
            var e = this.originalEvent;
            this.isPropagationStopped = f,
            e && (e.stopPropagation && e.stopPropagation(), e.cancelBubble = !0)
        },
        stopImmediatePropagation: function() {
            this.isImmediatePropagationStopped = f,
            this.stopPropagation()
        }
    },
    ot.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    },
    function(e, t) {
        ot.event.special[e] = {
            delegateType: t,
            bindType: t,
            handle: function(e) {
                var n, r = this,
                i = e.relatedTarget,
                o = e.handleObj;
                return (!i || i !== r && !ot.contains(r, i)) && (e.type = o.origType, n = o.handler.apply(this, arguments), e.type = t),
                n
            }
        }
    }),
    rt.submitBubbles || (ot.event.special.submit = {
        setup: function() {
            return ot.nodeName(this, "form") ? !1 : void ot.event.add(this, "click._submit keypress._submit",
            function(e) {
                var t = e.target,
                n = ot.nodeName(t, "input") || ot.nodeName(t, "button") ? t.form: void 0;
                n && !ot._data(n, "submitBubbles") && (ot.event.add(n, "submit._submit",
                function(e) {
                    e._submit_bubble = !0
                }), ot._data(n, "submitBubbles", !0))
            })
        },
        postDispatch: function(e) {
            e._submit_bubble && (delete e._submit_bubble, this.parentNode && !e.isTrigger && ot.event.simulate("submit", this.parentNode, e, !0))
        },
        teardown: function() {
            return ot.nodeName(this, "form") ? !1 : void ot.event.remove(this, "._submit")
        }
    }),
    rt.changeBubbles || (ot.event.special.change = {
        setup: function() {
            return _t.test(this.nodeName) ? (("checkbox" === this.type || "radio" === this.type) && (ot.event.add(this, "propertychange._change",
            function(e) {
                "checked" === e.originalEvent.propertyName && (this._just_changed = !0)
            }), ot.event.add(this, "click._change",
            function(e) {
                this._just_changed && !e.isTrigger && (this._just_changed = !1),
                ot.event.simulate("change", this, e, !0)
            })), !1) : void ot.event.add(this, "beforeactivate._change",
            function(e) {
                var t = e.target;
                _t.test(t.nodeName) && !ot._data(t, "changeBubbles") && (ot.event.add(t, "change._change",
                function(e) { ! this.parentNode || e.isSimulated || e.isTrigger || ot.event.simulate("change", this.parentNode, e, !0)
                }), ot._data(t, "changeBubbles", !0))
            })
        },
        handle: function(e) {
            var t = e.target;
            return this !== t || e.isSimulated || e.isTrigger || "radio" !== t.type && "checkbox" !== t.type ? e.handleObj.handler.apply(this, arguments) : void 0
        },
        teardown: function() {
            return ot.event.remove(this, "._change"),
            !_t.test(this.nodeName)
        }
    }),
    rt.focusinBubbles || ot.each({
        focus: "focusin",
        blur: "focusout"
    },
    function(e, t) {
        var n = function(e) {
            ot.event.simulate(t, e.target, ot.event.fix(e), !0)
        };
        ot.event.special[t] = {
            setup: function() {
                var r = this.ownerDocument || this,
                i = ot._data(r, t);
                i || r.addEventListener(e, n, !0),
                ot._data(r, t, (i || 0) + 1)
            },
            teardown: function() {
                var r = this.ownerDocument || this,
                i = ot._data(r, t) - 1;
                i ? ot._data(r, t, i) : (r.removeEventListener(e, n, !0), ot._removeData(r, t))
            }
        }
    }),
    ot.fn.extend({
        on: function(e, t, n, r, i) {
            var o, a;
            if ("object" == typeof e) {
                "string" != typeof t && (n = n || t, t = void 0);
                for (o in e) this.on(o, t, n, e[o], i);
                return this
            }
            if (null == n && null == r ? (r = t, n = t = void 0) : null == r && ("string" == typeof t ? (r = n, n = void 0) : (r = n, n = t, t = void 0)), r === !1) r = p;
            else if (!r) return this;
            return 1 === i && (a = r, r = function(e) {
                return ot().off(e),
                a.apply(this, arguments)
            },
            r.guid = a.guid || (a.guid = ot.guid++)),
            this.each(function() {
                ot.event.add(this, e, r, n, t)
            })
        },
        one: function(e, t, n, r) {
            return this.on(e, t, n, r, 1)
        },
        off: function(e, t, n) {
            var r, i;
            if (e && e.preventDefault && e.handleObj) return r = e.handleObj,
            ot(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace: r.origType, r.selector, r.handler),
            this;
            if ("object" == typeof e) {
                for (i in e) this.off(i, t, e[i]);
                return this
            }
            return (t === !1 || "function" == typeof t) && (n = t, t = void 0),
            n === !1 && (n = p),
            this.each(function() {
                ot.event.remove(this, e, n, t)
            })
        },
        trigger: function(e, t) {
            return this.each(function() {
                ot.event.trigger(e, t, this)
            })
        },
        triggerHandler: function(e, t) {
            var n = this[0];
            return n ? ot.event.trigger(e, t, n, !0) : void 0
        }
    });
    var Ft = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
    Pt = / jQuery\d+="(?:null|\d+)"/g,
    Bt = new RegExp("<(?:" + Ft + ")[\\s/>]", "i"),
    Wt = /^\s+/,
    Rt = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
    $t = /<([\w:]+)/,
    zt = /<tbody/i,
    It = /<|&#?\w+;/,
    Xt = /<(?:script|style|link)/i,
    Ut = /checked\s*(?:[^=]|=\s*.checked.)/i,
    Vt = /^$|\/(?:java|ecma)script/i,
    Yt = /^true\/(.*)/,
    Jt = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
    Qt = {
        option: [1, "<select multiple='multiple'>", "</select>"],
        legend: [1, "<fieldset>", "</fieldset>"],
        area: [1, "<map>", "</map>"],
        param: [1, "<object>", "</object>"],
        thead: [1, "<table>", "</table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: rt.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
    },
    Gt = m(mt),
    Kt = Gt.appendChild(mt.createElement("div"));
    Qt.optgroup = Qt.option,
    Qt.tbody = Qt.tfoot = Qt.colgroup = Qt.caption = Qt.thead,
    Qt.th = Qt.td,
    ot.extend({
        clone: function(e, t, n) {
            var r, i, o, a, s, l = ot.contains(e.ownerDocument, e);
            if (rt.html5Clone || ot.isXMLDoc(e) || !Bt.test("<" + e.nodeName + ">") ? o = e.cloneNode(!0) : (Kt.innerHTML = e.outerHTML, Kt.removeChild(o = Kt.firstChild)), !(rt.noCloneEvent && rt.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || ot.isXMLDoc(e))) for (r = g(o), s = g(e), a = 0; null != (i = s[a]); ++a) r[a] && C(i, r[a]);
            if (t) if (n) for (s = s || g(e), r = r || g(o), a = 0; null != (i = s[a]); a++) T(i, r[a]);
            else T(e, o);
            return r = g(o, "script"),
            r.length > 0 && w(r, !l && g(e, "script")),
            r = s = i = null,
            o
        },
        buildFragment: function(e, t, n, r) {
            for (var i, o, a, s, l, u, c, d = e.length,
            f = m(t), p = [], h = 0; d > h; h++) if (o = e[h], o || 0 === o) if ("object" === ot.type(o)) ot.merge(p, o.nodeType ? [o] : o);
            else if (It.test(o)) {
                for (s = s || f.appendChild(t.createElement("div")), l = ($t.exec(o) || ["", ""])[1].toLowerCase(), c = Qt[l] || Qt._default, s.innerHTML = c[1] + o.replace(Rt, "<$1></$2>") + c[2], i = c[0]; i--;) s = s.lastChild;
                if (!rt.leadingWhitespace && Wt.test(o) && p.push(t.createTextNode(Wt.exec(o)[0])), !rt.tbody) for (o = "table" !== l || zt.test(o) ? "<table>" !== c[1] || zt.test(o) ? 0 : s: s.firstChild, i = o && o.childNodes.length; i--;) ot.nodeName(u = o.childNodes[i], "tbody") && !u.childNodes.length && o.removeChild(u);
                for (ot.merge(p, s.childNodes), s.textContent = ""; s.firstChild;) s.removeChild(s.firstChild);
                s = f.lastChild
            } else p.push(t.createTextNode(o));
            for (s && f.removeChild(s), rt.appendChecked || ot.grep(g(p, "input"), v), h = 0; o = p[h++];) if ((!r || -1 === ot.inArray(o, r)) && (a = ot.contains(o.ownerDocument, o), s = g(f.appendChild(o), "script"), a && w(s), n)) for (i = 0; o = s[i++];) Vt.test(o.type || "") && n.push(o);
            return s = null,
            f
        },
        cleanData: function(e, t) {
            for (var n, r, i, o, a = 0,
            s = ot.expando,
            l = ot.cache,
            u = rt.deleteExpando,
            c = ot.event.special; null != (n = e[a]); a++) if ((t || ot.acceptData(n)) && (i = n[s], o = i && l[i])) {
                if (o.events) for (r in o.events) c[r] ? ot.event.remove(n, r) : ot.removeEvent(n, r, o.handle);
                l[i] && (delete l[i], u ? delete n[s] : typeof n.removeAttribute !== Nt ? n.removeAttribute(s) : n[s] = null, Y.push(i))
            }
        }
    }),
    ot.fn.extend({
        text: function(e) {
            return jt(this,
            function(e) {
                return void 0 === e ? ot.text(this) : this.empty().append((this[0] && this[0].ownerDocument || mt).createTextNode(e))
            },
            null, e, arguments.length)
        },
        append: function() {
            return this.domManip(arguments,
            function(e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = y(this, e);
                    t.appendChild(e)
                }
            })
        },
        prepend: function() {
            return this.domManip(arguments,
            function(e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = y(this, e);
                    t.insertBefore(e, t.firstChild)
                }
            })
        },
        before: function() {
            return this.domManip(arguments,
            function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            })
        },
        after: function() {
            return this.domManip(arguments,
            function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            })
        },
        remove: function(e, t) {
            for (var n, r = e ? ot.filter(e, this) : this, i = 0; null != (n = r[i]); i++) t || 1 !== n.nodeType || ot.cleanData(g(n)),
            n.parentNode && (t && ot.contains(n.ownerDocument, n) && w(g(n, "script")), n.parentNode.removeChild(n));
            return this
        },
        empty: function() {
            for (var e, t = 0; null != (e = this[t]); t++) {
                for (1 === e.nodeType && ot.cleanData(g(e, !1)); e.firstChild;) e.removeChild(e.firstChild);
                e.options && ot.nodeName(e, "select") && (e.options.length = 0)
            }
            return this
        },
        clone: function(e, t) {
            return e = null == e ? !1 : e,
            t = null == t ? e: t,
            this.map(function() {
                return ot.clone(this, e, t)
            })
        },
        html: function(e) {
            return jt(this,
            function(e) {
                var t = this[0] || {},
                n = 0,
                r = this.length;
                if (void 0 === e) return 1 === t.nodeType ? t.innerHTML.replace(Pt, "") : void 0;
                if (! ("string" != typeof e || Xt.test(e) || !rt.htmlSerialize && Bt.test(e) || !rt.leadingWhitespace && Wt.test(e) || Qt[($t.exec(e) || ["", ""])[1].toLowerCase()])) {
                    e = e.replace(Rt, "<$1></$2>");
                    try {
                        for (; r > n; n++) t = this[n] || {},
                        1 === t.nodeType && (ot.cleanData(g(t, !1)), t.innerHTML = e);
                        t = 0
                    } catch(i) {}
                }
                t && this.empty().append(e)
            },
            null, e, arguments.length)
        },
        replaceWith: function() {
            var e = arguments[0];
            return this.domManip(arguments,
            function(t) {
                e = this.parentNode,
                ot.cleanData(g(this)),
                e && e.replaceChild(t, this)
            }),
            e && (e.length || e.nodeType) ? this: this.remove()
        },
        detach: function(e) {
            return this.remove(e, !0)
        },
        domManip: function(e, t) {
            e = Q.apply([], e);
            var n, r, i, o, a, s, l = 0,
            u = this.length,
            c = this,
            d = u - 1,
            f = e[0],
            p = ot.isFunction(f);
            if (p || u > 1 && "string" == typeof f && !rt.checkClone && Ut.test(f)) return this.each(function(n) {
                var r = c.eq(n);
                p && (e[0] = f.call(this, n, r.html())),
                r.domManip(e, t)
            });
            if (u && (s = ot.buildFragment(e, this[0].ownerDocument, !1, this), n = s.firstChild, 1 === s.childNodes.length && (s = n), n)) {
                for (o = ot.map(g(s, "script"), b), i = o.length; u > l; l++) r = s,
                l !== d && (r = ot.clone(r, !0, !0), i && ot.merge(o, g(r, "script"))),
                t.call(this[l], r, l);
                if (i) for (a = o[o.length - 1].ownerDocument, ot.map(o, x), l = 0; i > l; l++) r = o[l],
                Vt.test(r.type || "") && !ot._data(r, "globalEval") && ot.contains(a, r) && (r.src ? ot._evalUrl && ot._evalUrl(r.src) : ot.globalEval((r.text || r.textContent || r.innerHTML || "").replace(Jt, "")));
                s = n = null
            }
            return this
        }
    }),
    ot.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    },
    function(e, t) {
        ot.fn[e] = function(e) {
            for (var n, r = 0,
            i = [], o = ot(e), a = o.length - 1; a >= r; r++) n = r === a ? this: this.clone(!0),
            ot(o[r])[t](n),
            G.apply(i, n.get());
            return this.pushStack(i)
        }
    });
    var Zt, en = {}; !
    function() {
        var e, t, n = mt.createElement("div"),
        r = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;padding:0;margin:0;border:0";
        n.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",
        e = n.getElementsByTagName("a")[0],
        e.style.cssText = "float:left;opacity:.5",
        rt.opacity = /^0.5/.test(e.style.opacity),
        rt.cssFloat = !!e.style.cssFloat,
        n.style.backgroundClip = "content-box",
        n.cloneNode(!0).style.backgroundClip = "",
        rt.clearCloneStyle = "content-box" === n.style.backgroundClip,
        e = n = null,
        rt.shrinkWrapBlocks = function() {
            var e, n, i, o;
            if (null == t) {
                if (e = mt.getElementsByTagName("body")[0], !e) return;
                o = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px",
                n = mt.createElement("div"),
                i = mt.createElement("div"),
                e.appendChild(n).appendChild(i),
                t = !1,
                typeof i.style.zoom !== Nt && (i.style.cssText = r + ";width:1px;padding:1px;zoom:1", i.innerHTML = "<div></div>", i.firstChild.style.width = "5px", t = 3 !== i.offsetWidth),
                e.removeChild(n),
                e = n = i = null
            }
            return t
        }
    } ();
    var tn, nn, rn = /^margin/,
    on = new RegExp("^(" + St + ")(?!px)[a-z%]+$", "i"),
    an = /^(top|right|bottom|left)$/;
    e.getComputedStyle ? (tn = function(e) {
        return e.ownerDocument.defaultView.getComputedStyle(e, null)
    },
    nn = function(e, t, n) {
        var r, i, o, a, s = e.style;
        return n = n || tn(e),
        a = n ? n.getPropertyValue(t) || n[t] : void 0,
        n && ("" !== a || ot.contains(e.ownerDocument, e) || (a = ot.style(e, t)), on.test(a) && rn.test(t) && (r = s.width, i = s.minWidth, o = s.maxWidth, s.minWidth = s.maxWidth = s.width = a, a = n.width, s.width = r, s.minWidth = i, s.maxWidth = o)),
        void 0 === a ? a: a + ""
    }) : mt.documentElement.currentStyle && (tn = function(e) {
        return e.currentStyle
    },
    nn = function(e, t, n) {
        var r, i, o, a, s = e.style;
        return n = n || tn(e),
        a = n ? n[t] : void 0,
        null == a && s && s[t] && (a = s[t]),
        on.test(a) && !an.test(t) && (r = s.left, i = e.runtimeStyle, o = i && i.left, o && (i.left = e.currentStyle.left), s.left = "fontSize" === t ? "1em": a, a = s.pixelLeft + "px", s.left = r, o && (i.left = o)),
        void 0 === a ? a: a + "" || "auto"
    }),
    function() {
        function t() {
            var t, n, r = mt.getElementsByTagName("body")[0];
            r && (t = mt.createElement("div"), n = mt.createElement("div"), t.style.cssText = u, r.appendChild(t).appendChild(n), n.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:absolute;display:block;padding:1px;border:1px;width:4px;margin-top:1%;top:1%", ot.swap(r, null != r.style.zoom ? {
                zoom: 1
            }: {},
            function() {
                i = 4 === n.offsetWidth
            }), o = !0, a = !1, s = !0, e.getComputedStyle && (a = "1%" !== (e.getComputedStyle(n, null) || {}).top, o = "4px" === (e.getComputedStyle(n, null) || {
                width: "4px"
            }).width), r.removeChild(t), n = r = null)
        }
        var n, r, i, o, a, s, l = mt.createElement("div"),
        u = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px",
        c = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;padding:0;margin:0;border:0";
        l.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",
        n = l.getElementsByTagName("a")[0],
        n.style.cssText = "float:left;opacity:.5",
        rt.opacity = /^0.5/.test(n.style.opacity),
        rt.cssFloat = !!n.style.cssFloat,
        l.style.backgroundClip = "content-box",
        l.cloneNode(!0).style.backgroundClip = "",
        rt.clearCloneStyle = "content-box" === l.style.backgroundClip,
        n = l = null,
        ot.extend(rt, {
            reliableHiddenOffsets: function() {
                if (null != r) return r;
                var e, t, n, i = mt.createElement("div"),
                o = mt.getElementsByTagName("body")[0];
                if (o) return i.setAttribute("className", "t"),
                i.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",
                e = mt.createElement("div"),
                e.style.cssText = u,
                o.appendChild(e).appendChild(i),
                i.innerHTML = "<table><tr><td></td><td>t</td></tr></table>",
                t = i.getElementsByTagName("td"),
                t[0].style.cssText = "padding:0;margin:0;border:0;display:none",
                n = 0 === t[0].offsetHeight,
                t[0].style.display = "",
                t[1].style.display = "none",
                r = n && 0 === t[0].offsetHeight,
                o.removeChild(e),
                i = o = null,
                r
            },
            boxSizing: function() {
                return null == i && t(),
                i
            },
            boxSizingReliable: function() {
                return null == o && t(),
                o
            },
            pixelPosition: function() {
                return null == a && t(),
                a
            },
            reliableMarginRight: function() {
                var t, n, r, i;
                if (null == s && e.getComputedStyle) {
                    if (t = mt.getElementsByTagName("body")[0], !t) return;
                    n = mt.createElement("div"),
                    r = mt.createElement("div"),
                    n.style.cssText = u,
                    t.appendChild(n).appendChild(r),
                    i = r.appendChild(mt.createElement("div")),
                    i.style.cssText = r.style.cssText = c,
                    i.style.marginRight = i.style.width = "0",
                    r.style.width = "1px",
                    s = !parseFloat((e.getComputedStyle(i, null) || {}).marginRight),
                    t.removeChild(n)
                }
                return s
            }
        })
    } (),
    ot.swap = function(e, t, n, r) {
        var i, o, a = {};
        for (o in t) a[o] = e.style[o],
        e.style[o] = t[o];
        i = n.apply(e, r || []);
        for (o in t) e.style[o] = a[o];
        return i
    };
    var sn = /alpha\([^)]*\)/i,
    ln = /opacity\s*=\s*([^)]*)/,
    un = /^(none|table(?!-c[ea]).+)/,
    cn = new RegExp("^(" + St + ")(.*)$", "i"),
    dn = new RegExp("^([+-])=(" + St + ")", "i"),
    fn = {
        position: "absolute",
        visibility: "hidden",
        display: "block"
    },
    pn = {
        letterSpacing: 0,
        fontWeight: 400
    },
    hn = ["Webkit", "O", "Moz", "ms"];
    ot.extend({
        cssHooks: {
            opacity: {
                get: function(e, t) {
                    if (t) {
                        var n = nn(e, "opacity");
                        return "" === n ? "1": n
                    }
                }
            }
        },
        cssNumber: {
            columnCount: !0,
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            "float": rt.cssFloat ? "cssFloat": "styleFloat"
        },
        style: function(e, t, n, r) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var i, o, a, s = ot.camelCase(t),
                l = e.style;
                if (t = ot.cssProps[s] || (ot.cssProps[s] = S(l, s)), a = ot.cssHooks[t] || ot.cssHooks[s], void 0 === n) return a && "get" in a && void 0 !== (i = a.get(e, !1, r)) ? i: l[t];
                if (o = typeof n, "string" === o && (i = dn.exec(n)) && (n = (i[1] + 1) * i[2] + parseFloat(ot.css(e, t)), o = "number"), null != n && n === n && ("number" !== o || ot.cssNumber[s] || (n += "px"), rt.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), !(a && "set" in a && void 0 === (n = a.set(e, n, r))))) try {
                    l[t] = "",
                    l[t] = n
                } catch(u) {}
            }
        },
        css: function(e, t, n, r) {
            var i, o, a, s = ot.camelCase(t);
            return t = ot.cssProps[s] || (ot.cssProps[s] = S(e.style, s)),
            a = ot.cssHooks[t] || ot.cssHooks[s],
            a && "get" in a && (o = a.get(e, !0, n)),
            void 0 === o && (o = nn(e, t, r)),
            "normal" === o && t in pn && (o = pn[t]),
            "" === n || n ? (i = parseFloat(o), n === !0 || ot.isNumeric(i) ? i || 0 : o) : o
        }
    }),
    ot.each(["height", "width"],
    function(e, t) {
        ot.cssHooks[t] = {
            get: function(e, n, r) {
                return n ? 0 === e.offsetWidth && un.test(ot.css(e, "display")) ? ot.swap(e, fn,
                function() {
                    return L(e, t, r)
                }) : L(e, t, r) : void 0
            },
            set: function(e, n, r) {
                var i = r && tn(e);
                return A(e, n, r ? j(e, t, r, rt.boxSizing() && "border-box" === ot.css(e, "boxSizing", !1, i), i) : 0)
            }
        }
    }),
    rt.opacity || (ot.cssHooks.opacity = {
        get: function(e, t) {
            return ln.test((t && e.currentStyle ? e.currentStyle.filter: e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "": t ? "1": ""
        },
        set: function(e, t) {
            var n = e.style,
            r = e.currentStyle,
            i = ot.isNumeric(t) ? "alpha(opacity=" + 100 * t + ")": "",
            o = r && r.filter || n.filter || "";
            n.zoom = 1,
            (t >= 1 || "" === t) && "" === ot.trim(o.replace(sn, "")) && n.removeAttribute && (n.removeAttribute("filter"), "" === t || r && !r.filter) || (n.filter = sn.test(o) ? o.replace(sn, i) : o + " " + i)
        }
    }),
    ot.cssHooks.marginRight = k(rt.reliableMarginRight,
    function(e, t) {
        return t ? ot.swap(e, {
            display: "inline-block"
        },
        nn, [e, "marginRight"]) : void 0
    }),
    ot.each({
        margin: "",
        padding: "",
        border: "Width"
    },
    function(e, t) {
        ot.cssHooks[e + t] = {
            expand: function(n) {
                for (var r = 0,
                i = {},
                o = "string" == typeof n ? n.split(" ") : [n]; 4 > r; r++) i[e + Dt[r] + t] = o[r] || o[r - 2] || o[0];
                return i
            }
        },
        rn.test(e) || (ot.cssHooks[e + t].set = A)
    }),
    ot.fn.extend({
        css: function(e, t) {
            return jt(this,
            function(e, t, n) {
                var r, i, o = {},
                a = 0;
                if (ot.isArray(t)) {
                    for (r = tn(e), i = t.length; i > a; a++) o[t[a]] = ot.css(e, t[a], !1, r);
                    return o
                }
                return void 0 !== n ? ot.style(e, t, n) : ot.css(e, t)
            },
            e, t, arguments.length > 1)
        },
        show: function() {
            return D(this, !0)
        },
        hide: function() {
            return D(this)
        },
        toggle: function(e) {
            return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function() {
                At(this) ? ot(this).show() : ot(this).hide()
            })
        }
    }),
    ot.Tween = _,
    _.prototype = {
        constructor: _,
        init: function(e, t, n, r, i, o) {
            this.elem = e,
            this.prop = n,
            this.easing = i || "swing",
            this.options = t,
            this.start = this.now = this.cur(),
            this.end = r,
            this.unit = o || (ot.cssNumber[n] ? "": "px")
        },
        cur: function() {
            var e = _.propHooks[this.prop];
            return e && e.get ? e.get(this) : _.propHooks._default.get(this)
        },
        run: function(e) {
            var t, n = _.propHooks[this.prop];
            return this.pos = t = this.options.duration ? ot.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : e,
            this.now = (this.end - this.start) * t + this.start,
            this.options.step && this.options.step.call(this.elem, this.now, this),
            n && n.set ? n.set(this) : _.propHooks._default.set(this),
            this
        }
    },
    _.prototype.init.prototype = _.prototype,
    _.propHooks = {
        _default: {
            get: function(e) {
                var t;
                return null == e.elem[e.prop] || e.elem.style && null != e.elem.style[e.prop] ? (t = ot.css(e.elem, e.prop, ""), t && "auto" !== t ? t: 0) : e.elem[e.prop]
            },
            set: function(e) {
                ot.fx.step[e.prop] ? ot.fx.step[e.prop](e) : e.elem.style && (null != e.elem.style[ot.cssProps[e.prop]] || ot.cssHooks[e.prop]) ? ot.style(e.elem, e.prop, e.now + e.unit) : e.elem[e.prop] = e.now
            }
        }
    },
    _.propHooks.scrollTop = _.propHooks.scrollLeft = {
        set: function(e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    },
    ot.easing = {
        linear: function(e) {
            return e
        },
        swing: function(e) {
            return.5 - Math.cos(e * Math.PI) / 2
        }
    },
    ot.fx = _.prototype.init,
    ot.fx.step = {};
    var mn, gn, vn = /^(?:toggle|show|hide)$/,
    yn = new RegExp("^(?:([+-])=|)(" + St + ")([a-z%]*)$", "i"),
    bn = /queueHooks$/,
    xn = [O],
    wn = {
        "*": [function(e, t) {
            var n = this.createTween(e, t),
            r = n.cur(),
            i = yn.exec(t),
            o = i && i[3] || (ot.cssNumber[e] ? "": "px"),
            a = (ot.cssNumber[e] || "px" !== o && +r) && yn.exec(ot.css(n.elem, e)),
            s = 1,
            l = 20;
            if (a && a[3] !== o) {
                o = o || a[3],
                i = i || [],
                a = +r || 1;
                do s = s || ".5",
                a /= s,
                ot.style(n.elem, e, a + o);
                while (s !== (s = n.cur() / r) && 1 !== s && --l)
            }
            return i && (a = n.start = +a || +r || 0, n.unit = o, n.end = i[1] ? a + (i[1] + 1) * i[2] : +i[2]),
            n
        }]
    };
    ot.Animation = ot.extend(P, {
        tweener: function(e, t) {
            ot.isFunction(e) ? (t = e, e = ["*"]) : e = e.split(" ");
            for (var n, r = 0,
            i = e.length; i > r; r++) n = e[r],
            wn[n] = wn[n] || [],
            wn[n].unshift(t)
        },
        prefilter: function(e, t) {
            t ? xn.unshift(e) : xn.push(e)
        }
    }),
    ot.speed = function(e, t, n) {
        var r = e && "object" == typeof e ? ot.extend({},
        e) : {
            complete: n || !n && t || ot.isFunction(e) && e,
            duration: e,
            easing: n && t || t && !ot.isFunction(t) && t
        };
        return r.duration = ot.fx.off ? 0 : "number" == typeof r.duration ? r.duration: r.duration in ot.fx.speeds ? ot.fx.speeds[r.duration] : ot.fx.speeds._default,
        (null == r.queue || r.queue === !0) && (r.queue = "fx"),
        r.old = r.complete,
        r.complete = function() {
            ot.isFunction(r.old) && r.old.call(this),
            r.queue && ot.dequeue(this, r.queue)
        },
        r
    },
    ot.fn.extend({
        fadeTo: function(e, t, n, r) {
            return this.filter(At).css("opacity", 0).show().end().animate({
                opacity: t
            },
            e, n, r)
        },
        animate: function(e, t, n, r) {
            var i = ot.isEmptyObject(e),
            o = ot.speed(t, n, r),
            a = function() {
                var t = P(this, ot.extend({},
                e), o); (i || ot._data(this, "finish")) && t.stop(!0)
            };
            return a.finish = a,
            i || o.queue === !1 ? this.each(a) : this.queue(o.queue, a)
        },
        stop: function(e, t, n) {
            var r = function(e) {
                var t = e.stop;
                delete e.stop,
                t(n)
            };
            return "string" != typeof e && (n = t, t = e, e = void 0),
            t && e !== !1 && this.queue(e || "fx", []),
            this.each(function() {
                var t = !0,
                i = null != e && e + "queueHooks",
                o = ot.timers,
                a = ot._data(this);
                if (i) a[i] && a[i].stop && r(a[i]);
                else for (i in a) a[i] && a[i].stop && bn.test(i) && r(a[i]);
                for (i = o.length; i--;) o[i].elem !== this || null != e && o[i].queue !== e || (o[i].anim.stop(n), t = !1, o.splice(i, 1)); (t || !n) && ot.dequeue(this, e)
            })
        },
        finish: function(e) {
            return e !== !1 && (e = e || "fx"),
            this.each(function() {
                var t, n = ot._data(this),
                r = n[e + "queue"],
                i = n[e + "queueHooks"],
                o = ot.timers,
                a = r ? r.length: 0;
                for (n.finish = !0, ot.queue(this, e, []), i && i.stop && i.stop.call(this, !0), t = o.length; t--;) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
                for (t = 0; a > t; t++) r[t] && r[t].finish && r[t].finish.call(this);
                delete n.finish
            })
        }
    }),
    ot.each(["toggle", "show", "hide"],
    function(e, t) {
        var n = ot.fn[t];
        ot.fn[t] = function(e, r, i) {
            return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(M(t, !0), e, r, i)
        }
    }),
    ot.each({
        slideDown: M("show"),
        slideUp: M("hide"),
        slideToggle: M("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    },
    function(e, t) {
        ot.fn[e] = function(e, n, r) {
            return this.animate(t, e, n, r)
        }
    }),
    ot.timers = [],
    ot.fx.tick = function() {
        var e, t = ot.timers,
        n = 0;
        for (mn = ot.now(); n < t.length; n++) e = t[n],
        e() || t[n] !== e || t.splice(n--, 1);
        t.length || ot.fx.stop(),
        mn = void 0
    },
    ot.fx.timer = function(e) {
        ot.timers.push(e),
        e() ? ot.fx.start() : ot.timers.pop()
    },
    ot.fx.interval = 13,
    ot.fx.start = function() {
        gn || (gn = setInterval(ot.fx.tick, ot.fx.interval))
    },
    ot.fx.stop = function() {
        clearInterval(gn),
        gn = null
    },
    ot.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    },
    ot.fn.delay = function(e, t) {
        return e = ot.fx ? ot.fx.speeds[e] || e: e,
        t = t || "fx",
        this.queue(t,
        function(t, n) {
            var r = setTimeout(t, e);
            n.stop = function() {
                clearTimeout(r)
            }
        })
    },
    function() {
        var e, t, n, r, i = mt.createElement("div");
        i.setAttribute("className", "t"),
        i.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",
        e = i.getElementsByTagName("a")[0],
        n = mt.createElement("select"),
        r = n.appendChild(mt.createElement("option")),
        t = i.getElementsByTagName("input")[0],
        e.style.cssText = "top:1px",
        rt.getSetAttribute = "t" !== i.className,
        rt.style = /top/.test(e.getAttribute("style")),
        rt.hrefNormalized = "/a" === e.getAttribute("href"),
        rt.checkOn = !!t.value,
        rt.optSelected = r.selected,
        rt.enctype = !!mt.createElement("form").enctype,
        n.disabled = !0,
        rt.optDisabled = !r.disabled,
        t = mt.createElement("input"),
        t.setAttribute("value", ""),
        rt.input = "" === t.getAttribute("value"),
        t.value = "t",
        t.setAttribute("type", "radio"),
        rt.radioValue = "t" === t.value,
        e = t = n = r = i = null
    } ();
    var Tn = /\r/g;
    ot.fn.extend({
        val: function(e) {
            var t, n, r, i = this[0]; {
                if (arguments.length) return r = ot.isFunction(e),
                this.each(function(n) {
                    var i;
                    1 === this.nodeType && (i = r ? e.call(this, n, ot(this).val()) : e, null == i ? i = "": "number" == typeof i ? i += "": ot.isArray(i) && (i = ot.map(i,
                    function(e) {
                        return null == e ? "": e + ""
                    })), t = ot.valHooks[this.type] || ot.valHooks[this.nodeName.toLowerCase()], t && "set" in t && void 0 !== t.set(this, i, "value") || (this.value = i))
                });
                if (i) return t = ot.valHooks[i.type] || ot.valHooks[i.nodeName.toLowerCase()],
                t && "get" in t && void 0 !== (n = t.get(i, "value")) ? n: (n = i.value, "string" == typeof n ? n.replace(Tn, "") : null == n ? "": n)
            }
        }
    }),
    ot.extend({
        valHooks: {
            option: {
                get: function(e) {
                    var t = ot.find.attr(e, "value");
                    return null != t ? t: ot.text(e)
                }
            },
            select: {
                get: function(e) {
                    for (var t, n, r = e.options,
                    i = e.selectedIndex,
                    o = "select-one" === e.type || 0 > i,
                    a = o ? null: [], s = o ? i + 1 : r.length, l = 0 > i ? s: o ? i: 0; s > l; l++) if (n = r[l], !(!n.selected && l !== i || (rt.optDisabled ? n.disabled: null !== n.getAttribute("disabled")) || n.parentNode.disabled && ot.nodeName(n.parentNode, "optgroup"))) {
                        if (t = ot(n).val(), o) return t;
                        a.push(t)
                    }
                    return a
                },
                set: function(e, t) {
                    for (var n, r, i = e.options,
                    o = ot.makeArray(t), a = i.length; a--;) if (r = i[a], ot.inArray(ot.valHooks.option.get(r), o) >= 0) try {
                        r.selected = n = !0
                    } catch(s) {
                        r.scrollHeight
                    } else r.selected = !1;
                    return n || (e.selectedIndex = -1),
                    i
                }
            }
        }
    }),
    ot.each(["radio", "checkbox"],
    function() {
        ot.valHooks[this] = {
            set: function(e, t) {
                return ot.isArray(t) ? e.checked = ot.inArray(ot(e).val(), t) >= 0 : void 0
            }
        },
        rt.checkOn || (ot.valHooks[this].get = function(e) {
            return null === e.getAttribute("value") ? "on": e.value
        })
    });
    var Cn, Nn, En = ot.expr.attrHandle,
    kn = /^(?:checked|selected)$/i,
    Sn = rt.getSetAttribute,
    Dn = rt.input;
    ot.fn.extend({
        attr: function(e, t) {
            return jt(this, ot.attr, e, t, arguments.length > 1)
        },
        removeAttr: function(e) {
            return this.each(function() {
                ot.removeAttr(this, e)
            })
        }
    }),
    ot.extend({
        attr: function(e, t, n) {
            var r, i, o = e.nodeType;
            if (e && 3 !== o && 8 !== o && 2 !== o) return typeof e.getAttribute === Nt ? ot.prop(e, t, n) : (1 === o && ot.isXMLDoc(e) || (t = t.toLowerCase(), r = ot.attrHooks[t] || (ot.expr.match.bool.test(t) ? Nn: Cn)), void 0 === n ? r && "get" in r && null !== (i = r.get(e, t)) ? i: (i = ot.find.attr(e, t), null == i ? void 0 : i) : null !== n ? r && "set" in r && void 0 !== (i = r.set(e, n, t)) ? i: (e.setAttribute(t, n + ""), n) : void ot.removeAttr(e, t))
        },
        removeAttr: function(e, t) {
            var n, r, i = 0,
            o = t && t.match(xt);
            if (o && 1 === e.nodeType) for (; n = o[i++];) r = ot.propFix[n] || n,
            ot.expr.match.bool.test(n) ? Dn && Sn || !kn.test(n) ? e[r] = !1 : e[ot.camelCase("default-" + n)] = e[r] = !1 : ot.attr(e, n, ""),
            e.removeAttribute(Sn ? n: r)
        },
        attrHooks: {
            type: {
                set: function(e, t) {
                    if (!rt.radioValue && "radio" === t && ot.nodeName(e, "input")) {
                        var n = e.value;
                        return e.setAttribute("type", t),
                        n && (e.value = n),
                        t
                    }
                }
            }
        }
    }),
    Nn = {
        set: function(e, t, n) {
            return t === !1 ? ot.removeAttr(e, n) : Dn && Sn || !kn.test(n) ? e.setAttribute(!Sn && ot.propFix[n] || n, n) : e[ot.camelCase("default-" + n)] = e[n] = !0,
            n
        }
    },
    ot.each(ot.expr.match.bool.source.match(/\w+/g),
    function(e, t) {
        var n = En[t] || ot.find.attr;
        En[t] = Dn && Sn || !kn.test(t) ?
        function(e, t, r) {
            var i, o;
            return r || (o = En[t], En[t] = i, i = null != n(e, t, r) ? t.toLowerCase() : null, En[t] = o),
            i
        }: function(e, t, n) {
            return n ? void 0 : e[ot.camelCase("default-" + t)] ? t.toLowerCase() : null
        }
    }),
    Dn && Sn || (ot.attrHooks.value = {
        set: function(e, t, n) {
            return ot.nodeName(e, "input") ? void(e.defaultValue = t) : Cn && Cn.set(e, t, n)
        }
    }),
    Sn || (Cn = {
        set: function(e, t, n) {
            var r = e.getAttributeNode(n);
            return r || e.setAttributeNode(r = e.ownerDocument.createAttribute(n)),
            r.value = t += "",
            "value" === n || t === e.getAttribute(n) ? t: void 0
        }
    },
    En.id = En.name = En.coords = function(e, t, n) {
        var r;
        return n ? void 0 : (r = e.getAttributeNode(t)) && "" !== r.value ? r.value: null
    },
    ot.valHooks.button = {
        get: function(e, t) {
            var n = e.getAttributeNode(t);
            return n && n.specified ? n.value: void 0
        },
        set: Cn.set
    },
    ot.attrHooks.contenteditable = {
        set: function(e, t, n) {
            Cn.set(e, "" === t ? !1 : t, n)
        }
    },
    ot.each(["width", "height"],
    function(e, t) {
        ot.attrHooks[t] = {
            set: function(e, n) {
                return "" === n ? (e.setAttribute(t, "auto"), n) : void 0
            }
        }
    })),
    rt.style || (ot.attrHooks.style = {
        get: function(e) {
            return e.style.cssText || void 0
        },
        set: function(e, t) {
            return e.style.cssText = t + ""
        }
    });
    var An = /^(?:input|select|textarea|button|object)$/i,
    jn = /^(?:a|area)$/i;
    ot.fn.extend({
        prop: function(e, t) {
            return jt(this, ot.prop, e, t, arguments.length > 1)
        },
        removeProp: function(e) {
            return e = ot.propFix[e] || e,
            this.each(function() {
                try {
                    this[e] = void 0,
                    delete this[e]
                } catch(t) {}
            })
        }
    }),
    ot.extend({
        propFix: {
            "for": "htmlFor",
            "class": "className"
        },
        prop: function(e, t, n) {
            var r, i, o, a = e.nodeType;
            if (e && 3 !== a && 8 !== a && 2 !== a) return o = 1 !== a || !ot.isXMLDoc(e),
            o && (t = ot.propFix[t] || t, i = ot.propHooks[t]),
            void 0 !== n ? i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r: e[t] = n: i && "get" in i && null !== (r = i.get(e, t)) ? r: e[t]
        },
        propHooks: {
            tabIndex: {
                get: function(e) {
                    var t = ot.find.attr(e, "tabindex");
                    return t ? parseInt(t, 10) : An.test(e.nodeName) || jn.test(e.nodeName) && e.href ? 0 : -1
                }
            }
        }
    }),
    rt.hrefNormalized || ot.each(["href", "src"],
    function(e, t) {
        ot.propHooks[t] = {
            get: function(e) {
                return e.getAttribute(t, 4)
            }
        }
    }),
    rt.optSelected || (ot.propHooks.selected = {
        get: function(e) {
            var t = e.parentNode;
            return t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex),
            null
        }
    }),
    ot.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"],
    function() {
        ot.propFix[this.toLowerCase()] = this
    }),
    rt.enctype || (ot.propFix.enctype = "encoding");
    var Ln = /[\t\r\n\f]/g;
    ot.fn.extend({
        addClass: function(e) {
            var t, n, r, i, o, a, s = 0,
            l = this.length,
            u = "string" == typeof e && e;
            if (ot.isFunction(e)) return this.each(function(t) {
                ot(this).addClass(e.call(this, t, this.className))
            });
            if (u) for (t = (e || "").match(xt) || []; l > s; s++) if (n = this[s], r = 1 === n.nodeType && (n.className ? (" " + n.className + " ").replace(Ln, " ") : " ")) {
                for (o = 0; i = t[o++];) r.indexOf(" " + i + " ") < 0 && (r += i + " ");
                a = ot.trim(r),
                n.className !== a && (n.className = a)
            }
            return this
        },
        removeClass: function(e) {
            var t, n, r, i, o, a, s = 0,
            l = this.length,
            u = 0 === arguments.length || "string" == typeof e && e;
            if (ot.isFunction(e)) return this.each(function(t) {
                ot(this).removeClass(e.call(this, t, this.className))
            });
            if (u) for (t = (e || "").match(xt) || []; l > s; s++) if (n = this[s], r = 1 === n.nodeType && (n.className ? (" " + n.className + " ").replace(Ln, " ") : "")) {
                for (o = 0; i = t[o++];) for (; r.indexOf(" " + i + " ") >= 0;) r = r.replace(" " + i + " ", " ");
                a = e ? ot.trim(r) : "",
                n.className !== a && (n.className = a)
            }
            return this
        },
        toggleClass: function(e, t) {
            var n = typeof e;
            return "boolean" == typeof t && "string" === n ? t ? this.addClass(e) : this.removeClass(e) : this.each(ot.isFunction(e) ?
            function(n) {
                ot(this).toggleClass(e.call(this, n, this.className, t), t)
            }: function() {
                if ("string" === n) for (var t, r = 0,
                i = ot(this), o = e.match(xt) || []; t = o[r++];) i.hasClass(t) ? i.removeClass(t) : i.addClass(t);
                else(n === Nt || "boolean" === n) && (this.className && ot._data(this, "__className__", this.className), this.className = this.className || e === !1 ? "": ot._data(this, "__className__") || "")
            })
        },
        hasClass: function(e) {
            for (var t = " " + e + " ",
            n = 0,
            r = this.length; r > n; n++) if (1 === this[n].nodeType && (" " + this[n].className + " ").replace(Ln, " ").indexOf(t) >= 0) return ! 0;
            return ! 1
        }
    }),
    ot.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),
    function(e, t) {
        ot.fn[t] = function(e, n) {
            return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
        }
    }),
    ot.fn.extend({
        hover: function(e, t) {
            return this.mouseenter(e).mouseleave(t || e)
        },
        bind: function(e, t, n) {
            return this.on(e, null, t, n)
        },
        unbind: function(e, t) {
            return this.off(e, null, t)
        },
        delegate: function(e, t, n, r) {
            return this.on(t, e, n, r)
        },
        undelegate: function(e, t, n) {
            return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
        }
    });
    var _n = ot.now(),
    Hn = /\?/,
    Mn = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
    ot.parseJSON = function(t) {
        if (e.JSON && e.JSON.parse) return e.JSON.parse(t + "");
        var n, r = null,
        i = ot.trim(t + "");
        return i && !ot.trim(i.replace(Mn,
        function(e, t, i, o) {
            return n && t && (r = 0),
            0 === r ? e: (n = i || t, r += !o - !i, "")
        })) ? Function("return " + i)() : ot.error("Invalid JSON: " + t)
    },
    ot.parseXML = function(t) {
        var n, r;
        if (!t || "string" != typeof t) return null;
        try {
            e.DOMParser ? (r = new DOMParser, n = r.parseFromString(t, "text/xml")) : (n = new ActiveXObject("Microsoft.XMLDOM"), n.async = "false", n.loadXML(t))
        } catch(i) {
            n = void 0
        }
        return n && n.documentElement && !n.getElementsByTagName("parsererror").length || ot.error("Invalid XML: " + t),
        n
    };
    var qn, On, Fn = /#.*$/,
    Pn = /([?&])_=[^&]*/,
    Bn = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
    Wn = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
    Rn = /^(?:GET|HEAD)$/,
    $n = /^\/\//,
    zn = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
    In = {},
    Xn = {},
    Un = "*/".concat("*");
    try {
        On = location.href
    } catch(Vn) {
        On = mt.createElement("a"),
        On.href = "",
        On = On.href
    }
    qn = zn.exec(On.toLowerCase()) || [],
    ot.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: On,
            type: "GET",
            isLocal: Wn.test(qn[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": Un,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": ot.parseJSON,
                "text xml": ot.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(e, t) {
            return t ? R(R(e, ot.ajaxSettings), t) : R(ot.ajaxSettings, e)
        },
        ajaxPrefilter: B(In),
        ajaxTransport: B(Xn),
        ajax: function(e, t) {
            function n(e, t, n, r) {
                var i, c, v, y, x, T = t;
                2 !== b && (b = 2, s && clearTimeout(s), u = void 0, a = r || "", w.readyState = e > 0 ? 4 : 0, i = e >= 200 && 300 > e || 304 === e, n && (y = $(d, w, n)), y = z(d, y, w, i), i ? (d.ifModified && (x = w.getResponseHeader("Last-Modified"), x && (ot.lastModified[o] = x), x = w.getResponseHeader("etag"), x && (ot.etag[o] = x)), 204 === e || "HEAD" === d.type ? T = "nocontent": 304 === e ? T = "notmodified": (T = y.state, c = y.data, v = y.error, i = !v)) : (v = T, (e || !T) && (T = "error", 0 > e && (e = 0))), w.status = e, w.statusText = (t || T) + "", i ? h.resolveWith(f, [c, T, w]) : h.rejectWith(f, [w, T, v]), w.statusCode(g), g = void 0, l && p.trigger(i ? "ajaxSuccess": "ajaxError", [w, d, i ? c: v]), m.fireWith(f, [w, T]), l && (p.trigger("ajaxComplete", [w, d]), --ot.active || ot.event.trigger("ajaxStop")))
            }
            "object" == typeof e && (t = e, e = void 0),
            t = t || {};
            var r, i, o, a, s, l, u, c, d = ot.ajaxSetup({},
            t),
            f = d.context || d,
            p = d.context && (f.nodeType || f.jquery) ? ot(f) : ot.event,
            h = ot.Deferred(),
            m = ot.Callbacks("once memory"),
            g = d.statusCode || {},
            v = {},
            y = {},
            b = 0,
            x = "canceled",
            w = {
                readyState: 0,
                getResponseHeader: function(e) {
                    var t;
                    if (2 === b) {
                        if (!c) for (c = {}; t = Bn.exec(a);) c[t[1].toLowerCase()] = t[2];
                        t = c[e.toLowerCase()]
                    }
                    return null == t ? null: t
                },
                getAllResponseHeaders: function() {
                    return 2 === b ? a: null
                },
                setRequestHeader: function(e, t) {
                    var n = e.toLowerCase();
                    return b || (e = y[n] = y[n] || e, v[e] = t),
                    this
                },
                overrideMimeType: function(e) {
                    return b || (d.mimeType = e),
                    this
                },
                statusCode: function(e) {
                    var t;
                    if (e) if (2 > b) for (t in e) g[t] = [g[t], e[t]];
                    else w.always(e[w.status]);
                    return this
                },
                abort: function(e) {
                    var t = e || x;
                    return u && u.abort(t),
                    n(0, t),
                    this
                }
            };
            if (h.promise(w).complete = m.add, w.success = w.done, w.error = w.fail, d.url = ((e || d.url || On) + "").replace(Fn, "").replace($n, qn[1] + "//"), d.type = t.method || t.type || d.method || d.type, d.dataTypes = ot.trim(d.dataType || "*").toLowerCase().match(xt) || [""], null == d.crossDomain && (r = zn.exec(d.url.toLowerCase()), d.crossDomain = !(!r || r[1] === qn[1] && r[2] === qn[2] && (r[3] || ("http:" === r[1] ? "80": "443")) === (qn[3] || ("http:" === qn[1] ? "80": "443")))), d.data && d.processData && "string" != typeof d.data && (d.data = ot.param(d.data, d.traditional)), W(In, d, t, w), 2 === b) return w;
            l = d.global,
            l && 0 === ot.active++&&ot.event.trigger("ajaxStart"),
            d.type = d.type.toUpperCase(),
            d.hasContent = !Rn.test(d.type),
            o = d.url,
            d.hasContent || (d.data && (o = d.url += (Hn.test(o) ? "&": "?") + d.data, delete d.data), d.cache === !1 && (d.url = Pn.test(o) ? o.replace(Pn, "$1_=" + _n++) : o + (Hn.test(o) ? "&": "?") + "_=" + _n++)),
            d.ifModified && (ot.lastModified[o] && w.setRequestHeader("If-Modified-Since", ot.lastModified[o]), ot.etag[o] && w.setRequestHeader("If-None-Match", ot.etag[o])),
            (d.data && d.hasContent && d.contentType !== !1 || t.contentType) && w.setRequestHeader("Content-Type", d.contentType),
            w.setRequestHeader("Accept", d.dataTypes[0] && d.accepts[d.dataTypes[0]] ? d.accepts[d.dataTypes[0]] + ("*" !== d.dataTypes[0] ? ", " + Un + "; q=0.01": "") : d.accepts["*"]);
            for (i in d.headers) w.setRequestHeader(i, d.headers[i]);
            if (d.beforeSend && (d.beforeSend.call(f, w, d) === !1 || 2 === b)) return w.abort();
            x = "abort";
            for (i in {
                success: 1,
                error: 1,
                complete: 1
            }) w[i](d[i]);
            if (u = W(Xn, d, t, w)) {
                w.readyState = 1,
                l && p.trigger("ajaxSend", [w, d]),
                d.async && d.timeout > 0 && (s = setTimeout(function() {
                    w.abort("timeout")
                },
                d.timeout));
                try {
                    b = 1,
                    u.send(v, n)
                } catch(T) {
                    if (! (2 > b)) throw T;
                    n( - 1, T)
                }
            } else n( - 1, "No Transport");
            return w
        },
        getJSON: function(e, t, n) {
            return ot.get(e, t, n, "json")
        },
        getScript: function(e, t) {
            return ot.get(e, void 0, t, "script")
        }
    }),
    ot.each(["get", "post"],
    function(e, t) {
        ot[t] = function(e, n, r, i) {
            return ot.isFunction(n) && (i = i || r, r = n, n = void 0),
            ot.ajax({
                url: e,
                type: t,
                dataType: i,
                data: n,
                success: r
            })
        }
    }),
    ot.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"],
    function(e, t) {
        ot.fn[t] = function(e) {
            return this.on(t, e)
        }
    }),
    ot._evalUrl = function(e) {
        return ot.ajax({
            url: e,
            type: "GET",
            dataType: "script",
            async: !1,
            global: !1,
            "throws": !0
        })
    },
    ot.fn.extend({
        wrapAll: function(e) {
            if (ot.isFunction(e)) return this.each(function(t) {
                ot(this).wrapAll(e.call(this, t))
            });
            if (this[0]) {
                var t = ot(e, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && t.insertBefore(this[0]),
                t.map(function() {
                    for (var e = this; e.firstChild && 1 === e.firstChild.nodeType;) e = e.firstChild;
                    return e
                }).append(this)
            }
            return this
        },
        wrapInner: function(e) {
            return this.each(ot.isFunction(e) ?
            function(t) {
                ot(this).wrapInner(e.call(this, t))
            }: function() {
                var t = ot(this),
                n = t.contents();
                n.length ? n.wrapAll(e) : t.append(e)
            })
        },
        wrap: function(e) {
            var t = ot.isFunction(e);
            return this.each(function(n) {
                ot(this).wrapAll(t ? e.call(this, n) : e)
            })
        },
        unwrap: function() {
            return this.parent().each(function() {
                ot.nodeName(this, "body") || ot(this).replaceWith(this.childNodes)
            }).end()
        }
    }),
    ot.expr.filters.hidden = function(e) {
        return e.offsetWidth <= 0 && e.offsetHeight <= 0 || !rt.reliableHiddenOffsets() && "none" === (e.style && e.style.display || ot.css(e, "display"))
    },
    ot.expr.filters.visible = function(e) {
        return ! ot.expr.filters.hidden(e)
    };
    var Yn = /%20/g,
    Jn = /\[\]$/,
    Qn = /\r?\n/g,
    Gn = /^(?:submit|button|image|reset|file)$/i,
    Kn = /^(?:input|select|textarea|keygen)/i;
    ot.param = function(e, t) {
        var n, r = [],
        i = function(e, t) {
            t = ot.isFunction(t) ? t() : null == t ? "": t,
            r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
        };
        if (void 0 === t && (t = ot.ajaxSettings && ot.ajaxSettings.traditional), ot.isArray(e) || e.jquery && !ot.isPlainObject(e)) ot.each(e,
        function() {
            i(this.name, this.value)
        });
        else for (n in e) I(n, e[n], t, i);
        return r.join("&").replace(Yn, "+")
    },
    ot.fn.extend({
        serialize: function() {
            return ot.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                var e = ot.prop(this, "elements");
                return e ? ot.makeArray(e) : this
            }).filter(function() {
                var e = this.type;
                return this.name && !ot(this).is(":disabled") && Kn.test(this.nodeName) && !Gn.test(e) && (this.checked || !Lt.test(e))
            }).map(function(e, t) {
                var n = ot(this).val();
                return null == n ? null: ot.isArray(n) ? ot.map(n,
                function(e) {
                    return {
                        name: t.name,
                        value: e.replace(Qn, "\r\n")
                    }
                }) : {
                    name: t.name,
                    value: n.replace(Qn, "\r\n")
                }
            }).get()
        }
    }),
    ot.ajaxSettings.xhr = void 0 !== e.ActiveXObject ?
    function() {
        return ! this.isLocal && /^(get|post|head|put|delete|options)$/i.test(this.type) && X() || U()
    }: X;
    var Zn = 0,
    er = {},
    tr = ot.ajaxSettings.xhr();
    e.ActiveXObject && ot(e).on("unload",
    function() {
        for (var e in er) er[e](void 0, !0)
    }),
    rt.cors = !!tr && "withCredentials" in tr,
    tr = rt.ajax = !!tr,
    tr && ot.ajaxTransport(function(e) {
        if (!e.crossDomain || rt.cors) {
            var t;
            return {
                send: function(n, r) {
                    var i, o = e.xhr(),
                    a = ++Zn;
                    if (o.open(e.type, e.url, e.async, e.username, e.password), e.xhrFields) for (i in e.xhrFields) o[i] = e.xhrFields[i];
                    e.mimeType && o.overrideMimeType && o.overrideMimeType(e.mimeType),
                    e.crossDomain || n["X-Requested-With"] || (n["X-Requested-With"] = "XMLHttpRequest");
                    for (i in n) void 0 !== n[i] && o.setRequestHeader(i, n[i] + "");
                    o.send(e.hasContent && e.data || null),
                    t = function(n, i) {
                        var s, l, u;
                        if (t && (i || 4 === o.readyState)) if (delete er[a], t = void 0, o.onreadystatechange = ot.noop, i) 4 !== o.readyState && o.abort();
                        else {
                            u = {},
                            s = o.status,
                            "string" == typeof o.responseText && (u.text = o.responseText);
                            try {
                                l = o.statusText
                            } catch(c) {
                                l = ""
                            }
                            s || !e.isLocal || e.crossDomain ? 1223 === s && (s = 204) : s = u.text ? 200 : 404
                        }
                        u && r(s, l, u, o.getAllResponseHeaders())
                    },
                    e.async ? 4 === o.readyState ? setTimeout(t) : o.onreadystatechange = er[a] = t: t()
                },
                abort: function() {
                    t && t(void 0, !0)
                }
            }
        }
    }),
    ot.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /(?:java|ecma)script/
        },
        converters: {
            "text script": function(e) {
                return ot.globalEval(e),
                e
            }
        }
    }),
    ot.ajaxPrefilter("script",
    function(e) {
        void 0 === e.cache && (e.cache = !1),
        e.crossDomain && (e.type = "GET", e.global = !1)
    }),
    ot.ajaxTransport("script",
    function(e) {
        if (e.crossDomain) {
            var t, n = mt.head || ot("head")[0] || mt.documentElement;
            return {
                send: function(r, i) {
                    t = mt.createElement("script"),
                    t.async = !0,
                    e.scriptCharset && (t.charset = e.scriptCharset),
                    t.src = e.url,
                    t.onload = t.onreadystatechange = function(e, n) { (n || !t.readyState || /loaded|complete/.test(t.readyState)) && (t.onload = t.onreadystatechange = null, t.parentNode && t.parentNode.removeChild(t), t = null, n || i(200, "success"))
                    },
                    n.insertBefore(t, n.firstChild)
                },
                abort: function() {
                    t && t.onload(void 0, !0)
                }
            }
        }
    });
    var nr = [],
    rr = /(=)\?(?=&|$)|\?\?/;
    ot.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var e = nr.pop() || ot.expando + "_" + _n++;
            return this[e] = !0,
            e
        }
    }),
    ot.ajaxPrefilter("json jsonp",
    function(t, n, r) {
        var i, o, a, s = t.jsonp !== !1 && (rr.test(t.url) ? "url": "string" == typeof t.data && !(t.contentType || "").indexOf("application/x-www-form-urlencoded") && rr.test(t.data) && "data");
        return s || "jsonp" === t.dataTypes[0] ? (i = t.jsonpCallback = ot.isFunction(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback, s ? t[s] = t[s].replace(rr, "$1" + i) : t.jsonp !== !1 && (t.url += (Hn.test(t.url) ? "&": "?") + t.jsonp + "=" + i), t.converters["script json"] = function() {
            return a || ot.error(i + " was not called"),
            a[0]
        },
        t.dataTypes[0] = "json", o = e[i], e[i] = function() {
            a = arguments
        },
        r.always(function() {
            e[i] = o,
            t[i] && (t.jsonpCallback = n.jsonpCallback, nr.push(i)),
            a && ot.isFunction(o) && o(a[0]),
            a = o = void 0
        }), "script") : void 0
    }),
    ot.parseHTML = function(e, t, n) {
        if (!e || "string" != typeof e) return null;
        "boolean" == typeof t && (n = t, t = !1),
        t = t || mt;
        var r = ft.exec(e),
        i = !n && [];
        return r ? [t.createElement(r[1])] : (r = ot.buildFragment([e], t, i), i && i.length && ot(i).remove(), ot.merge([], r.childNodes))
    };
    var ir = ot.fn.load;
    ot.fn.load = function(e, t, n) {
        if ("string" != typeof e && ir) return ir.apply(this, arguments);
        var r, i, o, a = this,
        s = e.indexOf(" ");
        return s >= 0 && (r = e.slice(s, e.length), e = e.slice(0, s)),
        ot.isFunction(t) ? (n = t, t = void 0) : t && "object" == typeof t && (o = "POST"),
        a.length > 0 && ot.ajax({
            url: e,
            type: o,
            dataType: "html",
            data: t
        }).done(function(e) {
            i = arguments,
            a.html(r ? ot("<div>").append(ot.parseHTML(e)).find(r) : e)
        }).complete(n &&
        function(e, t) {
            a.each(n, i || [e.responseText, t, e])
        }),
        this
    },
    ot.expr.filters.animated = function(e) {
        return ot.grep(ot.timers,
        function(t) {
            return e === t.elem
        }).length
    };
    var or = e.document.documentElement;
    ot.offset = {
        setOffset: function(e, t, n) {
            var r, i, o, a, s, l, u, c = ot.css(e, "position"),
            d = ot(e),
            f = {};
            "static" === c && (e.style.position = "relative"),
            s = d.offset(),
            o = ot.css(e, "top"),
            l = ot.css(e, "left"),
            u = ("absolute" === c || "fixed" === c) && ot.inArray("auto", [o, l]) > -1,
            u ? (r = d.position(), a = r.top, i = r.left) : (a = parseFloat(o) || 0, i = parseFloat(l) || 0),
            ot.isFunction(t) && (t = t.call(e, n, s)),
            null != t.top && (f.top = t.top - s.top + a),
            null != t.left && (f.left = t.left - s.left + i),
            "using" in t ? t.using.call(e, f) : d.css(f)
        }
    },
    ot.fn.extend({
        offset: function(e) {
            if (arguments.length) return void 0 === e ? this: this.each(function(t) {
                ot.offset.setOffset(this, e, t)
            });
            var t, n, r = {
                top: 0,
                left: 0
            },
            i = this[0],
            o = i && i.ownerDocument;
            if (o) return t = o.documentElement,
            ot.contains(t, i) ? (typeof i.getBoundingClientRect !== Nt && (r = i.getBoundingClientRect()), n = V(o), {
                top: r.top + (n.pageYOffset || t.scrollTop) - (t.clientTop || 0),
                left: r.left + (n.pageXOffset || t.scrollLeft) - (t.clientLeft || 0)
            }) : r
        },
        position: function() {
            if (this[0]) {
                var e, t, n = {
                    top: 0,
                    left: 0
                },
                r = this[0];
                return "fixed" === ot.css(r, "position") ? t = r.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), ot.nodeName(e[0], "html") || (n = e.offset()), n.top += ot.css(e[0], "borderTopWidth", !0), n.left += ot.css(e[0], "borderLeftWidth", !0)),
                {
                    top: t.top - n.top - ot.css(r, "marginTop", !0),
                    left: t.left - n.left - ot.css(r, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var e = this.offsetParent || or; e && !ot.nodeName(e, "html") && "static" === ot.css(e, "position");) e = e.offsetParent;
                return e || or
            })
        }
    }),
    ot.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    },
    function(e, t) {
        var n = /Y/.test(t);
        ot.fn[e] = function(r) {
            return jt(this,
            function(e, r, i) {
                var o = V(e);
                return void 0 === i ? o ? t in o ? o[t] : o.document.documentElement[r] : e[r] : void(o ? o.scrollTo(n ? ot(o).scrollLeft() : i, n ? i: ot(o).scrollTop()) : e[r] = i)
            },
            e, r, arguments.length, null)
        }
    }),
    ot.each(["top", "left"],
    function(e, t) {
        ot.cssHooks[t] = k(rt.pixelPosition,
        function(e, n) {
            return n ? (n = nn(e, t), on.test(n) ? ot(e).position()[t] + "px": n) : void 0
        })
    }),
    ot.each({
        Height: "height",
        Width: "width"
    },
    function(e, t) {
        ot.each({
            padding: "inner" + e,
            content: t,
            "": "outer" + e
        },
        function(n, r) {
            ot.fn[r] = function(r, i) {
                var o = arguments.length && (n || "boolean" != typeof r),
                a = n || (r === !0 || i === !0 ? "margin": "border");
                return jt(this,
                function(t, n, r) {
                    var i;
                    return ot.isWindow(t) ? t.document.documentElement["client" + e] : 9 === t.nodeType ? (i = t.documentElement, Math.max(t.body["scroll" + e], i["scroll" + e], t.body["offset" + e], i["offset" + e], i["client" + e])) : void 0 === r ? ot.css(t, n, a) : ot.style(t, n, r, a)
                },
                t, o ? r: void 0, o, null)
            }
        })
    }),
    ot.fn.size = function() {
        return this.length
    },
    ot.fn.andSelf = ot.fn.addBack,
    "function" == typeof define && define.amd && define("jquery", [],
    function() {
        return ot
    });
    var ar = e.jQuery,
    sr = e.$;
    return ot.noConflict = function(t) {
        return e.$ === ot && (e.$ = sr),
        t && e.jQuery === ot && (e.jQuery = ar),
        ot
    },
    typeof t === Nt && (e.jQuery = e.$ = ot),
    ot
}),
function(e, t) {
    var n = 0,
    r = Array.prototype.slice,
    i = e.cleanData;
    e.cleanData = function(t) {
        for (var n, r = 0; null != (n = t[r]); r++) try {
            e(n).triggerHandler("remove")
        } catch(o) {}
        i(t)
    },
    e.widget = function(n, r, i) {
        var o, a, s, l, u = {},
        c = n.split(".")[0];
        n = n.split(".")[1],
        o = c + "-" + n,
        i || (i = r, r = e.Widget),
        e.expr[":"][o.toLowerCase()] = function(t) {
            return !! e.data(t, o)
        },
        e[c] = e[c] || {},
        a = e[c][n],
        s = e[c][n] = function(e, n) {
            return this._createWidget ? (arguments.length && this._createWidget(e, n), t) : new s(e, n)
        },
        e.extend(s, a, {
            version: i.version,
            _proto: e.extend({},
            i),
            _childConstructors: []
        }),
        l = new r,
        l.options = e.widget.extend({},
        l.options),
        e.each(i,
        function(n, i) {
            return e.isFunction(i) ? (u[n] = function() {
                var e = function() {
                    return r.prototype[n].apply(this, arguments)
                },
                t = function(e) {
                    return r.prototype[n].apply(this, e)
                };
                return function() {
                    var n, r = this._super,
                    o = this._superApply;
                    return this._super = e,
                    this._superApply = t,
                    n = i.apply(this, arguments),
                    this._super = r,
                    this._superApply = o,
                    n
                }
            } (), t) : (u[n] = i, t)
        }),
        s.prototype = e.widget.extend(l, {
            widgetEventPrefix: a ? l.widgetEventPrefix: n
        },
        u, {
            constructor: s,
            namespace: c,
            widgetName: n,
            widgetFullName: o
        }),
        a ? (e.each(a._childConstructors,
        function(t, n) {
            var r = n.prototype;
            e.widget(r.namespace + "." + r.widgetName, s, n._proto)
        }), delete a._childConstructors) : r._childConstructors.push(s),
        e.widget.bridge(n, s)
    },
    e.widget.extend = function(n) {
        for (var i, o, a = r.call(arguments, 1), s = 0, l = a.length; l > s; s++) for (i in a[s]) o = a[s][i],
        a[s].hasOwnProperty(i) && o !== t && (n[i] = e.isPlainObject(o) ? e.isPlainObject(n[i]) ? e.widget.extend({},
        n[i], o) : e.widget.extend({},
        o) : o);
        return n
    },
    e.widget.bridge = function(n, i) {
        var o = i.prototype.widgetFullName || n;
        e.fn[n] = function(a) {
            var s = "string" == typeof a,
            l = r.call(arguments, 1),
            u = this;
            return a = !s && l.length ? e.widget.extend.apply(null, [a].concat(l)) : a,
            this.each(s ?
            function() {
                var r, i = e.data(this, o);
                return i ? e.isFunction(i[a]) && "_" !== a.charAt(0) ? (r = i[a].apply(i, l), r !== i && r !== t ? (u = r && r.jquery ? u.pushStack(r.get()) : r, !1) : t) : e.error("no such method '" + a + "' for " + n + " widget instance") : e.error("cannot call methods on " + n + " prior to initialization; attempted to call method '" + a + "'")
            }: function() {
                var t = e.data(this, o);
                t ? t.option(a || {})._init() : e.data(this, o, new i(a, this))
            }),
            u
        }
    },
    e.Widget = function() {},
    e.Widget._childConstructors = [],
    e.Widget.prototype = {
        widgetName: "widget",
        widgetEventPrefix: "",
        defaultElement: "<div>",
        options: {
            disabled: !1,
            create: null
        },
        _createWidget: function(t, r) {
            r = e(r || this.defaultElement || this)[0],
            this.element = e(r),
            this.uuid = n++,
            this.eventNamespace = "." + this.widgetName + this.uuid,
            this.options = e.widget.extend({},
            this.options, this._getCreateOptions(), t),
            this.bindings = e(),
            this.hoverable = e(),
            this.focusable = e(),
            r !== this && (e.data(r, this.widgetFullName, this), this._on(!0, this.element, {
                remove: function(e) {
                    e.target === r && this.destroy()
                }
            }), this.document = e(r.style ? r.ownerDocument: r.document || r), this.window = e(this.document[0].defaultView || this.document[0].parentWindow)),
            this._create(),
            this._trigger("create", null, this._getCreateEventData()),
            this._init()
        },
        _getCreateOptions: e.noop,
        _getCreateEventData: e.noop,
        _create: e.noop,
        _init: e.noop,
        destroy: function() {
            this._destroy(),
            this.element.unbind(this.eventNamespace).removeData(this.widgetName).removeData(this.widgetFullName).removeData(e.camelCase(this.widgetFullName)),
            this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName + "-disabled ui-state-disabled"),
            this.bindings.unbind(this.eventNamespace),
            this.hoverable.removeClass("ui-state-hover"),
            this.focusable.removeClass("ui-state-focus")
        },
        _destroy: e.noop,
        widget: function() {
            return this.element
        },
        option: function(n, r) {
            var i, o, a, s = n;
            if (0 === arguments.length) return e.widget.extend({},
            this.options);
            if ("string" == typeof n) if (s = {},
            i = n.split("."), n = i.shift(), i.length) {
                for (o = s[n] = e.widget.extend({},
                this.options[n]), a = 0; i.length - 1 > a; a++) o[i[a]] = o[i[a]] || {},
                o = o[i[a]];
                if (n = i.pop(), r === t) return o[n] === t ? null: o[n];
                o[n] = r
            } else {
                if (r === t) return this.options[n] === t ? null: this.options[n];
                s[n] = r
            }
            return this._setOptions(s),
            this
        },
        _setOptions: function(e) {
            var t;
            for (t in e) this._setOption(t, e[t]);
            return this
        },
        _setOption: function(e, t) {
            return this.options[e] = t,
            "disabled" === e && (this.widget().toggleClass(this.widgetFullName + "-disabled ui-state-disabled", !!t).attr("aria-disabled", t), this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus")),
            this
        },
        enable: function() {
            return this._setOption("disabled", !1)
        },
        disable: function() {
            return this._setOption("disabled", !0)
        },
        _on: function(n, r, i) {
            var o, a = this;
            "boolean" != typeof n && (i = r, r = n, n = !1),
            i ? (r = o = e(r), this.bindings = this.bindings.add(r)) : (i = r, r = this.element, o = this.widget()),
            e.each(i,
            function(i, s) {
                function l() {
                    return n || a.options.disabled !== !0 && !e(this).hasClass("ui-state-disabled") ? ("string" == typeof s ? a[s] : s).apply(a, arguments) : t
                }
                "string" != typeof s && (l.guid = s.guid = s.guid || l.guid || e.guid++);
                var u = i.match(/^(\w+)\s*(.*)$/),
                c = u[1] + a.eventNamespace,
                d = u[2];
                d ? o.delegate(d, c, l) : r.bind(c, l)
            })
        },
        _off: function(e, t) {
            t = (t || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace,
            e.unbind(t).undelegate(t)
        },
        _delay: function(e, t) {
            function n() {
                return ("string" == typeof e ? r[e] : e).apply(r, arguments)
            }
            var r = this;
            return setTimeout(n, t || 0)
        },
        _hoverable: function(t) {
            this.hoverable = this.hoverable.add(t),
            this._on(t, {
                mouseenter: function(t) {
                    e(t.currentTarget).addClass("ui-state-hover")
                },
                mouseleave: function(t) {
                    e(t.currentTarget).removeClass("ui-state-hover")
                }
            })
        },
        _focusable: function(t) {
            this.focusable = this.focusable.add(t),
            this._on(t, {
                focusin: function(t) {
                    e(t.currentTarget).addClass("ui-state-focus")
                },
                focusout: function(t) {
                    e(t.currentTarget).removeClass("ui-state-focus")
                }
            })
        },
        _trigger: function(t, n, r) {
            var i, o, a = this.options[t];
            if (r = r || {},
            n = e.Event(n), n.type = (t === this.widgetEventPrefix ? t: this.widgetEventPrefix + t).toLowerCase(), n.target = this.element[0], o = n.originalEvent) for (i in o) i in n || (n[i] = o[i]);
            return this.element.trigger(n, r),
            !(e.isFunction(a) && a.apply(this.element[0], [n].concat(r)) === !1 || n.isDefaultPrevented())
        }
    },
    e.each({
        show: "fadeIn",
        hide: "fadeOut"
    },
    function(t, n) {
        e.Widget.prototype["_" + t] = function(r, i, o) {
            "string" == typeof i && (i = {
                effect: i
            });
            var a, s = i ? i === !0 || "number" == typeof i ? n: i.effect || n: t;
            i = i || {},
            "number" == typeof i && (i = {
                duration: i
            }),
            a = !e.isEmptyObject(i),
            i.complete = o,
            i.delay && r.delay(i.delay),
            a && e.effects && e.effects.effect[s] ? r[t](i) : s !== t && r[s] ? r[s](i.duration, i.easing, o) : r.queue(function(n) {
                e(this)[t](),
                o && o.call(r[0]),
                n()
            })
        }
    })
} (jQuery),
function(e) {
    "function" == typeof define && define.amd ? define(["jquery"], e) : "object" == typeof exports ? module.exports = e: e(jQuery)
} (function(e) {
    function t(t) {
        var i, o = t || window.event,
        a = [].slice.call(arguments, 1),
        s = 0,
        l = 0,
        u = 0,
        c = 0,
        d = 0;
        return t = e.event.fix(o),
        t.type = "mousewheel",
        o.wheelDelta && (s = o.wheelDelta),
        o.detail && (s = -1 * o.detail),
        o.deltaY && (u = -1 * o.deltaY, s = u),
        o.deltaX && (l = o.deltaX, s = -1 * l),
        void 0 !== o.wheelDeltaY && (u = o.wheelDeltaY),
        void 0 !== o.wheelDeltaX && (l = -1 * o.wheelDeltaX),
        c = Math.abs(s),
        (!n || n > c) && (n = c),
        d = Math.max(Math.abs(u), Math.abs(l)),
        (!r || r > d) && (r = d),
        i = s > 0 ? "floor": "ceil",
        s = Math[i](s / n),
        l = Math[i](l / r),
        u = Math[i](u / r),
        a.unshift(t, s, l, u),
        (e.event.dispatch || e.event.handle).apply(this, a)
    }
    var n, r, i = ["wheel", "mousewheel", "DOMMouseScroll", "MozMousePixelScroll"],
    o = "onwheel" in document || document.documentMode >= 9 ? ["wheel"] : ["mousewheel", "DomMouseScroll", "MozMousePixelScroll"];
    if (e.event.fixHooks) for (var a = i.length; a;) e.event.fixHooks[i[--a]] = e.event.mouseHooks;
    e.event.special.mousewheel = {
        setup: function() {
            if (this.addEventListener) for (var e = o.length; e;) this.addEventListener(o[--e], t, !1);
            else this.onmousewheel = t
        },
        teardown: function() {
            if (this.removeEventListener) for (var e = o.length; e;) this.removeEventListener(o[--e], t, !1);
            else this.onmousewheel = null
        }
    },
    e.fn.extend({
        mousewheel: function(e) {
            return e ? this.bind("mousewheel", e) : this.trigger("mousewheel")
        },
        unmousewheel: function(e) {
            return this.unbind("mousewheel", e)
        }
    })
});; !
function(t) {
    "use strict";
    t.ajaxPrefilter(function(t) {
        return t.iframe ? (t.originalURL = t.url, "iframe") : void 0
    }),
    t.ajaxTransport("iframe",
    function(e, a) {
        function n() {
            d.each(function(e, a) {
                var n = t(a);
                n.data("clone").replaceWith(n)
            }),
            i.remove(),
            o.one("load",
            function() {
                o.remove()
            }),
            o.attr("src", "javascript:false;")
        }
        var i = null,
        o = null,
        r = "iframe-" + t.now(),
        d = t(e.files).filter(":file:enabled"),
        l = null,
        u = null;
        return e.dataTypes.shift(),
        e.data = a.data,
        d.length ? (i = t("<form enctype='multipart/form-data' method='post'></form>").hide().attr({
            action: e.originalURL,
            target: r
        }), "string" == typeof e.data && e.data.length > 0 && t.error("data must not be serialized"), t.each(e.data || {},
        function(e, a) {
            t.isPlainObject(a) && (e = a.name, a = a.value),
            t("<input type='hidden' />").attr({
                name: e,
                value: a
            }).appendTo(i)
        }), t("<input type='hidden' value='IFrame' name='X-Requested-With' />").appendTo(i), u = e.dataTypes[0] && e.accepts[e.dataTypes[0]] ? e.accepts[e.dataTypes[0]] + ("*" !== e.dataTypes[0] ? ", */*; q=0.01": "") : e.accepts["*"], t("<input type='hidden' name='X-HTTP-Accept'>").attr("value", u).appendTo(i), l = d.after(function() {
            var e = t(this),
            a = e.clone().prop("disabled", !0);
            return e.data("clone", a),
            a
        }).next(), d.appendTo(i), {
            send: function(e, a) {
                o = t("<iframe src='javascript:false;' name='" + r + "' id='" + r + "' style='display:none'></iframe>"),
                o.one("load",
                function() {
                    o.one("load",
                    function() {
                        var t = this.contentWindow ? this.contentWindow.document: this.contentDocument ? this.contentDocument: this.document,
                        e = t.documentElement ? t.documentElement: t.body,
                        i = e.getElementsByTagName("textarea")[0],
                        o = i && i.getAttribute("data-type") || null,
                        r = i && i.getAttribute("data-status") || 200,
                        d = i && i.getAttribute("data-statusText") || "OK",
                        l = {
                            html: e.innerHTML,
                            text: o ? i.value: e ? e.textContent || e.innerText: null
                        };
                        n(),
                        a(r, d, l, o ? "Content-Type: " + o: null)
                    }),
                    i[0].submit()
                }),
                t("body").append(i, o)
            },
            abort: function() {
                null !== o && (o.unbind("load").attr("src", "javascript:false;"), n())
            }
        }) : void 0
    })
} (jQuery);; (function() {
    var n = this,
    t = n._,
    r = {},
    e = Array.prototype,
    u = Object.prototype,
    i = Function.prototype,
    a = e.push,
    o = e.slice,
    c = e.concat,
    l = (e.unshift, u.toString),
    f = u.hasOwnProperty,
    s = e.forEach,
    p = e.map,
    h = e.reduce,
    v = e.reduceRight,
    g = e.filter,
    m = e.every,
    d = e.some,
    y = e.indexOf,
    b = e.lastIndexOf,
    x = Array.isArray,
    _ = Object.keys,
    j = i.bind,
    w = function(n) {
        return n instanceof w ? n: this instanceof w ? void(this._wrapped = n) : new w(n)
    };
    "undefined" != typeof exports ? ("undefined" != typeof module && module.exports && (exports = module.exports = w), exports._ = w) : n._ = w,
    w.VERSION = "1.4.2";
    var O = w.each = w.forEach = function(n, t, e) {
        if (null != n) if (s && n.forEach === s) n.forEach(t, e);
        else if (n.length === +n.length) {
            for (var u = 0,
            i = n.length; i > u; u++) if (t.call(e, n[u], u, n) === r) return
        } else for (var a in n) if (w.has(n, a) && t.call(e, n[a], a, n) === r) return
    };
    w.map = w.collect = function(n, t, r) {
        var e = [];
        return null == n ? e: p && n.map === p ? n.map(t, r) : (O(n,
        function(n, u, i) {
            e[e.length] = t.call(r, n, u, i)
        }), e)
    },
    w.reduce = w.foldl = w.inject = function(n, t, r, e) {
        var u = arguments.length > 2;
        if (null == n && (n = []), h && n.reduce === h) return e && (t = w.bind(t, e)),
        u ? n.reduce(t, r) : n.reduce(t);
        if (O(n,
        function(n, i, a) {
            u ? r = t.call(e, r, n, i, a) : (r = n, u = !0)
        }), !u) throw new TypeError("Reduce of empty array with no initial value");
        return r
    },
    w.reduceRight = w.foldr = function(n, t, r, e) {
        var u = arguments.length > 2;
        if (null == n && (n = []), v && n.reduceRight === v) return e && (t = w.bind(t, e)),
        arguments.length > 2 ? n.reduceRight(t, r) : n.reduceRight(t);
        var i = n.length;
        if (i !== +i) {
            var a = w.keys(n);
            i = a.length
        }
        if (O(n,
        function(o, c, l) {
            c = a ? a[--i] : --i,
            u ? r = t.call(e, r, n[c], c, l) : (r = n[c], u = !0)
        }), !u) throw new TypeError("Reduce of empty array with no initial value");
        return r
    },
    w.find = w.detect = function(n, t, r) {
        var e;
        return E(n,
        function(n, u, i) {
            return t.call(r, n, u, i) ? (e = n, !0) : void 0
        }),
        e
    },
    w.filter = w.select = function(n, t, r) {
        var e = [];
        return null == n ? e: g && n.filter === g ? n.filter(t, r) : (O(n,
        function(n, u, i) {
            t.call(r, n, u, i) && (e[e.length] = n)
        }), e)
    },
    w.reject = function(n, t, r) {
        var e = [];
        return null == n ? e: (O(n,
        function(n, u, i) {
            t.call(r, n, u, i) || (e[e.length] = n)
        }), e)
    },
    w.every = w.all = function(n, t, e) {
        t || (t = w.identity);
        var u = !0;
        return null == n ? u: m && n.every === m ? n.every(t, e) : (O(n,
        function(n, i, a) {
            return (u = u && t.call(e, n, i, a)) ? void 0 : r
        }), !!u)
    };
    var E = w.some = w.any = function(n, t, e) {
        t || (t = w.identity);
        var u = !1;
        return null == n ? u: d && n.some === d ? n.some(t, e) : (O(n,
        function(n, i, a) {
            return u || (u = t.call(e, n, i, a)) ? r: void 0
        }), !!u)
    };
    w.contains = w.include = function(n, t) {
        var r = !1;
        return null == n ? r: y && n.indexOf === y ? -1 != n.indexOf(t) : r = E(n,
        function(n) {
            return n === t
        })
    },
    w.invoke = function(n, t) {
        var r = o.call(arguments, 2);
        return w.map(n,
        function(n) {
            return (w.isFunction(t) ? t: n[t]).apply(n, r)
        })
    },
    w.pluck = function(n, t) {
        return w.map(n,
        function(n) {
            return n[t]
        })
    },
    w.where = function(n, t) {
        return w.isEmpty(t) ? [] : w.filter(n,
        function(n) {
            for (var r in t) if (t[r] !== n[r]) return ! 1;
            return ! 0
        })
    },
    w.max = function(n, t, r) {
        if (!t && w.isArray(n) && n[0] === +n[0] && n.length < 65535) return Math.max.apply(Math, n);
        if (!t && w.isEmpty(n)) return - 1 / 0;
        var e = {
            computed: -1 / 0
        };
        return O(n,
        function(n, u, i) {
            var a = t ? t.call(r, n, u, i) : n;
            a >= e.computed && (e = {
                value: n,
                computed: a
            })
        }),
        e.value
    },
    w.min = function(n, t, r) {
        if (!t && w.isArray(n) && n[0] === +n[0] && n.length < 65535) return Math.min.apply(Math, n);
        if (!t && w.isEmpty(n)) return 1 / 0;
        var e = {
            computed: 1 / 0
        };
        return O(n,
        function(n, u, i) {
            var a = t ? t.call(r, n, u, i) : n;
            a < e.computed && (e = {
                value: n,
                computed: a
            })
        }),
        e.value
    },
    w.shuffle = function(n) {
        var t, r = 0,
        e = [];
        return O(n,
        function(n) {
            t = w.random(r++),
            e[r - 1] = e[t],
            e[t] = n
        }),
        e
    };
    var A = function(n) {
        return w.isFunction(n) ? n: function(t) {
            return t[n]
        }
    };
    w.sortBy = function(n, t, r) {
        var e = A(t);
        return w.pluck(w.map(n,
        function(n, t, u) {
            return {
                value: n,
                index: t,
                criteria: e.call(r, n, t, u)
            }
        }).sort(function(n, t) {
            var r = n.criteria,
            e = t.criteria;
            if (r !== e) {
                if (r > e || void 0 === r) return 1;
                if (e > r || void 0 === e) return - 1
            }
            return n.index < t.index ? -1 : 1
        }), "value")
    };
    var k = function(n, t, r, e) {
        var u = {},
        i = A(t);
        return O(n,
        function(t, a) {
            var o = i.call(r, t, a, n);
            e(u, o, t)
        }),
        u
    };
    w.groupBy = function(n, t, r) {
        return k(n, t, r,
        function(n, t, r) { (w.has(n, t) ? n[t] : n[t] = []).push(r)
        })
    },
    w.countBy = function(n, t, r) {
        return k(n, t, r,
        function(n, t) {
            w.has(n, t) || (n[t] = 0),
            n[t]++
        })
    },
    w.sortedIndex = function(n, t, r, e) {
        r = null == r ? w.identity: A(r);
        for (var u = r.call(e, t), i = 0, a = n.length; a > i;) {
            var o = i + a >>> 1;
            r.call(e, n[o]) < u ? i = o + 1 : a = o
        }
        return i
    },
    w.toArray = function(n) {
        return n ? n.length === +n.length ? o.call(n) : w.values(n) : []
    },
    w.size = function(n) {
        return n.length === +n.length ? n.length: w.keys(n).length
    },
    w.first = w.head = w.take = function(n, t, r) {
        return null == t || r ? n[0] : o.call(n, 0, t)
    },
    w.initial = function(n, t, r) {
        return o.call(n, 0, n.length - (null == t || r ? 1 : t))
    },
    w.last = function(n, t, r) {
        return null == t || r ? n[n.length - 1] : o.call(n, Math.max(n.length - t, 0))
    },
    w.rest = w.tail = w.drop = function(n, t, r) {
        return o.call(n, null == t || r ? 1 : t)
    },
    w.compact = function(n) {
        return w.filter(n,
        function(n) {
            return !! n
        })
    };
    var F = function(n, t, r) {
        return O(n,
        function(n) {
            w.isArray(n) ? t ? a.apply(r, n) : F(n, t, r) : r.push(n)
        }),
        r
    };
    w.flatten = function(n, t) {
        return F(n, t, [])
    },
    w.without = function(n) {
        return w.difference(n, o.call(arguments, 1))
    },
    w.uniq = w.unique = function(n, t, r, e) {
        var u = r ? w.map(n, r, e) : n,
        i = [],
        a = [];
        return O(u,
        function(r, e) { (t ? e && a[a.length - 1] === r: w.contains(a, r)) || (a.push(r), i.push(n[e]))
        }),
        i
    },
    w.union = function() {
        return w.uniq(c.apply(e, arguments))
    },
    w.intersection = function(n) {
        var t = o.call(arguments, 1);
        return w.filter(w.uniq(n),
        function(n) {
            return w.every(t,
            function(t) {
                return w.indexOf(t, n) >= 0
            })
        })
    },
    w.difference = function(n) {
        var t = c.apply(e, o.call(arguments, 1));
        return w.filter(n,
        function(n) {
            return ! w.contains(t, n)
        })
    },
    w.zip = function() {
        for (var n = o.call(arguments), t = w.max(w.pluck(n, "length")), r = new Array(t), e = 0; t > e; e++) r[e] = w.pluck(n, "" + e);
        return r
    },
    w.object = function(n, t) {
        for (var r = {},
        e = 0,
        u = n.length; u > e; e++) t ? r[n[e]] = t[e] : r[n[e][0]] = n[e][1];
        return r
    },
    w.indexOf = function(n, t, r) {
        if (null == n) return - 1;
        var e = 0,
        u = n.length;
        if (r) {
            if ("number" != typeof r) return e = w.sortedIndex(n, t),
            n[e] === t ? e: -1;
            e = 0 > r ? Math.max(0, u + r) : r
        }
        if (y && n.indexOf === y) return n.indexOf(t, r);
        for (; u > e; e++) if (n[e] === t) return e;
        return - 1
    },
    w.lastIndexOf = function(n, t, r) {
        if (null == n) return - 1;
        var e = null != r;
        if (b && n.lastIndexOf === b) return e ? n.lastIndexOf(t, r) : n.lastIndexOf(t);
        for (var u = e ? r: n.length; u--;) if (n[u] === t) return u;
        return - 1
    },
    w.range = function(n, t, r) {
        arguments.length <= 1 && (t = n || 0, n = 0),
        r = arguments[2] || 1;
        for (var e = Math.max(Math.ceil((t - n) / r), 0), u = 0, i = new Array(e); e > u;) i[u++] = n,
        n += r;
        return i
    };
    var R = function() {};
    w.bind = function(n, t) {
        var r, e;
        if (n.bind === j && j) return j.apply(n, o.call(arguments, 1));
        if (!w.isFunction(n)) throw new TypeError;
        return e = o.call(arguments, 2),
        r = function() {
            if (! (this instanceof r)) return n.apply(t, e.concat(o.call(arguments)));
            R.prototype = n.prototype;
            var u = new R,
            i = n.apply(u, e.concat(o.call(arguments)));
            return Object(i) === i ? i: u
        }
    },
    w.bindAll = function(n) {
        var t = o.call(arguments, 1);
        return 0 == t.length && (t = w.functions(n)),
        O(t,
        function(t) {
            n[t] = w.bind(n[t], n)
        }),
        n
    },
    w.memoize = function(n, t) {
        var r = {};
        return t || (t = w.identity),
        function() {
            var e = t.apply(this, arguments);
            return w.has(r, e) ? r[e] : r[e] = n.apply(this, arguments)
        }
    },
    w.delay = function(n, t) {
        var r = o.call(arguments, 2);
        return setTimeout(function() {
            return n.apply(null, r)
        },
        t)
    },
    w.defer = function(n) {
        return w.delay.apply(w, [n, 1].concat(o.call(arguments, 1)))
    },
    w.throttle = function(n, t) {
        var r, e, u, i, a, o, c = w.debounce(function() {
            a = i = !1
        },
        t);
        return function() {
            r = this,
            e = arguments;
            var l = function() {
                u = null,
                a && (o = n.apply(r, e)),
                c()
            };
            return u || (u = setTimeout(l, t)),
            i ? a = !0 : (i = !0, o = n.apply(r, e)),
            c(),
            o
        }
    },
    w.debounce = function(n, t, r) {
        var e, u;
        return function() {
            var i = this,
            a = arguments,
            o = function() {
                e = null,
                r || (u = n.apply(i, a))
            },
            c = r && !e;
            return clearTimeout(e),
            e = setTimeout(o, t),
            c && (u = n.apply(i, a)),
            u
        }
    },
    w.once = function(n) {
        var t, r = !1;
        return function() {
            return r ? t: (r = !0, t = n.apply(this, arguments), n = null, t)
        }
    },
    w.wrap = function(n, t) {
        return function() {
            var r = [n];
            return a.apply(r, arguments),
            t.apply(this, r)
        }
    },
    w.compose = function() {
        var n = arguments;
        return function() {
            for (var t = arguments,
            r = n.length - 1; r >= 0; r--) t = [n[r].apply(this, t)];
            return t[0]
        }
    },
    w.after = function(n, t) {
        return 0 >= n ? t() : function() {
            return--n < 1 ? t.apply(this, arguments) : void 0
        }
    },
    w.keys = _ ||
    function(n) {
        if (n !== Object(n)) throw new TypeError("Invalid object");
        var t = [];
        for (var r in n) w.has(n, r) && (t[t.length] = r);
        return t
    },
    w.values = function(n) {
        var t = [];
        for (var r in n) w.has(n, r) && t.push(n[r]);
        return t
    },
    w.pairs = function(n) {
        var t = [];
        for (var r in n) w.has(n, r) && t.push([r, n[r]]);
        return t
    },
    w.invert = function(n) {
        var t = {};
        for (var r in n) w.has(n, r) && (t[n[r]] = r);
        return t
    },
    w.functions = w.methods = function(n) {
        var t = [];
        for (var r in n) w.isFunction(n[r]) && t.push(r);
        return t.sort()
    },
    w.extend = function(n) {
        return O(o.call(arguments, 1),
        function(t) {
            for (var r in t) n[r] = t[r]
        }),
        n
    },
    w.pick = function(n) {
        var t = {},
        r = c.apply(e, o.call(arguments, 1));
        return O(r,
        function(r) {
            r in n && (t[r] = n[r])
        }),
        t
    },
    w.omit = function(n) {
        var t = {},
        r = c.apply(e, o.call(arguments, 1));
        for (var u in n) w.contains(r, u) || (t[u] = n[u]);
        return t
    },
    w.defaults = function(n) {
        return O(o.call(arguments, 1),
        function(t) {
            for (var r in t) null == n[r] && (n[r] = t[r])
        }),
        n
    },
    w.clone = function(n) {
        return w.isObject(n) ? w.isArray(n) ? n.slice() : w.extend({},
        n) : n
    },
    w.tap = function(n, t) {
        return t(n),
        n
    };
    var S = function(n, t, r, e) {
        if (n === t) return 0 !== n || 1 / n == 1 / t;
        if (null == n || null == t) return n === t;
        n instanceof w && (n = n._wrapped),
        t instanceof w && (t = t._wrapped);
        var u = l.call(n);
        if (u != l.call(t)) return ! 1;
        switch (u) {
        case "[object String]":
            return n == String(t);
        case "[object Number]":
            return n != +n ? t != +t: 0 == n ? 1 / n == 1 / t: n == +t;
        case "[object Date]":
        case "[object Boolean]":
            return + n == +t;
        case "[object RegExp]":
            return n.source == t.source && n.global == t.global && n.multiline == t.multiline && n.ignoreCase == t.ignoreCase
        }
        if ("object" != typeof n || "object" != typeof t) return ! 1;
        for (var i = r.length; i--;) if (r[i] == n) return e[i] == t;
        r.push(n),
        e.push(t);
        var a = 0,
        o = !0;
        if ("[object Array]" == u) {
            if (a = n.length, o = a == t.length) for (; a--&&(o = S(n[a], t[a], r, e)););
        } else {
            var c = n.constructor,
            f = t.constructor;
            if (c !== f && !(w.isFunction(c) && c instanceof c && w.isFunction(f) && f instanceof f)) return ! 1;
            for (var s in n) if (w.has(n, s) && (a++, !(o = w.has(t, s) && S(n[s], t[s], r, e)))) break;
            if (o) {
                for (s in t) if (w.has(t, s) && !a--) break;
                o = !a
            }
        }
        return r.pop(),
        e.pop(),
        o
    };
    w.isEqual = function(n, t) {
        return S(n, t, [], [])
    },
    w.isEmpty = function(n) {
        if (null == n) return ! 0;
        if (w.isArray(n) || w.isString(n)) return 0 === n.length;
        for (var t in n) if (w.has(n, t)) return ! 1;
        return ! 0
    },
    w.isElement = function(n) {
        return ! (!n || 1 !== n.nodeType)
    },
    w.isArray = x ||
    function(n) {
        return "[object Array]" == l.call(n)
    },
    w.isObject = function(n) {
        return n === Object(n)
    },
    O(["Arguments", "Function", "String", "Number", "Date", "RegExp"],
    function(n) {
        w["is" + n] = function(t) {
            return l.call(t) == "[object " + n + "]"
        }
    }),
    w.isArguments(arguments) || (w.isArguments = function(n) {
        return ! (!n || !w.has(n, "callee"))
    }),
    "function" != typeof / . / &&(w.isFunction = function(n) {
        return "function" == typeof n
    }),
    w.isFinite = function(n) {
        return w.isNumber(n) && isFinite(n)
    },
    w.isNaN = function(n) {
        return w.isNumber(n) && n != +n
    },
    w.isBoolean = function(n) {
        return n === !0 || n === !1 || "[object Boolean]" == l.call(n)
    },
    w.isNull = function(n) {
        return null === n
    },
    w.isUndefined = function(n) {
        return void 0 === n
    },
    w.has = function(n, t) {
        return f.call(n, t)
    },
    w.noConflict = function() {
        return n._ = t,
        this
    },
    w.identity = function(n) {
        return n
    },
    w.times = function(n, t, r) {
        for (var e = 0; n > e; e++) t.call(r, e)
    },
    w.random = function(n, t) {
        return null == t && (t = n, n = 0),
        n + (0 | Math.random() * (t - n + 1))
    };
    var I = {
        escape: {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#x27;",
            "/": "&#x2F;"
        }
    };
    I.unescape = w.invert(I.escape);
    var M = {
        escape: new RegExp("[" + w.keys(I.escape).join("") + "]", "g"),
        unescape: new RegExp("(" + w.keys(I.unescape).join("|") + ")", "g")
    };
    w.each(["escape", "unescape"],
    function(n) {
        w[n] = function(t) {
            return null == t ? "": ("" + t).replace(M[n],
            function(t) {
                return I[n][t]
            })
        }
    }),
    w.result = function(n, t) {
        if (null == n) return null;
        var r = n[t];
        return w.isFunction(r) ? r.call(n) : r
    },
    w.mixin = function(n) {
        O(w.functions(n),
        function(t) {
            var r = w[t] = n[t];
            w.prototype[t] = function() {
                var n = [this._wrapped];
                return a.apply(n, arguments),
                z.call(this, r.apply(w, n))
            }
        })
    };
    var T = 0;
    w.uniqueId = function(n) {
        var t = T++;
        return n ? n + t: t
    },
    w.templateSettings = {
        evaluate: /<%([\s\S]+?)%>/g,
        interpolate: /<%=([\s\S]+?)%>/g,
        escape: /<%-([\s\S]+?)%>/g
    };
    var N = /(.)^/,
    q = {
        "'": "'",
        "\\": "\\",
        "\r": "r",
        "\n": "n",
        "   ": "t",
        "\u2028": "u2028",
        "\u2029": "u2029"
    },
    B = /\\|'|\r|\n|\t|\u2028|\u2029/g;
    w.template = function(n, t, r) {
        r = w.defaults({},
        r, w.templateSettings);
        var e = new RegExp([(r.escape || N).source, (r.interpolate || N).source, (r.evaluate || N).source].join("|") + "|$", "g"),
        u = 0,
        i = "__p+='";
        n.replace(e,
        function(t, r, e, a, o) {
            i += n.slice(u, o).replace(B,
            function(n) {
                return "\\" + q[n]
            }),
            i += r ? "'+\n((__t=(" + r + "))==null?'':_.escape(__t))+\n'": e ? "'+\n((__t=(" + e + "))==null?'':__t)+\n'": a ? "';\n" + a + "\n__p+='": "",
            u = o + t.length
        }),
        i += "';\n",
        r.variable || (i = "with(obj||{}){\n" + i + "}\n"),
        i = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + i + "return __p;\n";
        try {
            var a = new Function(r.variable || "obj", "_", i)
        } catch(o) {
            throw o.source = i,
            o
        }
        if (t) return a(t, w);
        var c = function(n) {
            return a.call(this, n, w)
        };
        return c.source = "function(" + (r.variable || "obj") + "){\n" + i + "}",
        c
    },
    w.chain = function(n) {
        return w(n).chain()
    };
    var z = function(n) {
        return this._chain ? w(n).chain() : n
    };
    w.mixin(w),
    O(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"],
    function(n) {
        var t = e[n];
        w.prototype[n] = function() {
            var r = this._wrapped;
            return t.apply(r, arguments),
            "shift" != n && "splice" != n || 0 !== r.length || delete r[0],
            z.call(this, r)
        }
    }),
    O(["concat", "join", "slice"],
    function(n) {
        var t = e[n];
        w.prototype[n] = function() {
            return z.call(this, t.apply(this._wrapped, arguments))
        }
    }),
    w.extend(w.prototype, {
        chain: function() {
            return this._chain = !0,
            this
        },
        value: function() {
            return this._wrapped
        }
    })
}).call(this);; !
function(i) {
    function n(n) {
        return i.inArray(n.toLocaleLowerCase(), u) > -1
    }
    function e(n, e, a, l) {
        if (l && l.url) var r = l.url;
        else var r = 0 / 0;
        a.find(".loading").removeClass("hide"),
        t(a, !1),
        i.ajax({
            url: r,
            files: a.find("[type=file]"),
            iframe: !0,
            dataType: "json",
            success: function(i) {
                return a.find(".loading").addClass("hide"),
                i.errno ? (d(null, i.errmsg || "上传失败。"), void n.val("")) : void e(i.url)
            },
            error: function(i) {
                d(a, i)
            }
        }).complete(function() {})
    }
    function t(i, n) {
        n ? i.find(".upload-btn").addClass("empty") : i.find(".upload-btn").removeClass("empty")
    }
    function a(i) {
        var n = i.attr("input-name"),
        e = i.data("title"),
        t = i.attr("data-url"),
        a = u.map(function(i) {
            return "." + i
        }).join(","),
        d = '<div class="upload-preview hide" >                        <img class="simg" title="logo" width="150" height="125">                    </div>                    <div class="upload-btn empty">                        <div class="btn add-long">点击上传' + e + '图</div>                        <div class="btn add">上传</div>                        <input type="file" name="file" value="上传" accept="' + a + '"/>                        <input type="hidden" data-node="imgUrl">                        <div class="btn del">删除</div>                    </div>                    <div class="upload-loading hide loading"><img></div>';
        i.html(d),
        i.find("input:file"),
        i.find("input:hidden").attr("name", n),
        i.find("input:hidden").attr("value", t),
        i.find(".loading").find("img").attr("src", "http://web1.waimai.bdimg.com/static/merchants/images/loading_0e6e0f4.gif"),
        t && i.find(".upload-preview").removeClass("hide").find("img").attr("src", t)
    }
    function d(i, n) {
        alert(n || "上传失败")
    }
    function l(i, n, e, t) {
        var a = "",
        n = n || 150,
        e = e || 125,
        t = t || "s_0",
        d = parseInt(3 * Math.random(), 10);
        return i ? a = /^(http|https):\/\/img.waimai.bdimg.com\/.*$/gi.test(i) ? i + "@" + t + ",w_" + n + ",h_" + e: "http://webmap" + d + ".map.bdimg.com/maps/services/thumbnails?align=center,center&quality=100&width=" + n + "&height=" + e + "&src=" + encodeURIComponent(i) : ""
    }
    function r(i, n) {
        n ? i.addClass("has-del") : i.removeClass("has-del")
    }
    function s(n, a) {
        n.find("input:file").change(function(t) {
            t.preventDefault();
            var d = i(this),
            l = d.val();
            i.when(o(l)).done(function() {
                var l = t.target.files[0];
                a.validatImageSize && (f = a.validatImageSize),
                i.when(f(l)).then(function() {
                    n.find("input:hidden").val("").change(),
                    e(d,
                    function(i) {
                        n.find("input:hidden").val(i).change()
                    },
                    n, a)
                },
                function() {
                    d.val("")
                })
            })
        }),
        n.find("input:hidden").change(function() {
            var e = i(this).val();
            e && (e && !e.indexOf("http") ? (n.find("a").attr("href", e).unbind().click(function(i) {
                i.stopPropagation(),
                i.preventDefault()
            }), n.find(".simg").attr("src", l(e)).closest("div").removeClass("hide"), r(n, !0)) : n.find(".simg").closest("div").addClass("hide"))
        }),
        n.find(".btn.del").click(function() {
            n.find(".simg").attr("src", "").closest("div").addClass("hide"),
            n.find("input:file").val(""),
            n.find("input:hidden").val(""),
            n.find(".upload-btn").removeClass("empty"),
            r(n, !1),
            t(n, !0)
        })
    }
    function o(e) {
        var t = new i.Deferred;
        if (e.length) {
            var a = e.split(".");
            if (a.length && (a = a[a.length - 1], a.length)) {
                if (n(a)) return void t.resolve();
                alert("不支持此种格式的图片。")
            }
        }
        return t.reject(),
        t
    }
    function f() {
        var n = new i.Deferred;
        return n.resolve(),
        n
    }
    var u = ["jpg", "jpeg", "png", "bmp"];
    i.fn.uploadImg = function(n) {
        this.each(function() {
            var e = i(this);
            a(e, n),
            s(e, n)
        })
    }
} (jQuery);;
define("merchants:static/js/page.js",
function() {});