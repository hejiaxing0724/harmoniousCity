(function() {
    window.BMap_loadScriptTime = (new Date).getTime();
    document.write('<script type="text/javascript" src="http://api.map.baidu.com/getscript?v=2.0&ak=cCe0XnNST86WTCkWgNzG06nC&services=&t=20160928173929"></script>');
})();