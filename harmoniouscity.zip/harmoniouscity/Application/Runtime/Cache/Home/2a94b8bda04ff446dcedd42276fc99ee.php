<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
	<title>【H&L】HeJiaxing</title>
	<script type="text/javascript" src="/harmoniouscity/Public/js/jquery-3.1.0.js"></script>
	<link rel="stylesheet" type="text/css" href="/harmoniouscity/Public/bootstrap-3.3.5-dist/css/bootstrap.min.css">
	<script type="text/javascript" src ="/harmoniouscity/Public/bootstrap-3.3.5-dist/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class ="navbar navbar-default" role ="navigation" style = "position:fixed; z-index:900; width:100% ;background:#fff;">
		<div class="container">
	   		<div class ="navbar-header ">
	   			<button type ="button" class= "navbar-toggle " data-toggle ="collapse" data-target ="#example-navbar-collapse">
	   				<span class="sr-only">切换导航</span>
	   				<span class ="icon-bar"></span>
	   				<span class ="icon-bar"></span>
	   			   	<span class ="icon-bar"></span>

	   			</button>

	   			<a style ="font-size:50px;color:#09C;margin-top:10px;"href="<?php echo U('index/index');?>">
	   				H&L</a>
	   		</div>

<!-- 导航匡 -->

	   		<div class ="collapse navbar-collapse" style="font-size:20px;"id = "example-navbar-collapse">
	   			<ul class ="nav navbar-nav">
	   				<li><a style="margin-top:10px;"href="<?php echo U('info/index');?>">数据分析</a></li>
	   				<!-- <li class ="divider"></li> -->
	   				<li><a style="margin-top:10px;"href ="<?php echo U('share/index');?>">博客讨论</a></li>
	   				<!-- <li class ="divider"></li> -->

	   				
	   				<li class ="dropdown" role="presentation">
	   					<a style="margin-top:10px;"class="dropdown-toggle"data-toggle="dropdown">个人中心

	   					</a>
<!-- my 下拉列表 -->
	   					<ul class="dropdown-menu">
<!-- 检查登录 -->
	   						<?php if(is_array($checklog)): $i = 0; $__LIST__ = $checklog;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; if(($vo["result"]) == "1"): ?><li><a href="<?php echo U('My/myinfo');?>">我的资料</a></li>	
		   						<li><a href="<?php echo U('My/myblog');?>">我的博客</a></li>
		   						<li><a href="<?php echo U('index/log_out');?>">退出账号</a></li><?php endif; ?>
		   					<?php if(($vo["result"]) == "0"): ?><li><a href="<?php echo U('index/index');?>">请登录</a></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
	   					</ul>
	   				</li>
				
	   			</ul>
<!-- 搜索框 -->
	   			<form action="<?php echo U('Info/searchall');?>" method="post" class="navbar-form navbar-right" role="search">
	   				<div style="margin:10px"class="form-group">
	   					<input type ="text" class ="form-control"
	   					placeholder ="全库搜索数据和博客" name="searchcontent">
	   				</div>
	   				<input type ="submit" class ="btn btn-default" value="搜索">
	   			</form>
	   			
	   		</div>	
	   	</div>

	</nav>


<style type="text/css">

	.input-group{
    		margin: 20px;

    		
    	}
    .class{
    	clear:both;
 	

    }
    .shujubiaoti{
    	visibility: hidden;
    	width: 250px;
    	height: 65px;
    	
    	font-size: 18px;
    	background:transparent;
    	background-color:rgba(255,255,255,0.7);
    	position: relative;
    	top: 100px;
    	padding: 11px;
    }
</style>


<div style="background-image:url(/harmoniouscity/Public/picture/bg.jpg);background-size:cover;height:600px"class = "jumbotron">
		<div class ="container">

<!-- 显示登录 -->
			<div style="margin-top:50px;height:100px;"class="indexImage">
				
					<h2 style="color:#fff;position:relative;top:80px">
<!-- 检查登录						 -->
						<?php if(is_array($checklog)): $i = 0; $__LIST__ = $checklog;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>欢迎<?php if(($vo["result"]) == "1"): echo ($vo["nick"]); endif; ?>来到和谐宜居城市评价系统!
						<?php if(($vo["result"]) == "0"): ?><button style="color:#09c"type="button" class="btn btn-default btn-lg"data-toggle="modal" data-target="#myModal" >登录／注册</button><?php endif; endforeach; endif; else: echo "" ;endif; ?>
					</h2>
					
			</div>

			<div>
				
				<h1>City of Harmonious & Liveability </h1>
				<!-- <h4 >
					<a href="<?php echo U('Index/xitongjianjie');?>" style="background-color: white;padding:5px"><span class="glyphicon glyphicon-check" aria-hidden="true"></span> 评价系统简介</a>
					<a href="<?php echo U('Index/xiangguansuanf');?>" style="background-color: white;padding:5px"><span class="glyphicon glyphicon-signal" aria-hidden="true"></span> 相关算法简介</a>
					<a href="<?php echo U('Index/contactus');?>" style="background-color: white;padding:5px"><span class="glyphicon glyphicon-comment" aria-hidden="true"></span> 开发者介绍</a>
				</h4> -->
			</div>
<!-- 登录模态框 -->
	
			
			<!-- Modal -->
			<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			  <div class="modal-dialog" role="document">
			    <div class="modal-content">
			      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			        <h4 class="modal-title" id="myModalLabel">用户登录</h4>
			      </div>
			      <div class="modal-body">
<!-- 登录内容 -->
			        <div  class="input-group">
     					<span class="glyphicon glyphicon-user input-group-addon" id="sizing-addon1"aria-hidden="true"></span>
     					<input  name="username"type="text" class="username form-control" placeholder=
     		             "用户名" aria-describedby="basic-addon1">
     				</div>

     				<div class="input-group">
     					<span class="glyphicon glyphicon-heart input-group-addon" id="sizing-addon1"aria-hidden="true"></span>
     					<input  name="password"type="password" class="password form-control" placeholder=
     		             "密码" aria-describedby="basic-addon1">
     				</div>
     				<img id="yzm"src="/harmoniouscity/Public/yanzhengma.php" style="margin:0px 50px;"width="200px" height="34px"><a href="#" onclick="reloadyzm()">reload</a>

     				<div class="input-group ">
     					<span class="glyphicon glyphicon-star input-group-addon" id="sizing-addon2"aria-hidden="true"></span>
     					<input  name="yanzhengma"type="text" class="yanzhengma form-control" placeholder=
     		             "验证码" aria-describedby="basic-addon1">
     				</div>

			      </div>
			      <div class="modal-footer">
			        <button type="button" class="btn btn-default" onclick="register()">注册新用户</button>
			        <button type="button" class="btn btn-primary" onclick="login()">提交</button>
			      </div>
			    </div>
			  </div>
			</div>

<!-- 刷新验证码js -->
<script type="text/javascript">
	function reloadyzm(){
		document.getElementById("yzm").src="/harmoniouscity/Public/yanzhengma.php";
	}
	function register(){

		window.location.href="<?php echo U('index/register');?>";
	}
	function login(){
		username=$('input[name=username]').val();
		password=$('input[name=password]').val();
		yanzhengma=$('input[name=yanzhengma]').val();
		if(yanzhengma==""){
			alert('	请输入验证码');
		}else{
			data={
				username:username,
				password:password,
				yanzhengma:yanzhengma
			}
			$.ajax({url:"<?php echo U('Index/login');?>",type:'POST',data:data,success:
					                function(succ){
					                    	console.log(succ);
					                        result = JSON.parse(succ);
					                        
					                        if(result.result=='ok'){
					                              alert('登录成功');
					                            
					                               window.location.href="<?php echo U('Index/index');?>"; 
					                        }else{
					                            if (result.id=='0') {
					                                alert('密码不正确');
					                            }
					                            if (result.id=='1') {
					                                alert('您好亲爱的管理员'+result.ru_id);
					                                window.location.href="<?php echo U('Admin/index');?>"
					                            }
					                            if(result.id=='9'){
					                            	alert('验证码不正确');
					                            }
					                        }
					                            
					                }
					            })
					                      
		}
	}
</script>



	</div>
</div>
<div style="background-color:white"class = "jumbotron">
	<div class="container">
		<center>
		  <div style="margin-left:20px"class="page-header">
		  	
		  		<h2>每年，我们都用数字记录城市的一切变化</h2>
   <h2><small>H&L采用AHP算法，分析海量数据，为你所关心的36个城市问题打分</small></h2>
		  	
  
</div>
<div class="col-sm-6 col-md-4">
	<div class="shujubiaoti">2016年北京PM2.5指数减少9.9%，多了9天蓝天白云</div>
	<img class="shujutu" style="width:250px;height:250"src="/harmoniouscity/Public/picture/wumai.png" class="img-rounded">
	
</div>
<div class="col-sm-6 col-md-4">
	<div class="shujubiaoti">共享单车为首都人民节省了5个鸟巢的停车位</div>
	<img class="shujutu"style="width:250px;height:250"src="/harmoniouscity/Public/picture/duche.png" class="img-rounded">
	
</div>
<div class="col-sm-6 col-md-4">
	<div class="shujubiaoti">深圳是全中国最具创新能力的城市？</div>
	<img class="shujutu"style="width:250px;height:250"src="/harmoniouscity/Public/picture/lengmo.png" class="img-rounded">
	
</div>
 <button style="color:#09c;margin-top:50px"type="button" class="btn btn-default btn-lg"onclick="toinfo()" > 查看更多城市数据分析<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		        		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></button>
</center>

<div style="margin-left:20px;margin-top:120px"class="page-header">
		  	
		  		<h2>但有时，我们也有例外</h2>
   <h2><small>和谐宜居无法只用数字评价，每个人都有自己的普罗旺斯</small></h2>
		  	
  
</div>
<div>

</div>
	<div style="width:100%;float:left">
		<div style="float:right"class="col-sm-6 col-md-4">
			<div class="shujubiaoti">评分了了的路边摊依然能缓解城市给我们的压力</div>
			<img class="shujutu" style="height:250px;"src="/harmoniouscity/Public/picture/caiseximen.jpg">
		</div>

	

	</div>	

	<center>
		<button style="color:#09c;margin-top:50px"type="button" class="btn btn-default btn-lg" onclick="toblog()"> 参与博客讨论发表你的看法<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		        		<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></button>

	</center>
	
	
</div>


		
	

</div>
	

	
		

<script type="text/javascript">
	$('.shujutu').mouseover(function(){
          $(this).prev()[0].style.visibility="visible";

        })
    $('.shujutu').mouseout(function(){
          $(this).prev()[0].style.visibility="hidden";
        })
    function toblog(){
    	window.location.href="<?php echo U('Share/index');?>";
    }
    function toinfo(){
    	window.location.href="<?php echo U('Info/index');?>";
    }
</script>	
</body>
</html>