<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
	<title>【H&L】HeJiaxing </title>
	<script type="text/javascript" src="/harmoniouscity/Public/js/jquery-3.1.0.js"></script>
	<link rel="stylesheet" type="text/css" href="/harmoniouscity/Public/bootstrap-3.3.5-dist/css/bootstrap.min.css">
	<script type="text/javascript" src ="/harmoniouscity/Public/bootstrap-3.3.5-dist/js/bootstrap.min.js"></script>
</head>
<body>
	<div class = "jumbotron">
    <div style="background-color:white;"class ="container">
    	<div style="width:60px"><a href="<?php echo U('Index/index');?>"><button class="btn btn-default" style="margin:40px">返回</button></a></div>
    	
    	<div style="float:left;width:450px;">
    		
    		<div style="background-image:url(/harmoniouscity/Public/picture/advator.jpeg);background-size:cover;background-position:0px -150px;height:250px;margin-top:100px">
    		</div>
    		
    		
    	</div>
    	<div style="margin-left:100px;width:450px;float:left">
    		<div style="margin-bottom:50px">
    			<div style="width:200px;float:left;font-size:26px">何家兴</div>
    			<div class="text-right"style="width:150px;float:right;font-size:26px;color:#09c">开发者</div>
    		</div>

    		<div style="margin-bottom:50px">
    			<div style="width:200px;float:left;font-size:26px">360104250@qq.com</div>
    			<div class="text-right"style="width:150px;float:right;font-size:26px;color:#09c">邮箱</div>
    		</div>
    		
    		
    	</div>
    	
	</div>
</div>
</body>
</html>