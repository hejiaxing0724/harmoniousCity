<?php
namespace Home\Controller;
use Think\Controller;

class IndexController extends Controller{

	public function index(){
		$checklog = $this->log_check();
		if ($checklog==0) {
			$arr=array('result'=>'0');
		//dump(session('token'));	
		}else{
			$user=M('registereduser')->where(array('ru_id'=>$checklog))->select();
			$arrr=array('result'=>'1','nick'=>$user[0]['ru_nick']);
			$arr[]=$arrr;
		}
		//dump($arr);
		$this->assign('checklog',$arr);

		
		//$this->assign('firstindex',$firstindex);
		$this->display();
    }

     
    public function log_check(){
    	$token=session('token');
    	$arr=M('token')->where(array('t_token'=>$token))->select();
    	if (empty($arr)) {
    		return 0;
    	}else{
    		$arrr=D('User')->get_token($arr[0]['t_token']);
    		if ($arrr[0]['t_passtime']>time()) {
    			return $arrr[0]['t_ru_id'];
    		}else{
    			return 0;
    		}
    	}

    }

    public function log_out(){
    	session('token',null);

    	if (session('?token')) {
    		$this->success('账号退出失败');
    	}else{
    		$this->error('账号退出成功','index/index');
    	}
    }

    public function register(){
    	$checklog = $this->log_check();
		if ($checklog==0) {
			$arr=array('result'=>'0');
		//dump(session('token'));	
		}else{
			$user=M('registereduser')->where(array('ru_id'=>$checklog))->select();
			$arrr=array('result'=>'1','nick'=>$user[0]['ru_nick']);
			$arr[]=$arrr;
		}
		//dump($arr);
		$this->assign('checklog',$arr);
    	$this->display();
    }

    public function register_submit(){
    	$uname = I('uname');
		$password = md5(I('password'));
		$telephone = I('telephone');
		$nick=I('nick');
		$yanzhengma=I('yanzhengma');
		$yanzhengmaresult=session('yanzhengma');
		if($yanzhengma!=$yanzhengmaresult){
			echo json_encode(array('result'=>'no','id'=>"9"));
			return;
		}

		$arr = array('ru_username'=>$uname);//检查用户名是否重复
			     	if(M('registereduser')->where($arr)->select()){
			     		echo json_encode(array('result'=>'no','id'=>'1'));
						return;
			     	}
		$data=array('ru_username'=>$uname,'ru_telephone'=>$telephone,'ru_password'=>$password,'ru_nick'=>$nick);
			     	if(M('registereduser')->add($data)){
			     		$arr=M('registereduser')->where($arr)->select();
			     		//DUMP($arr);
			     		$uid=$arr[0]['ru_id'];
			     		if($add_token=D('User')->add_token($uid)){
			     			$token=D('User')->get_token($uid);
			     			//dump($token);
			     			session('token',$token[0]['t_token']);
			     			echo json_encode(array('result'=>'ok','token'=>$token));
			     		}
			     		// echo json_encode(array('result'=>'ok'));  
			     		return;
			     	}else{
			     		echo json_encode(array('result'=>'no','id'=>'0'));
			     		return;
			     	}
    }

    public function login(){
    	$ru_name=I('username');
    	$password=I('password');
    	$yanzhengma=I('yanzhengma');
    	$yanzhengmaresult=session('yanzhengma');
    	if($yanzhengma==$yanzhengmaresult){
    		$arr=M('registereduser')->where(array('ru_username'=>$ru_name))->select();
    		//var_dump($arr);
    		$ru_password=$arr[0]['ru_password'];
    		//echo md5($password);
    		if($ru_password==md5($password)){
    			$uid=$arr[0]['ru_id'];
    			$ru_manage=$arr[0]['ru_manage'];
    			if($ru_manage=='1'){
    				echo json_encode(array('result'=>'no','id'=>'1','ru_id'=>$uid));
    			}else{
    				$arrr=M('token')->where(array('t_ru_id'=>$uid))->select();
		    		$passtime=strtotime('+ 1 days');
		    		$token=md5($passtime.$uid);
		    		if(!empty($arrr)){
		    			M('token')->where(array('t_ru_id'=>$uid))->save(array('t_passtime'=>$passtime,'t_token'=>$token));
		    		}else{
		    			M('token')->add(array('t_ru_id'=>$uid,'t_passtime'=>$passtime,'t_token'=>$token));
		    		}
	    			session('token',$token);
    				echo json_encode(array('result'=>'ok','token'=>$token));
    			}
    			
	    		
    			
    		}else{
    			echo json_encode(array('result'=>'no','id'=>'0'));
    		}
    	}else{echo json_encode(array('result'=>'no','id'=>'9'));}
    }

    public function xitongjianjie(){
    	layout(false);
    	$this->display();
    }

    public function xiangguansuanf(){
    	layout(false);
    	$this->display();
    }

    public function contactus(){
    	layout(false);
    	$this->display();
    }
}
